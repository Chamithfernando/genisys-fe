import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from '@app/login/login.component';
import { PageNotFoundComponent } from '@app/page-not-found/page-not-found.component';

import { AuthGuard } from '@app/shared/guards/auth.guard';
import { EnableProcessBannerComponent } from './enable-process-banner/enable-process-banner.component';
import { PolicyAgreementComponent } from './policy-agreement/policy-agreement.component';

const routes: Routes = [
  {
    path: '',
    component: LoginComponent
  },
  {
    path: 'disclaimer',
    component: PolicyAgreementComponent,
  },
  {
    path: 'enabled-calculation-process',
    component: EnableProcessBannerComponent,
  },

  {
    path: 'dashboard',
    loadChildren: () => import('./dashboard/dashboard.module').then((m) => m.DashboardModule),
    canActivate: [AuthGuard]
  },

  { path: '**', component: PageNotFoundComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes, {  useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
