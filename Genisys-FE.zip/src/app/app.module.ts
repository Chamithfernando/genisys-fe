import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LOCAL_STORAGE } from 'ngx-webstorage-service';
import { SERVICE_STORAGE, LocalStorageService } from '@app/shared/services/local-storage/local-storage.service';

// import {NgIdleModule} from '@ng-idle/core';

// import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';

import { AppRoutingModule } from '@app/app-routing.module';
import { AppComponent } from '@app/app.component';
import { LoginComponent } from '@app/login/login.component';
import { PageNotFoundComponent } from '@app/page-not-found/page-not-found.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuthGuard } from './shared/guards/auth.guard';
import { DialogComponent } from '@app/shared/dialog/dialog.component';
import { MatDialogModule } from '@angular/material/dialog';
import { PopupService } from '@app/shared/services/popup/popup.service';
import { ErrorInterceptor } from '@app/shared/interceptors/error.interceptor';
import { MatSelectModule } from '@angular/material/select';
import { AuthInterceptor } from './shared/interceptors/authInterceptor';
import { MatTableModule } from '@angular/material/table';
import { NgHttpLoaderModule } from 'ng-http-loader';

import { PolicyAgreementComponent } from './policy-agreement/policy-agreement.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { GenarateAgentComponent } from './shared/popup/genarate-agent/genarate-agent.component';
import { NgxIntlTelInputModule } from 'ngx-intl-tel-input';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { EnableProcessBannerComponent } from './enable-process-banner/enable-process-banner.component';
import { NormalUserGuard } from './shared/guards/normal-user.guard';
import { ApprovalUserGuard } from './shared/guards/approval-user.guard';

import { MatTableExporterModule } from 'mat-table-exporter';
import { MatChipsModule } from '@angular/material/chips';
import { BirthdayToAgePipe } from './dashboard/azpp/dob-to-age/birthday-to-age.pipe';
import { NgxJsonViewerModule } from 'ngx-json-viewer';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { SaveButtonComponent } from './shared/button/save-button/save-button.component';
import {SnowComponent} from '@app/shared/animation/snow.component';
import {MatCardModule} from "@angular/material/card";
import {MatPaginatorModule} from "@angular/material/paginator";
import {MatDatepickerModule} from "@angular/material/datepicker";

import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { MatTooltipModule } from '@angular/material/tooltip';
import { DividerModule } from 'primeng/divider';









@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    PageNotFoundComponent,
    DialogComponent,
    GenarateAgentComponent,
    PolicyAgreementComponent,
    EnableProcessBannerComponent,
    BirthdayToAgePipe,
    SaveButtonComponent,
    SnowComponent,

  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    InputTextModule,
    ButtonModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule,
    MatCheckboxModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatProgressBarModule,
    MatSnackBarModule,
    MatSelectModule,
    MatTableModule,
    MatExpansionModule,
    NgxIntlTelInputModule,
    BsDropdownModule,
    MatTableExporterModule,
    MatChipsModule,
    NgxJsonViewerModule,
    PdfViewerModule,
    MatAutocompleteModule,
    MatTooltipModule,
    DividerModule,
    NgHttpLoaderModule.forRoot(),
    MatCardModule,
    MatPaginatorModule,
    MatDatepickerModule,


    // NgIdleModule.forRoot(),
    // NgIdleKeepaliveModule.forRoot()
  ],
  providers: [AuthGuard, PopupService, MatSnackBarModule, LocalStorageService, NormalUserGuard, ApprovalUserGuard,



    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },


    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    { provide: SERVICE_STORAGE, useExisting: LOCAL_STORAGE },

    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true }],

  bootstrap: [AppComponent],
  exports: [
  ],
  schemas: []
})
export class AppModule { }
