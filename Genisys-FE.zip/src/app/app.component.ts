import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
// import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { AuthService } from '@app/shared/services/auth/auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent  implements OnInit {
  idleState = 'NOT_STARTED';
  countdown?: number = null;
  lastPing?: Date = null;
  title = 'front-end';
  session = [];

  constructor(
    private readonly titleService: Title,
    private authService: AuthService,
    // private idle: Idle,
    _cd: ChangeDetectorRef
    )
  {
    // const checkToken = this.authService.getCurrentUserDetails().access_token;
    // if (checkToken){
    //   idle.setIdle(5);
    //   idle.setTimeout(300);
    //   idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    //   idle.onIdleStart.subscribe(() => {
    //     this.idleState = 'IDLE';
    //   });
    //   idle.onIdleEnd.subscribe(() => {
    //     this.idleState = 'NOT_IDLE';
    //     console.log(`${this.idleState} ${new Date()}`);
    //     this.countdown = null;
    //     _cd.detectChanges();
    //   });
    //   idle.onTimeout.subscribe(() => {
    //     this.idleState = 'TIMED_OUT';
    //     this.authService.timeoutLogout();
    //   });
    // }
  }

  reset() {
    this.idleState = 'NOT_IDLE';
    this.countdown = null;
    this.lastPing = null;
  }
    async ngOnInit() {
      this.reset();
    }
  }
