import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ClaimRequestComponent } from './claim-request/claim-request.component';
import { PageNotFoundComponent } from '@app/page-not-found/page-not-found.component';
import { ViewClaimRequestComponent } from './claim-request/view-claim-request/view-claim-request.component';
import { UploadClaimFormComponent } from './claim-request/upload-claim-form/upload-claim-form.component';
import { AspManagementComponent } from './asp-management.component';
import { CreateClaimRequestComponent } from './claim-request/create-claim-request/create-claim-request.component';
import { SignatureContainerComponent } from './claim-request/signature-container/signature-container.component';
import { UpdateCalimRequestComponent } from './claim-request/update-calim-request/update-calim-request.component';
import { ActionClaimRequestComponent } from './claim-request/action-claim-request/action-claim-request.component';
import { AspReportComponent } from './asp-report/asp-report.component';

const routes: Routes = [
  {
    path: '',
    component: AspManagementComponent,
    children: [
      {
        path: '',
        component: ClaimRequestComponent
      },
      {
        path: 'report',
        component: AspReportComponent
      },
      {
        path: 'view-claim-request/:claimId',
        component: ViewClaimRequestComponent
      },
      {
        path: 'action-claim-request/:claimId',
        component: ActionClaimRequestComponent
      },
      {
        path: 'update-claim-request/:claimId',
        component: UpdateCalimRequestComponent
      },
      {
        path: 'create-claim-request',
        component: CreateClaimRequestComponent
      },
      {
        path: 'service-portal/signature/claim/:claimId',
        component: SignatureContainerComponent
      },


      { path: '**', component: PageNotFoundComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AspManagementRoutingModule { }
