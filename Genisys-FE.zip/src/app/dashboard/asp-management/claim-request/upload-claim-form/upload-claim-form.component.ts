import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DomSanitizer } from '@angular/platform-browser';
import { DocumentViewerNgxComponent } from '@app/dashboard/sales-onbording/document-upload-section/document-viewer-ngx/document-viewer-ngx.component';
import { AspModuleService } from '@app/shared/services/asp-module/asp-module.service';
import { AuthService } from '@app/shared/services/auth/auth.service';
import { EncryptDecryptService } from '@app/shared/services/encrypt-decrypt-service/encrypt-decrypt.service';
import { ImageCompresserService } from '@app/shared/services/image-compresser/image-compresser.service';
import { Observable } from 'rxjs';
import { take } from 'rxjs/operators';



export interface FileData {
  documentType: string;
  fileNames: string;
  fileNameArray:any;
  files: any;
  required: string;
}

interface DmsFiles {
  extension: string,
  name: string,
  file: any
}
interface DmsRequestDTO{
  type: string,
      policyNo: string,
      contractNo: string,
      files: DmsFiles[]
}
interface DmsFilesRetrieve {
  policyNo: string,
  contractNo: string
}

interface DmsFileData {
  file: string,
  name: string
}

export interface DmsPayload {
  dmsRequestDTOList:DmsRequestDTO[],
  status: string
}

@Component({
  selector: 'app-upload-claim-form',
  templateUrl: './upload-claim-form.component.html',
  styleUrls: ['./upload-claim-form.component.scss']
})
export class UploadClaimFormComponent implements OnInit{

  @Input() documentFormData: any;
  @Output() onFormLoaded = new EventEmitter<any>();
  token: any;

  documentUploadTitle: string;
  claimRequestId: number;
  isEnableDocumentList: boolean = true;
  claimRequestData: any;

  isClaimRequestViewEnable: boolean = false;

  selectedFiles: any = [];
  documentListFromDMS: DmsRequestDTO[] = [];
  submitReadyFileList: any = [];
  progressInfos = [];
  message = '';

  validationFileSize: number = 10485760;
  documentList: any = [];
  isFileValid: boolean = false;
  documentLoading: boolean = false;

  fileInfos: Observable<any>;
  @ViewChild('formInput') fileInputVariable: ElementRef;
  validationMessage: string = "Please verify the required file type and Maximum file size is 10MB";
  dialogRef: MatDialogRef<any>;

  constructor(
    private aspService: AspModuleService,
    private _snackBar: MatSnackBar,
    private authService: AuthService,
    private imageCompressor: ImageCompresserService,
    private encryptDecryptService: EncryptDecryptService,
    private sanitizer: DomSanitizer,
    public dialog: MatDialog,
  
  ) {
    this.token = this.authService.getCurrentUserDetails().access_token;
   }

  ngOnInit() {
   
    this.documentUploadTitle = this.documentFormData.title;
    this.claimRequestId = this.documentFormData.data.claimRequestId;
    this.claimRequestData = this.documentFormData.data;
    this.isClaimRequestViewEnable = this.documentFormData.isEnableDocView;

    console.log(this.documentFormData);
    


    console.log(this.documentUploadTitle);
    this.loadSavedFilesForomClaimRequest(this.claimRequestId);
    
  }

  incomingSavedFiles: any;

  async loadSavedFilesForomClaimRequest(requestId: number){
    this.documentLoading = true;
    let dmsPayloadModel:DmsFilesRetrieve={policyNo:this.claimRequestData.policyNumber,contractNo:this.claimRequestData.claimGeneratedCode};
      const documentretreiveResponse: any = await this.getClaimDocuments(dmsPayloadModel).catch((error) => {
        console.log(error);
      });
    if (documentretreiveResponse.status == 200) {
      this.onFormLoaded.emit("pending");
      this.documentLoading = false;
      this.documentListFromDMS = documentretreiveResponse.payload;
      console.log(this.documentListFromDMS);
      const updatedDocumentTitle: string = this.documentUploadTitle + ' form'
      console.log(updatedDocumentTitle);

      this.documentListFromDMS.filter(dmsDoc => {
        if (dmsDoc.type == updatedDocumentTitle) {
          this.onFormLoaded.emit("uploaded");
          const dmsFileResponse: DmsFiles[] = dmsDoc.files;
          for (let i = 0; i < dmsFileResponse.length; i++) {
            let blob = this.encryptDecryptService.dataURItoBlob(dmsFileResponse[i].file);
            var file = new File([blob], dmsFileResponse[i].name + '.pdf', {
              type: "'application/pdf'"
            });

            this.selectedFiles.push(file);

          }
        }


      })
    


      // for (let i = 0; i < this.documentListFromDMS.files; i++) {
      //   const element = array[i];

      // }
    } else{
      this.onFormLoaded.emit("pending");
    }
     this.documentLoading = false;
   
    

  }

  

  async getClaimDocuments(payload: any) {
    return new Promise((resolve, reject) => {
      this.aspService
        .getClaimDocuments(this.token,payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
 

  async selectFiles(pFileList: File[]) {
    this.documentList = Object.keys(pFileList).map(key => pFileList[key]);
    for (let i = 0; i < this.documentList.length; i++) {
      let file = this.documentList[i];
      if (file.size < this.validationFileSize) {
        if (file.type === "application/pdf" || file.type === "image/jpeg" || file.type === "image/png") {
          this.isFileValid = true;
        } else {
          this.isFileValid = false;
        }
      } else {
        this.isFileValid = false;
      }

    }
console.log("isFileValid "+this.isFileValid)
    if (this.isFileValid) {

      for (let i = 0; i < this.documentList.length; i++) {
        let file = this.documentList[i];
        if(file.type === "image/jpeg" || file.type === "image/png"){
          file=await this.compressImage(file);
        }
        this.selectedFiles.push(file);

      }
      this._snackBar.open("File ready to upload!", 'Close', {
        duration: 2000,
      });

    } else if (!this.isFileValid) {
      this.resetDocuments();
      this._snackBar.open(this.validationMessage, 'Close', {
        duration: 2000,
      });
    }
  }

  compressImage(image) {
    return new Promise((resolve, reject) => {
      this.imageCompressor.compress(image)
        .pipe(take(1))
        .subscribe(compressedImage => {
          resolve(compressedImage);
        }, error => {
          reject(error);
        });
    });
  }

  resetDocuments() {
    this.documentList = [];
    this.fileInputVariable.nativeElement.value = "";
    this.onFormLoaded.emit("pending");
  }

  upload(idx, file) {
    this.progressInfos[idx] = { value: 0, fileName: file.name };

    console.log(this.progressInfos[idx].value);
    
  }

  removeDocument(index: number): void {
    this.selectedFiles.splice(index, 1);
    if(this.selectedFiles.length==0){
      this.onFormLoaded.emit("pending");
    }
  }

  downlaodDocument(index: number): void {
    let file = this.selectedFiles[index];
    const newBlob = new Blob([file]);
    const data = window.URL.createObjectURL(newBlob);
    const downloadLink = document.createElement("a");
    downloadLink.href = data;
    downloadLink.download = file.name;
    downloadLink.click();
  }

  async uploadFiles() {
    let dmsRequestmodel:DmsRequestDTO[]=[];
    let dmsFileModel:DmsFiles[]=[];
    if (this.selectedFiles.length > 0) {
      for (let i = 0; i < this.selectedFiles.length; i++) {
        console.log(this.selectedFiles[i]);
        
        let fileNameExtention=this.selectedFiles[i].name.split(".");
        const base64 = await this.encryptDecryptService.fileToDataURL(this.selectedFiles[i]);

        console.log(fileNameExtention);
        dmsFileModel.push({extension:fileNameExtention[1],name:fileNameExtention[0],file:base64});
        console.log(dmsFileModel);
      }
      const updatedDocumentTitle: string = this.documentUploadTitle + ' form'
      dmsRequestmodel.push({type:updatedDocumentTitle,policyNo:this.claimRequestData.policyNumber,contractNo:this.claimRequestData.claimGeneratedCode,files:dmsFileModel})
      console.log(dmsRequestmodel);
      let dmsPayloadModel:DmsPayload={dmsRequestDTOList:dmsRequestmodel,status:"update"}
      console.log(dmsPayloadModel);
      this.documentLoading = true;
      const documentUploadResponse: any = await this.saveClaimDocuments(dmsPayloadModel).catch((error) => {
        console.log(error);
      });
      if (documentUploadResponse.status == 200) {
        this.selectedFiles = [];
        this.loadSavedFilesForomClaimRequest(this.claimRequestId);
        console.log("successfully uploaded");
        this._snackBar.open("Form Uploaded Successful!", 'Close', {
          duration: 2000,
        });
        this.documentLoading = false;

      } else {
        this.onFormLoaded.emit("pending");
        this.documentLoading = false;
      }
      
    } else {
      
    }
  }

  async saveClaimDocuments(payload: any) {
    return new Promise((resolve, reject) => {
      this.aspService
        .saveClaimDocuments(this.token,payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  viewClaimFormDoc(index: number): void {
    let file = this.selectedFiles[index];
    this.viewDocumentItem(file);
  }

  viewDocumentItem(submitReadyDoc: any) {
    if (submitReadyDoc.type == "'application/pdf'" || submitReadyDoc.type == 'application/pdf') {
      const docfilePdf = new File([submitReadyDoc], submitReadyDoc.name, { type: 'application/pdf' });
      const rowurl = URL.createObjectURL(docfilePdf);
      this.dialogRef = this.dialog.open(DocumentViewerNgxComponent, {
        width: '900px',
        disableClose: true,
        data: {
          file: rowurl,
          type: "pdf",
        }
      });
    } else {
      const docfileJpg = new File([submitReadyDoc], submitReadyDoc.name, { type: 'image/jpeg' });
      const rowurl = URL.createObjectURL(docfileJpg);
      const url = this.sanitizer.bypassSecurityTrustResourceUrl(rowurl);
      // console.log(url);
      this.dialogRef = this.dialog.open(DocumentViewerNgxComponent, {
        width: '95%',
        disableClose: true,
        data: {
          file: url,
          type: "jpg",
        }
      });
    }
  }
  


  

}

