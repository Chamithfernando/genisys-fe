import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadClaimFormComponent } from './upload-claim-form.component';

describe('UploadClaimFormComponent', () => {
  let component: UploadClaimFormComponent;
  let fixture: ComponentFixture<UploadClaimFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UploadClaimFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UploadClaimFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
