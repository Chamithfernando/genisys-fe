import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AspModuleService } from '@app/shared/services/asp-module/asp-module.service';
import { AuthService } from '@app/shared/services/auth/auth.service';

@Component({
  selector: 'app-approval-remak-history',
  templateUrl: './approval-remak-history.component.html',
  styleUrls: ['./approval-remak-history.component.scss']
})
export class ApprovalRemakHistoryComponent {

  token: any;
  claimRequestId: number;
  isEnable404Image: boolean = false;

  claimHistoryReponse: any[]

  constructor(
    public dialogRef: MatDialogRef<ApprovalRemakHistoryComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
    private _formBuilder: FormBuilder,
    private authService: AuthService,
    private aspServiceService: AspModuleService
  ) {
    this.claimRequestId = data;
    this.token = this.authService.getCurrentUserDetails().access_token;
    this.getClaimRequestData();

    
  }

  async getClaimRequestData(){
    this.isEnable404Image = false;
    const claimRequestHistoryResponse: any = await this.getCliamHistoryAndRemarkHistory().catch((error) => {
      console.log(error);
    });
    if (claimRequestHistoryResponse.status == 200) {
      if(claimRequestHistoryResponse.payload.length != 0) {
        this.claimHistoryReponse=claimRequestHistoryResponse.payload;
      } else {
        this.isEnable404Image = true;
      }
    } else {
      this.isEnable404Image = true;
    }
    
    
  }


  firstFormGroup: FormGroup = this._formBuilder.group({firstCtrl: ['']});
  secondFormGroup: FormGroup = this._formBuilder.group({secondCtrl: ['']});


  async getCliamHistoryAndRemarkHistory() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId,
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimApprovalAndRemarkHistory(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
