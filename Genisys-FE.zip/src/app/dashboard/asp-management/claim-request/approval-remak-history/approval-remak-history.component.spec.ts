import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApprovalRemakHistoryComponent } from './approval-remak-history.component';

describe('ApprovalRemakHistoryComponent', () => {
  let component: ApprovalRemakHistoryComponent;
  let fixture: ComponentFixture<ApprovalRemakHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApprovalRemakHistoryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ApprovalRemakHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
