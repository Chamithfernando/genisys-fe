import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RejectionClaimRequestComponent } from './rejection-claim-request.component';

describe('RejectionClaimRequestComponent', () => {
  let component: RejectionClaimRequestComponent;
  let fixture: ComponentFixture<RejectionClaimRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RejectionClaimRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RejectionClaimRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
