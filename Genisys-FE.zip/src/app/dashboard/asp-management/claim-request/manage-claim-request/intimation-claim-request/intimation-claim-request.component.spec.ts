import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IntimationClaimRequestComponent } from './intimation-claim-request.component';

describe('IntimationClaimRequestComponent', () => {
  let component: IntimationClaimRequestComponent;
  let fixture: ComponentFixture<IntimationClaimRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IntimationClaimRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IntimationClaimRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
