import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignClaimRequestComponent } from './assign-claim-request.component';

describe('AssignClaimRequestComponent', () => {
  let component: AssignClaimRequestComponent;
  let fixture: ComponentFixture<AssignClaimRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssignClaimRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssignClaimRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
