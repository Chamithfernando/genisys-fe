import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AspModuleService } from '@app/shared/services/asp-module/asp-module.service';
import { DocumentViewerDialogComponent } from '../../upload-documents/document-viewer-dialog/document-viewer-dialog.component';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-assign-claim-request',
  templateUrl: './assign-claim-request.component.html',
  styleUrls: ['./assign-claim-request.component.scss']
})
export class AssignClaimRequestComponent {

  
  newClaimRequest: FormGroup;
  assignableUsers:any;
  token: any;
  action:any;
  internalStatus: any;
  noOfClaims:number;
  

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private aspServiceService: AspModuleService,
    private _formBuilder: FormBuilder,
    private dialogRef: MatDialogRef<DocumentViewerDialogComponent>,
  ){
    this.token=this.data.token;
    this.action=this.data.action;

    this.newClaimRequest = _formBuilder.group({
      firstApproval: ['', Validators.required]
      
    });
    if(this.action=="bulkAssign" || this.action=="bulkReAssign"){
      this.loadBulkAssignData();
      this.noOfClaims=this.data.claimRequests.length != 0 ?this.data.claimRequests.length:0;
    }else{
      this.loadData();
    }
    
  }

  async loadBulkAssignData(){
    const assignedusersResponse: any =await this.getAssignableUsers(true).catch((error) => {
      console.log(error);
    });
    if (assignedusersResponse.status == 200) {
      this.assignableUsers=assignedusersResponse.payload;
    }
  }

  async loadData(){
    const assignedusersResponse: any =await this.getAssignableUsers(false).catch((error) => {
      console.log(error);
    });
    if (assignedusersResponse.status == 200) {
      this.assignableUsers=assignedusersResponse.payload;
    }
    const currentAssignResponse: any = await this.getCurrentAssignDetails().catch((error) => {
      console.log(error);
    });
    if (currentAssignResponse.status == 200) {
      this.internalStatus = currentAssignResponse.payload.internalStatus;
    }
  }

  async assignClaimRequest(){
    const assignResponse: any =await this.assignClaimRequestFirstLevel().catch((error) => {
      console.log(error);
    });
    if (assignResponse.status == 200) {
      Swal.fire({
        title: "Success",
        text: "Claim is assigned successfully",
        confirmButtonText: "OK",
      }).then(async (result) => {
        if (result.isConfirmed) {
          this.closeDialog("");
        }
      });      
    }
  }

  async reAssignClaimRequest(){
    const assignResponse: any =await this.reAssignClaimRequestFirstLevel().catch((error) => {
      console.log(error);
    });
    if (assignResponse.status == 200) {
      Swal.fire({
        title: "Success",
        text: "Claim is assigned successfully",
        confirmButtonText: "OK",
      }).then(async (result) => {
        if (result.isConfirmed) {
          this.closeDialog("");
        }
      });
      
    }
  }

  async bulkAssignClaimRequest(){
    const assignResponse: any =await this.bulkAssignClaimRequestFirstLevel().catch((error) => {
      console.log(error);
    });
    if (assignResponse.status == 200) {
      Swal.fire({
        title: "Success",
        text: "Claim is assigned successfully",
        confirmButtonText: "OK",
      }).then(async (result) => {
        if (result.isConfirmed) {
          this.closeDialog("");
        }
      });
      
    }
  }

  closeDialog(action:string){
    this.dialogRef.close({action:action});
  }

  async getAssignableUsers(isBulk:boolean) {
    let paylaod ={}
    if(isBulk){
      paylaod = {
        token: this.token
      }
    }else{
      paylaod = {
        token: this.token,
        claimRequestId: this.data.claimRequestId
      }
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getAssigneeUserList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getCurrentAssignDetails() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.data.claimRequestId,
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getCurrentAssignDetails(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async assignClaimRequestFirstLevel() {
    const request = {
      token: this.token,
      data:{
        claimRequestId: this.data.claimRequestId,
        userId:this.newClaimRequest.value.firstApproval,
        action:3,
      }
      
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .assignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async reAssignClaimRequestFirstLevel() {
    
    let action;
    if (this.internalStatus == "Pending-Call Center Assign") {
      action = 7;
    } else if (this.internalStatus == "Rejected - Call Center  Assign") {
      action = 9;
    } else if (this.internalStatus == "Approved - Call Center Assign") {
      action = 11;
    } else if (this.internalStatus == "Intimate - Call Center Assign") {
      action = 15;
    }else{
      action=3;
    }
    let userName = this.assignableUsers.find(users => users.id == this.newClaimRequest.value.firstApproval).name;
    const request = {
      token: this.token,
      data:{
        claimRequestId: this.data.claimRequestId,
        userId:this.newClaimRequest.value.firstApproval,
        action:action,
        remark:"Claim request re-assigned to "+userName,
        admin:true
      }
      
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .assignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async bulkAssignClaimRequestFirstLevel() {
    const claimIds=this.data.claimRequests.map(claim=>claim.id)
    let userName = this.assignableUsers.find(users => users.id == this.newClaimRequest.value.firstApproval).name;
    const payload={
      claimRequestIds: claimIds,
      userId:this.newClaimRequest.value.firstApproval,
      action:3
    };
    if(this.action=="bulkReAssign"){
      payload['admin']=true;
      payload['payload']="Claim request re-assigned to "+userName;
    }
    const request = {
      token: this.token,
      data:payload
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .bulkAssignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
}
