import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllCalimRequestComponent } from './all-calim-request.component';

describe('AllCalimRequestComponent', () => {
  let component: AllCalimRequestComponent;
  let fixture: ComponentFixture<AllCalimRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllCalimRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AllCalimRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
