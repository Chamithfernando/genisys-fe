import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { AspModuleService } from '@app/shared/services/asp-module/asp-module.service';
import { AuthService } from '@app/shared/services/auth/auth.service';
import { ApprovalRemakHistoryComponent } from '../../approval-remak-history/approval-remak-history.component';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { AssignClaimRequestComponent } from '../assign-claim-request/assign-claim-request.component';
import { Table } from 'primeng/table';
import { event } from 'jquery';
import * as FileSaver from 'file-saver';
import { FilterMatchMode, LazyLoadEvent, PrimeNGConfig } from 'primeng/api';


export interface Claims {
  id: number;
  requestNumber: string;
  policyNumber: string;
  claimNumber: string;
  claimantName: string;
  branchName: string
  claimType: string;
  submittedDate: string
  requestStatus: string;
}
export interface FilterChildren {
  value: string,
  matchMode: string,
  column: string
}
export interface Product {
  id?: string;
  code?: string;
  name?: string;
  description?: string;
  price?: number;
  quantity?: number;
  inventoryStatus?: string;
  category?: string;
  image?: string;
  rating?: number;
}
export interface Representative {
  name?: string;
  image?: string;
}
const FILTER_DATA: FilterChildren[] = [
];

@Component({
  selector: 'app-all-calim-request',
  templateUrl: './all-calim-request.component.html',
  styleUrls: ['./all-calim-request.component.scss']
})
export class AllCalimRequestComponent implements OnInit {

  token: any;
  userRole: any;
  dataSource = new MatTableDataSource([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  displayedColumns = ['requestNumber', 'policyNumber', 'claimNumber', 'claimantName', 'branchName', 'claimType', 'submittedDate', 'assignedUser', 'requestStatus', 'action'];
  @ViewChild('busTbSort') busTbSort = new MatSort();
  @ViewChild('dt') dt: Table | undefined;
  @Input() details: any;
  limit: number = 10;
  offset: number = 0;
  count: any;
  length = 100;
  pageSize = 10;
  pageSizeOptions: number[] = [10, 50, 100, 200];
  advanceSearchForm: FormGroup;
  dialogRef: MatDialogRef<any>;
  claimRequests: Claims[];
  selectedClaimRequests: Claims[];
  clairmRequest: Claims;
  representatives: Representative[];
  products: Product[];
  cols: any[];
  exportName: string;
  myPaginationString: string;
  totalRecords = 0;
  first = 0;
  rows = 10;
  matchModeOptions = [];
  
  loadingEvent: LazyLoadEvent;

  filters = [...FILTER_DATA];
  statuses: any[];
  claimTypes: any[];
  users:any[];
  selectedUser: any = null;
  selectedClaimType: any = null;
  selectedStatus: any = null;
  value: Date | null;
  today: Date = new Date();

  pageEvent: PageEvent;

  isEnableAdvanceSearch: boolean = false;

  searchText = new FormControl('');

  constructor(
    private aspServiceService: AspModuleService,
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private dialog: MatDialog,
    private config: PrimeNGConfig
  ) {
    this.token = this.authService.getCurrentUserDetails().access_token;
    // this.loadData();
    // this.loadDataWithFilter(this.loadingEvent);
    this.cols = [
      {
        field: 'claimRequestNumber',
        header: 'Claim Request Number'
      },
      {
        field: 'policyNumber',
        header: 'Policy Number'
      },
      {
        field: 'claimNumber',
        header: 'Claim Number'
      },
      {
        field: 'claimantsName',
        header: 'Claimants Name'
      },
      {
        field: 'branchName',
        header: 'Branch Name'
      },
      {
        field: 'submittedDate',
        header: 'Submitted Date'
      },
      {
        field: 'currentAssignUser',
        header: 'Assigned User'
      },
      {
        field: 'claimListType',
        header: 'Claim Type'
      },
      {
        field: 'requestStatus',
        header: 'Status'
      },
    ];
    this.matchModeOptions = [
      {
        label: 'Starts With',
        value: FilterMatchMode.STARTS_WITH
      },
      {
        label: 'Contains',
        value: FilterMatchMode.CONTAINS
      },
      {
        label: 'Ends With',
        value: FilterMatchMode.ENDS_WITH
      },
      {
        label: 'Equals',
        value: FilterMatchMode.EQUALS
      },
    ];
    this.exportName = "Claim report"
    this.advanceSearchForm = formBuilder.group({
      policyNu: [''],
      claimRequestNu: [''],
    });
    this.userRole = localStorage.getItem('ASPUserRoleId');
  }
  async ngOnInit(): Promise<void> {
    const statusListResponse: any =await this.getStatusList().catch((error) => {
      console.log(error);
    });
    if (statusListResponse.status == 200) {
      this.statuses= statusListResponse.payload.map(item => ({
        label: item.name,  
        value: item.name  
      }));
    }
    const claimListResponse: any = await this.getClaimList().catch((error) => {
      console.log(error);
    });
    if (claimListResponse.status == 200) {
      this.claimTypes = claimListResponse.payload.map(item => ({
        label: item.name,  
        value: item.name  
      }));
    }
    const assignedusersResponse: any =await this.getAssignableUsers(true).catch((error) => {
      console.log(error);
    });
    if (assignedusersResponse.status == 200) {
      this.users=assignedusersResponse.payload.map(item => ({
        label: item.name,  
        value: item.userServiceUserId  
      }));
    }

  }



  async getStatusList() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getStatusList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  convertToCapitalized(value: string): string {
    if (!value) return ''; 
    value = value.toLowerCase(); 
    return value.charAt(0).toUpperCase() + value.slice(1); 
  }

  async loadDataWithFilter(event: LazyLoadEvent) {
    this.filters = [];
    if (event.filters.claimRequestNumber != undefined) {
      const rawDate = event.filters.submittedDate[0].value;
      let fixedDate=null;
      if(rawDate!=null){
        const rawDateUTC = new Date(Date.UTC(rawDate.getFullYear(), rawDate.getMonth(), rawDate.getDate()));
        const utcNoon = new Date(rawDateUTC.setUTCHours(12, 0, 0, 0));
        fixedDate = utcNoon.toISOString();
      }
      this.filters.push({ value: event.filters.claimRequestNumber[0].value, matchMode: event.filters.claimRequestNumber[0].matchMode, column: "claimRequestNumber" })
      this.filters.push({ value: event.filters.policyNumber[0].value, matchMode: event.filters.policyNumber[0].matchMode, column: "policyNumber" })
      this.filters.push({ value: event.filters.claimNumber[0].value, matchMode: event.filters.claimNumber[0].matchMode, column: "claimNumber" })
      this.filters.push({ value: event.filters.branchName[0].value, matchMode: event.filters.branchName[0].matchMode, column: "branchName" })
      this.filters.push({ value: fixedDate, matchMode: event.filters.submittedDate[0].matchMode, column: "createDate" })
      this.filters.push({ value: event.filters.requestStatus[0].value, matchMode: event.filters.requestStatus[0].matchMode, column: "requestStatus" })
      this.filters.push({ value: event.filters.claimListType[0].value, matchMode: event.filters.claimListType[0].matchMode, column: "claimList" })
      this.filters.push({ value: event.filters.currentAssignUser[0].value, matchMode: event.filters.currentAssignUser[0].matchMode, column: "currentAssignUser" })
    }

    const request = {
      token: this.token,
      limit: this.limit,
      offset: this.offset,
      data: {
        limit: this.limit,
        offset: this.offset,
        filters: this.filters,
        sortField: event.sortField ? event.sortField : '',
        sortOrder: event.sortOrder === 1 ? 'ASC' : 'DESC'
      }
    }
    const claimDashboardResponse: any = await this.getClaimDashboardWithFilter(request).catch((error) => {
      console.log(error);
    });
    if (claimDashboardResponse.status == 200) {
      this.dataSource = new MatTableDataSource<Claims>(claimDashboardResponse.payload.object);
      this.claimRequests = claimDashboardResponse.payload.object;
      this.count = claimDashboardResponse.payload.count;
      this.length = this.count;

    }

  }

  applyFilterGlobal(event: any, stringVal: any) {
    console.log((event.target as HTMLInputElement).value + " " + stringVal)
    this.dt!.filterGlobal((event.target as HTMLInputElement).value, stringVal);
  }

  applyFilter(value: string | null, filterCallback: any) {
    console.log(value)
    if (value) {
      filterCallback(value);
    } else {
      filterCallback(null);
    }
  }


  exportExcel() {
    import('xlsx').then((xlsx) => {
      const worksheet = xlsx.utils.json_to_sheet(this.products);
      const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
      const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
      this.saveAsExcelFile(excelBuffer, 'products');
    });
  }

  saveAsExcelFile(buffer: any, fileName: string): void {
    let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    let EXCEL_EXTENSION = '.xlsx';
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE
    });
    FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
  }

  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput
        .split(',')
        .map((str) => +str);
    }
  }

  getStatusColor(status) {
    switch (status) {
      case 'Rejected':
        return 'danger';
      case 'Rejected - Call Center Updated':
        return 'danger';
      case 'Rejected - Call Center  Assign':
        return 'danger';

      case 'Approved':
        return 'success';

      case 'Approved - Call Center Updated':
        return 'success';

      case 'Approved - Call Center Assign':
        return 'success';

      case 'Assigned':
        return 'info';

      case 'Pending':
        return 'warning';

      case 'Pending-Call Center Updated':
        return 'warning';

      case 'Pending-Call Center Assign':
        return 'warning';

      case 'Returned':
        return 'danger';

      default:
        return null;
    }
  }

  async loadLazyData(event: LazyLoadEvent) {
    this.filters = [];
    console.log(event)
    this.offset = (event.first === 0 || event.first == undefined) ? 0 : event.first / (event.rows == undefined ? 1 : event.rows) ;
    this.limit = event.rows == undefined ? 10 : event.rows;
    await this.loadDataWithFilter(event);
    this.totalRecords = this.count;
  }

  viewClaimRequest(id: number) {
    console.log(id);

    const requestId: string = encodeURIComponent('id?%' + id);
    this.router.navigate([
      '/dashboard/asp-management/view-claim-request/' + requestId], { queryParams: { navigate: 0, action: false } }
    );
  }

  assignClaimRequest(id: number) {
    console.log(id);
    const dialogRef = this.dialog.open(AssignClaimRequestComponent, {
      data: {
        claimRequestId: id,
        token: this.token,
        action: "reAssign"
      },
      disableClose: true,

    });

    dialogRef.afterClosed().subscribe(result => {
      if (result.action != "closed") {
        window.location.reload();
      }
    });

  }

  handleFilter(e, filteredRecordCount) {
    console.log("filteredRecordCount");
    e.preventDefault();
  }

  bulkAssignClaimRequest() {
    if(this.selectedClaimRequests.length!=0){
      const dialogRef = this.dialog.open(AssignClaimRequestComponent, {
        data: {
          claimRequests: this.selectedClaimRequests,
          token: this.token,
          action: "bulkReAssign"
        },
        disableClose: true,
  
      });
  
      dialogRef.afterClosed().subscribe(result => {
        if (result.action != "closed") {
          window.location.reload();
        }
      });
    }
  }

  openApprovalLevelWithRemarkHistoryDialog(element: number) {
    this.dialogRef = this.dialog.open(ApprovalRemakHistoryComponent, {
      width: '600px',
      height: '600px',
      data: element
    });
  }

  async advanceSearch() {
    this.dataSource = new MatTableDataSource<Claims>([]);
    const paylaod = {
      policyNumber: this.advanceSearchForm.value.policyNu,
      claimRequestNumber: this.advanceSearchForm.value.claimRequestNu,
    }
    const advanceSearchResponse: any = await this.searchClaimRequest(paylaod).catch((error) => {
      console.log(error);
    });
    console.log(advanceSearchResponse);
    if (advanceSearchResponse.status == 200) {
      this.dataSource = new MatTableDataSource<Claims>(advanceSearchResponse.payload.object);
      this.count = advanceSearchResponse.payload.count;
      this.length = this.count;
    }

  }

  activateAdvaceSearch() {
    switch (this.isEnableAdvanceSearch) {
      case true:
        this.isEnableAdvanceSearch = false;
        this.advanceSearchForm.reset();
        // this.loadData();
        break;
      case false:
        this.isEnableAdvanceSearch = true;
        break;

      default:
        break;
    }

    console.log(this.isEnableAdvanceSearch);

  }

  async getClaimDashboard(paylaod: any) {
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimRequestList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getClaimDashboardWithFilter(paylaod: any) {
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getAllClaimRequestList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async searchClaimRequest(paylaod: any) {
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .searchClaimRequest(this.token, paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getClaimList() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getAssignableUsers(isBulk:boolean) {
    let paylaod ={}
    paylaod = {
      token: this.token
    }
    
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getAssigneeUserList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
