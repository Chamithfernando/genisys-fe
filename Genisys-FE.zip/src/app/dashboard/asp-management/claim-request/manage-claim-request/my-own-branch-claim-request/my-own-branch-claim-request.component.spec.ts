import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyOwnBranchClaimRequestComponent } from './my-own-branch-claim-request.component';

describe('MyOwnBranchClaimRequestComponent', () => {
  let component: MyOwnBranchClaimRequestComponent;
  let fixture: ComponentFixture<MyOwnBranchClaimRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyOwnBranchClaimRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MyOwnBranchClaimRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
