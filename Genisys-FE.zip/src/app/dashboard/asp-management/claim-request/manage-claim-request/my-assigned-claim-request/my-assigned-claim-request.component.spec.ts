import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyAssignedClaimRequestComponent } from './my-assigned-claim-request.component';

describe('MyAssignedClaimRequestComponent', () => {
  let component: MyAssignedClaimRequestComponent;
  let fixture: ComponentFixture<MyAssignedClaimRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyAssignedClaimRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MyAssignedClaimRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
