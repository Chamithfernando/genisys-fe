import { Component, Input, ViewChild } from '@angular/core';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { AspModuleService } from '@app/shared/services/asp-module/asp-module.service';
import { AuthService } from '@app/shared/services/auth/auth.service';
import { ClaimRequestComponent } from '../../claim-request.component';
import { AssignClaimRequestComponent } from '../assign-claim-request/assign-claim-request.component';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

export interface Claims {
  id:number;
  requestNumber: string;
  policyNumber: string;
  claimNumber:string;
  claimantName: string;
  branchName:string
  claimType: string;
  submittedDate:string
  requestStatus: string;
}

@Component({
  selector: 'app-settlement-claim-request',
  templateUrl: './settlement-claim-request.component.html',
  styleUrls: ['./settlement-claim-request.component.scss']
})
export class SettlementClaimRequestComponent {
  token: any;
  userRole:any;
  dataSource = new MatTableDataSource([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  displayedColumns = ['requestNumber', 'policyNumber','claimNumber', 'claimantName', 'branchName', 'claimType','submittedDate','assignedUser', 'requestStatus',  'action'];
  @ViewChild('busTbSort') busTbSort = new MatSort();
  @Input() details: any;
  limit: number = 10;
  offset: number = 0;
  count: any;
  length = 100;
  pageSize = 10;
  pageSizeOptions: number[] = [10, 50, 100, 200];

  pageEvent: PageEvent;

  constructor(
    private aspServiceService: AspModuleService,
    private authService: AuthService,
    private router: Router,
    public dialog: MatDialog,
  ){
    this.token = this.authService.getCurrentUserDetails().access_token;
    console.log(this.authService.getCurrentUserDetails())
    this.userRole=localStorage.getItem('ASPUserRoleId');
    this.loadData();
    

  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  async loadData(){
    const request = {
      token: this.token,
      data:{
        limit: this.limit,
        offset: this.offset,
        userServiceId:0,
        departmentId:1,
        status:1
      }
      
    }
    const claimDashboardResponse: any = await this.getSettlementClaimRequestList(request).catch((error) => {
      console.log(error);
    });
    console.log(claimDashboardResponse);
    if (claimDashboardResponse.status == 200) {
      this.dataSource = new MatTableDataSource<Claims>(claimDashboardResponse.payload.object);
      this.count = claimDashboardResponse.payload.count;
      this.length = this.count;
       
    }
  }

  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput
        .split(',')
        .map((str) => +str);
    }
  }

  data($event) {
    this.length = this.count;
    this.limit = $event.pageSize;
    this.offset = $event.pageIndex;
    this.loadData();
    return $event;
  }

  viewClaimRequest(id:number){
    console.log(id);
    
    const requestId: string = encodeURIComponent('id?%'+id);
    this.router.navigate([
      '/dashboard/asp-management/view-claim-request/'+requestId],{ queryParams: { navigate: 0,action:false }}
    );
  }

  assignClaimRequest(id:number){
    console.log(id);
    const dialogRef = this.dialog.open(AssignClaimRequestComponent, {
      data: {
        claimRequestId: id,
        token:this.token,
        action:"new"
      },
      disableClose: true,

    });

    dialogRef.afterClosed().subscribe(result => {
      if(result.action!="closed"){
        window.location.reload();
      }
    });
    
  }

  async getSettlementClaimRequestList(paylaod:any) {
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getSettlementClaimRequestList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
