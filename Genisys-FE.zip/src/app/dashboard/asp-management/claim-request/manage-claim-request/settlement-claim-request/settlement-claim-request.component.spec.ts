import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SettlementClaimRequestComponent } from './settlement-claim-request.component';

describe('SettlementClaimRequestComponent', () => {
  let component: SettlementClaimRequestComponent;
  let fixture: ComponentFixture<SettlementClaimRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SettlementClaimRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SettlementClaimRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
