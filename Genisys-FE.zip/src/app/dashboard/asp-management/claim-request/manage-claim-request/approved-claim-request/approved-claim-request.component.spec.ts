import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApprovedClaimRequestComponent } from './approved-claim-request.component';

describe('ApprovedClaimRequestComponent', () => {
  let component: ApprovedClaimRequestComponent;
  let fixture: ComponentFixture<ApprovedClaimRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApprovedClaimRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ApprovedClaimRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
