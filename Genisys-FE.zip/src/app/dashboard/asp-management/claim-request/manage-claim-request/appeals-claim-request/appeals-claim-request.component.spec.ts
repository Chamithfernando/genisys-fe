import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppealsClaimRequestComponent } from './appeals-claim-request.component';

describe('AppealsClaimRequestComponent', () => {
  let component: AppealsClaimRequestComponent;
  let fixture: ComponentFixture<AppealsClaimRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AppealsClaimRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AppealsClaimRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
