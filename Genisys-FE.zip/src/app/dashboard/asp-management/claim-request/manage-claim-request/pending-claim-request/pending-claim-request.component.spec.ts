import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingClaimRequestComponent } from './pending-claim-request.component';

describe('PendingClaimRequestComponent', () => {
  let component: PendingClaimRequestComponent;
  let fixture: ComponentFixture<PendingClaimRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PendingClaimRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PendingClaimRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
