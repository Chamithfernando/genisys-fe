import { Component, Input, ViewChild } from '@angular/core';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { AspModuleService } from '@app/shared/services/asp-module/asp-module.service';
import { AuthService } from '@app/shared/services/auth/auth.service';
import { ClaimRequestComponent } from '../../claim-request.component';
import { AssignClaimRequestComponent } from '../assign-claim-request/assign-claim-request.component';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { LazyLoadEvent } from 'primeng/api';

export interface Claims {
  id: number;
  requestNumber: string;
  policyNumber: string;
  claimNumber: string;
  claimantName: string;
  branchName: string
  claimType: string;
  submittedDate: string
  requestStatus: string;
}

export interface FilterChildren {
  value: string,
  matchMode: string,
  column: string
}
const FILTER_DATA: FilterChildren[] = [
];

@Component({
  selector: 'app-pending-claim-request',
  templateUrl: './pending-claim-request.component.html',
  styleUrls: ['./pending-claim-request.component.scss']
})
export class PendingClaimRequestComponent {
  token: any;
  userRole: any;
  dataSource = new MatTableDataSource([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  displayedColumns = ['requestNumber', 'policyNumber', 'claimNumber', 'claimantName', 'branchName', 'claimType', 'submittedDate', 'requestStatus', 'action'];
  @ViewChild('busTbSort') busTbSort = new MatSort();
  @Input() details: any;
  limit: number = 10;
  offset: number = 0;
  count: any;
  length = 100;
  pageSize = 10;
  pageSizeOptions: number[] = [10, 50, 100, 200];

  pageEvent: PageEvent;
  claimRequests: Claims[];
  cols: any[];
  exportName: string;
  totalRecords = 0;
  first = 0;
  rows = 10;
  matchModeOptions = [];
  loadingEvent: LazyLoadEvent;

  filters = [...FILTER_DATA];
  searchText = new FormControl('');

  constructor(
    private aspServiceService: AspModuleService,
    private authService: AuthService,
    private router: Router,
    public dialog: MatDialog,
  ) {
    this.token = this.authService.getCurrentUserDetails().access_token;
    console.log(this.authService.getCurrentUserDetails())
    this.userRole = localStorage.getItem('ASPUserRoleId');
    // this.loadData();


  }

  async loadLazyData(event: LazyLoadEvent) {
    this.filters = [];
    console.log(event)
    this.offset = (event.first === 0 || event.first == undefined) ? 0 : event.first / (event.rows == undefined ? 1 : event.rows);
    this.limit = event.rows == undefined ? 10 : event.rows;
    await this.loadDataWithFilter(event);
    this.totalRecords = this.count;
  }

  convertToCapitalized(value: string): string {
    if (!value) return ''; 
    value = value.toLowerCase(); 
    return value.charAt(0).toUpperCase() + value.slice(1); 
  }

  async loadDataWithFilter(event: LazyLoadEvent) {
    this.filters = [];

    const request = {
      token: this.token,
      limit: this.limit,
      offset: this.offset,
      sortField: event.sortField ? event.sortField : '',
      sortOrder: event.sortOrder === 1 ? 'ASC' : 'DESC'

    }
    const claimDashboardResponse: any = await this.getPendingClaimRequestList(request).catch((error) => {
      console.log(error);
    });
    console.log(claimDashboardResponse);
    if (claimDashboardResponse.status == 200) {
      this.dataSource = new MatTableDataSource<Claims>(claimDashboardResponse.payload.object);
      this.claimRequests = claimDashboardResponse.payload.object;
      this.count = claimDashboardResponse.payload.count;
      this.length = this.count;

    }

  }

  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput
        .split(',')
        .map((str) => +str);
    }
  }

  getStatusColor(status) {
    switch (status) {
      case 'Rejected':
        return 'danger';
      case 'Rejected - Call Center Updated':
        return 'danger';
      case 'Rejected - Call Center  Assign':
        return 'danger';

      case 'Approved':
        return 'success';

      case 'Approved - Call Center Updated':
        return 'success';

      case 'Approved - Call Center Assign':
        return 'success';

      case 'Assigned':
        return 'info';

      case 'Pending':
        return 'warning';

      case 'Pending-Call Center Updated':
        return 'warning';

      case 'Pending-Call Center Assign':
        return 'warning';

      case 'Returned':
        return 'danger';

      default:
        return null;
    }
  }

  viewClaimRequest(id: number) {
    console.log(id);

    const requestId: string = encodeURIComponent('id?%' + id);
    this.router.navigate([
      '/dashboard/asp-management/view-claim-request/' + requestId], { queryParams: { navigate: 0, action: false } }
    );
  }

  assignClaimRequest(id: number) {
    console.log(id);
    const dialogRef = this.dialog.open(AssignClaimRequestComponent, {
      data: {
        claimRequestId: id,
        token: this.token,
        action: "reAssign"
      },
      disableClose: true,

    });

    dialogRef.afterClosed().subscribe(result => {
      if(result.action!="closed"){
        window.location.reload();
      }
    });

  }

  async getPendingClaimRequestList(paylaod: any) {
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getPendingClaimRequestList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
}
