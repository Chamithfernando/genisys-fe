import { Component, Input, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { AspModuleService } from '@app/shared/services/asp-module/asp-module.service';
import { AuthService } from '@app/shared/services/auth/auth.service';
import { ApprovalRemakHistoryComponent } from '../../approval-remak-history/approval-remak-history.component';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AssignClaimRequestComponent } from '../assign-claim-request/assign-claim-request.component';
import { LazyLoadEvent } from 'primeng/api';


export interface Claims {
  id: number;
  requestNumber: string;
  policyNumber: string;
  claimNumber: string;
  claimantName: string;
  branchName: string
  claimType: string;
  submittedDate: string
  requestStatus: string;
}
export interface FilterChildren {
  value: string,
  matchMode: string,
  column: string
}
const FILTER_DATA: FilterChildren[] = [
];
@Component({
  selector: 'app-finance-all-claim-request',
  templateUrl: './finance-all-claim-request.component.html',
  styleUrls: ['./finance-all-claim-request.component.scss']
})
export class FinanceAllClaimRequestComponent {
  token: any;
  userRole: any;
  dataSource = new MatTableDataSource([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  displayedColumns = ['requestNumber', 'policyNumber', 'claimNumber', 'claimantName', 'branchName', 'claimType', 'submittedDate', 'requestStatus', 'action'];
  @ViewChild('busTbSort') busTbSort = new MatSort();
  @Input() details: any;
  limit: number = 10;
  offset: number = 0;
  count: any;
  length = 100;
  pageSize = 10;
  totalRecords = 0;
  first = 0;
  rows = 10;
  pageSizeOptions: number[] = [10, 50, 100, 200];
  advanceSearchForm: FormGroup;
  dialogRef: MatDialogRef<any>;

  pageEvent: PageEvent;
    loadingEvent: LazyLoadEvent;
  
    filters = [...FILTER_DATA];
      claimRequests: Claims[];

  isEnableAdvanceSearch: boolean = false;

  constructor(
    private aspServiceService: AspModuleService,
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private dialog: MatDialog,
  ) {
    this.token = this.authService.getCurrentUserDetails().access_token;
    this.advanceSearchForm = formBuilder.group({
      policyNu: [''],
      claimRequestNu: [''],
    });
    this.userRole = localStorage.getItem('ASPUserRoleId');
  }

  async loadLazyData(event: LazyLoadEvent) {
    this.filters = [];
    console.log(event)
    this.offset = (event.first === 0 || event.first == undefined) ? 0 : event.first / (event.rows == undefined ? 1 : event.rows);
    this.limit = event.rows == undefined ? 10 : event.rows;
    await this.loadDataWithFilter(event);
    this.totalRecords = this.count;
  }

  convertToCapitalized(value: string): string {
    if (!value) return '';
    value = value.toLowerCase();
    return value.charAt(0).toUpperCase() + value.slice(1);
  }

  async loadDataWithFilter(event: LazyLoadEvent) {
    this.filters = [];

    const request = {
      token: this.token,
      limit: this.limit,
      offset: this.offset,
      sortField: event.sortField ? event.sortField : '',
      sortOrder: event.sortOrder === 1 ? 'ASC' : 'DESC'
    }
    const claimDashboardResponse: any = await this.getClaimDashboard(request).catch((error) => {
      console.log(error);
    });
    console.log(claimDashboardResponse);
    if (claimDashboardResponse.status == 200) {
      this.dataSource = new MatTableDataSource<Claims>(claimDashboardResponse.payload.object);
      this.claimRequests = claimDashboardResponse.payload.object;
      this.count = claimDashboardResponse.payload.count;
      this.length = this.count;

    }

  }

  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput
        .split(',')
        .map((str) => +str);
    }
  }

  getStatusColor(status) {
    switch (status) {
      case 'Rejected':
        return 'danger';
      case 'Rejected - Call Center Updated':
        return 'danger';
      case 'Rejected - Call Center  Assign':
        return 'danger';

      case 'Approved':
        return 'success';

      case 'Approved - Call Center Updated':
        return 'success';

      case 'Approved - Call Center Assign':
        return 'success';

      case 'Assigned':
        return 'info';

      case 'Pending':
        return 'warning';

      case 'Pending-Call Center Updated':
        return 'warning';

      case 'Pending-Call Center Assign':
        return 'warning';

      case 'Returned':
        return 'danger';

      default:
        return null;
    }
  }

  assignClaimRequest(id: number) {
    console.log(id);
    const dialogRef = this.dialog.open(AssignClaimRequestComponent, {
      data: {
        claimRequestId: id,
        token: this.token,
        action: "reAssign"
      },
      disableClose: true,

    });

    dialogRef.afterClosed().subscribe(result => {
      if (result.action != "closed") {
        window.location.reload();
      }
    });

  }

  viewClaimRequest(id: number) {
    console.log(id);

    const requestId: string = encodeURIComponent('id?%' + id);
    this.router.navigate([
      '/dashboard/asp-management/view-claim-request/' + requestId], { queryParams: { navigate: 0, action: false } }
    );
  }

  openApprovalLevelWithRemarkHistoryDialog(element: number) {
    this.dialogRef = this.dialog.open(ApprovalRemakHistoryComponent, {
      width: '600px',
      height: '600px',
      data: element
    });
  }

  async advanceSearch() {
    this.dataSource = new MatTableDataSource<Claims>([]);
    const paylaod = {
      policyNumber: this.advanceSearchForm.value.policyNu,
      claimRequestNumber: this.advanceSearchForm.value.claimRequestNu,
    }
    const advanceSearchResponse: any = await this.searchClaimRequest(paylaod).catch((error) => {
      console.log(error);
    });
    console.log(advanceSearchResponse);
    if (advanceSearchResponse.status == 200) {
      this.dataSource = new MatTableDataSource<Claims>(advanceSearchResponse.payload.object);
      this.count = advanceSearchResponse.payload.count;
      this.length = this.count;
    }

  }

  activateAdvaceSearch() {
    switch (this.isEnableAdvanceSearch) {
      case true:
        this.isEnableAdvanceSearch = false;
        this.advanceSearchForm.reset();
        // this.loadData();
        break;
      case false:
        this.isEnableAdvanceSearch = true;
        break;

      default:
        break;
    }

    console.log(this.isEnableAdvanceSearch);

  }

  async getClaimDashboard(paylaod: any) {
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimRequestListFinance(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async searchClaimRequest(paylaod: any) {
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .searchClaimRequest(this.token, paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
