import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FinanceAllClaimRequestComponent } from './finance-all-claim-request.component';

describe('FinanceAllClaimRequestComponent', () => {
  let component: FinanceAllClaimRequestComponent;
  let fixture: ComponentFixture<FinanceAllClaimRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FinanceAllClaimRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FinanceAllClaimRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
