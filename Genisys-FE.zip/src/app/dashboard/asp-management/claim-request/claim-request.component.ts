import { Component, ElementRef, Injector, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { AspModuleService } from '@app/shared/services/asp-module/asp-module.service';
import { AuthService } from '@app/shared/services/auth/auth.service';
import { MyClaimRequestComponent } from './manage-claim-request/my-claim-request/my-claim-request.component';
import { MyOwnBranchClaimRequestComponent } from './manage-claim-request/my-own-branch-claim-request/my-own-branch-claim-request.component';
import { title } from 'process';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import Chart from "chart.js/auto"


export interface PermissionComponent {
  id: number;
  name: string;
  status: number;
}

export interface TabName {
  name: string;
  displayName: string;
  data: any;
}

export interface Claims {
  id: number;
  requestNumber: string;
  policyNumber: string;
  claimantName: string;
  hospitalName: string;
  claimType: string;
  remark: string;
  requestStatus: string;
}

@Component({
  selector: 'app-claim-request',
  templateUrl: './claim-request.component.html',
  styleUrls: ['./claim-request.component.scss']
})
export class ClaimRequestComponent implements OnInit {

  token: any;
  userRoleId: number;
  EnableTabList: boolean = false;
  yearlyOperationUserBarData: any;
  yearlyCallCenterUserBarData: any;
  monthlyOperationUserBarData: any;
  monthlyCallCenterUserBarData: any;
  yearlyOperationDeaprtmentBarData: any;
  yearlyCallCenterDepartmentBarData: any;
  monthlyOperationDeaprtmentBarData: any;
  monthlyCallCenterDepartmentBarData: any;
  zonewiseYearlyBarData: any;
  zonewiseMonthlyBarData: any;
  commonChartOptions: any;
  yearlyChartOptions: any;
  monthlyChartOptions: any;
  zonewiseCommonChartOptions: any;
  zonewiseMonthlyChartOptions: any;
  zonewiseYearlyChartOptions: any;
  doughnutData: any;
  dougnutOptions: any;
  activeTabIndex = 0;
  yearlyCenterTextPlugin: any;
  monthlyCenterTextPlugin: any;
  hovered: boolean = false;
  chartInstance: any;
  loading: boolean = false;
  selectedOption = "My Claims";
  assignedCount: number;


  userAllowedPermissionList: PermissionComponent[] = [];
  myClaimrequestTab: string = 'MY_REQUEST';
  myownBrnachClaimTab: string = 'CLAIM_OWN_BRANCH';
  myAssignedClaimRequestTab: string = 'CLAIM_ASSIGNED_TO_ME';
  allClaimRequestTab: string = 'CLAIM_ALL';
  pendingClaimRequestTab: string = 'PENDING_REQUEST';
  intimationClaimRequestTab: string = 'INTIMATION_REQUEST';
  appealClaimRequestTab: string = 'APPEAL_REQUEST';
  rejectionClaimRequestTab: string = 'REJECTION_REQUEST';
  settlementClaimRequestTab: string = 'SETTLEMENT_REQUEST';
  approvedClaimRequestTab: string = 'APPROVED_REQUEST';
  createNewClaimRequest: string = 'CREATE_NEW_CLAIM_REQUEST';
  financeAll: string = 'FINANCE_ALL';
  operationStats: string = 'OPERATION_STATS';
  callcenterStats: string = 'CALL_CENTER_STATS'

  tabNameList: TabName[] = [
    {
      name: "MY_REQUEST",
      displayName: "My Requests",
      data: 'Data for Child 1'
    },
    {
      name: "CLAIM_OWN_BRANCH",
      displayName: "Branch All Requests",
      data: 'Data for Child 2'
    },
    {
      name: "CLAIM_ASSIGNED_TO_ME",
      displayName: "Assigned Requests",
      data: 'Data for Child 3'
    },
    {
      name: "CLAIM_ALL",
      displayName: "All Requests",
      data: 'Data for Child 4'
    },
    {
      name: "PENDING_REQUEST",
      displayName: "Pendings",
      data: 'Data for Child 5'
    },
    {
      name: "INTIMATION_REQUEST",
      displayName: "Intimations",
      data: 'Data for Child 6'
    },
    {
      name: "APPEAL_REQUEST",
      displayName: "Appeals",
      data: 'Data for Child 7'
    },
    {
      name: "REJECTION_REQUEST",
      displayName: "Rejections",
      data: 'Data for Child 8'
    },
    {
      name: "SETTLEMENT_REQUEST",
      displayName: "Settlement",
      data: 'Data for Child 9'
    },
    {
      name: "FINANCE_ALL",
      displayName: "All Requests",
      data: 'Data for Child 10'
    },
    {
      name: "APPROVED_REQUEST",
      displayName: "Approvals",
      data: 'Data for Child 9'
    },
  ];

  userAllowedTabList: TabName[] = [];




  constructor(
    private aspServiceService: AspModuleService,
    private authService: AuthService,
    private router: Router,
  ) {
    Chart.register(ChartDataLabels);
    this.token = this.authService.getCurrentUserDetails().access_token;

  }
  async ngOnInit() {
    this.loading = true;
    await this.loadUserPermission();
    if (!this.isBranchUser) {
      this.initCharts();
      await this.fetchChartData();
      await this.fetchAssignedCount();
    }
  }

  async onTypeChange() {
    this.loading = true;
    await this.fetchChartData();
  }

  async fetchChartData() {
    if (this.ifUserHasOperationStatsPermission && this.selectedOption == 'My Claims') {
      const portalStatsResponse: any = await this.getOperationStats().catch((error) => {
        console.log(error);
      });
      if (portalStatsResponse.status == 200) {
        this.updateOperationUserChartData(portalStatsResponse.payload);
      }
    } else if (this.ifUserHasCallCenterStatsPermission && this.selectedOption == 'My Claims') {
      const portalStatsResponse: any = await this.getCallCenterStats().catch((error) => {
        console.log(error);
      });
      if (portalStatsResponse.status == 200) {
        this.updateCallCenterUserChartData(portalStatsResponse.payload);
      }
    } else if (this.ifUserHasOperationStatsPermission && this.selectedOption == 'Zone Wise') {
      const portalStatsResponse: any = await this.getZoneStats().catch((error) => {
        console.log(error);
      });
      console.log(portalStatsResponse)
      if (portalStatsResponse.status == 200) {
        this.updateZoneWiseChartData(portalStatsResponse.payload);
      }
    } else if (this.ifUserHasOperationStatsPermission && this.selectedOption == 'Department') {
      const portalStatsResponse: any = await this.getDepartmentStats().catch((error) => {
        console.log(error);
      });
      if (portalStatsResponse.status == 200) {
        this.updateOperationDepartmentChartData(portalStatsResponse.payload);
      }
    } else if (this.ifUserHasCallCenterStatsPermission && this.selectedOption == 'Department') {
      const portalStatsResponse: any = await this.getDepartmentStats().catch((error) => {
        console.log(error);
      });
      if (portalStatsResponse.status == 200) {
        this.updateCallCenterDepartmentChartData(portalStatsResponse.payload);
      }
    }

  }

  async fetchAssignedCount() {
    const assignedResponse: any = await this.getAssignedJobsCount().catch((error) => {
      console.log(error);
    });
    if (assignedResponse.status == 200) {
      this.assignedCount = assignedResponse.payload;
    }
  }
  // backgroundColor: [
  //   'rgb(0, 17, 34)',
  //   'rgb(0, 29, 58)',
  //   'rgb(5, 43, 77)',
  //   'rgb(9, 64, 113)',
  //   'rgb(50, 90, 130)',
  //   'rgb(100, 150, 200)'],
  // hoverBackgroundColor: [
  //   'rgb(19, 44, 66)',
  //   'rgb(23, 45, 65)',
  //   'rgb(30, 61, 88)',
  //   'rgb(36, 81, 121)',
  //   'rgb(151, 189, 223)',
  //   'rgb(173, 187, 199)']
  updateOperationUserChartData(response: any) {
    this.yearlyOperationUserBarData = {
      labels: ['Assigned', 'Pending', 'In progress', 'Approved', 'Rejected', 'Paid', 'Returned'],
      datasets: [
        {
          data: response.yearlyCount,
          backgroundColor: [
            'rgb(0, 17, 34)',
            'rgb(18,43,84)',
            'rgb(0,55,129)',
            'rgb(0,97,146)',
            'rgb(19,160,211)',
            'rgb(101, 196, 228)',
            'rgb(161, 225, 247)'
          ],
          hoverBackgroundColor: [
            'rgb(19, 44, 66)',
            'rgb(23, 45, 65)',
            'rgb(30, 61, 88)',
            'rgb(36, 81, 121)',
            'rgb(151, 189, 223)',
            'rgb(173, 187, 199)',
            'rgb(161, 225, 247)']
        }
      ]
    };

    this.monthlyOperationUserBarData = {
      labels: ['Assigned', 'Pending', 'In progress', 'Approved', 'Rejected', 'Paid', 'Returned'],
      datasets: [
        {
          // data: [50, 320, 60, 240, 130,120],
          data: response.monthlyCount,
          backgroundColor: [
            'rgb(0, 17, 34)',
            'rgb(18,43,84)',
            'rgb(0,55,129)',
            'rgb(0,97,146)',
            'rgb(19,160,211)',
            'rgb(101, 196, 228)',
            'rgb(161, 225, 247)'],
          hoverBackgroundColor: [
            'rgb(19, 44, 66)',
            'rgb(23, 45, 65)',
            'rgb(30, 61, 88)',
            'rgb(36, 81, 121)',
            'rgb(151, 189, 223)',
            'rgb(173, 187, 199)',
            'rgb(161, 225, 247)']
        }
      ]
    };
    this.loading = false;
  }

  updateOperationDepartmentChartData(response: any) {
    this.yearlyOperationDeaprtmentBarData = {
      labels: ['Assigned', 'Pending', 'In progress', 'Approved', 'Rejected', 'Paid', 'Returned'],
      datasets: [
        {
          data: response.yearlyCount,
          backgroundColor: [
            'rgb(0, 17, 34)',
            'rgb(18,43,84)',
            'rgb(0,55,129)',
            'rgb(0,97,146)',
            'rgb(19,160,211)',
            'rgb(101, 196, 228)',
            'rgb(161, 225, 247)'],
          hoverBackgroundColor: [
            'rgb(19, 44, 66)',
            'rgb(23, 45, 65)',
            'rgb(30, 61, 88)',
            'rgb(36, 81, 121)',
            'rgb(151, 189, 223)',
            'rgb(173, 187, 199)',
            'rgb(161, 225, 247)']
        }
      ]
    };

    this.monthlyOperationDeaprtmentBarData = {
      labels: ['Assigned', 'Pending', 'In progress', 'Approved', 'Rejected', 'Paid', 'Returned'],
      datasets: [
        {
          // data: [50, 320, 60, 240, 130,120],
          data: response.monthlyCount,
          backgroundColor: [
            'rgb(0, 17, 34)',
            'rgb(18,43,84)',
            'rgb(0,55,129)',
            'rgb(0,97,146)',
            'rgb(19,160,211)',
            'rgb(101, 196, 228)',
            'rgb(161, 225, 247)'],
          hoverBackgroundColor: [
            'rgb(19, 44, 66)',
            'rgb(23, 45, 65)',
            'rgb(30, 61, 88)',
            'rgb(36, 81, 121)',
            'rgb(151, 189, 223)',
            'rgb(173, 187, 199)',
            'rgb(161, 225, 247)']
        }
      ]
    };
    this.loading = false;
  }

  updateZoneWiseChartData(response: any) {

    this.zonewiseYearlyBarData = {
      labels: response.zoneAndStatusWiseClaimYearlyCountDto.zoneList,
      datasets: [
        {
          type: 'bar',
          label: 'Updated',
          backgroundColor: 'rgb(0, 17, 34)',
          data: response.zoneAndStatusWiseClaimYearlyCountDto.updatedStatusCount
        },
        {
          type: 'bar',
          label: 'Pending',
          backgroundColor: 'rgb(18,43,84)',
          data: response.zoneAndStatusWiseClaimYearlyCountDto.pendingStatusCount
        },
        {
          type: 'bar',
          label: 'Approved',
          backgroundColor: 'rgb(0,55,129)',
          data: response.zoneAndStatusWiseClaimYearlyCountDto.approvedStatusCount
        },
        {
          type: 'bar',
          label: 'Rejected',
          backgroundColor: 'rgb(0,97,146)',
          data: response.zoneAndStatusWiseClaimYearlyCountDto.rejectedStatusCount
        },
        {
          type: 'bar',
          label: 'In progress',
          backgroundColor: 'rgb(19,160,211)',
          data: response.zoneAndStatusWiseClaimYearlyCountDto.inProgressStatusCount
        },
        {
          type: 'bar',
          label: 'Paid',
          backgroundColor: 'rgb(101, 196, 228)',
          data: response.zoneAndStatusWiseClaimYearlyCountDto.paidStatusCount
        },
        {
          type: 'bar',
          label: 'Returned',
          backgroundColor: 'rgb(161, 225, 247)',
          data: response.zoneAndStatusWiseClaimYearlyCountDto.returnStatusCount
        }
      ],

    };

    this.zonewiseMonthlyBarData = {
      labels: response.claimStatusAndZoneWiseMonthlyClaimCountDto.zoneList,
      datasets: [
        {
          type: 'bar',
          label: 'Updated',
          backgroundColor: 'rgb(0, 17, 34)',
          data: response.claimStatusAndZoneWiseMonthlyClaimCountDto.updatedStatusCount
        },
        {
          type: 'bar',
          label: 'Pending',
          backgroundColor: 'rgb(18,43,84)',
          data: response.claimStatusAndZoneWiseMonthlyClaimCountDto.pendingStatusCount
        },
        {
          type: 'bar',
          label: 'Approved',
          backgroundColor: 'rgb(0,55,129)',
          data: response.claimStatusAndZoneWiseMonthlyClaimCountDto.approvedStatusCount
        },
        {
          type: 'bar',
          label: 'Rejected',
          backgroundColor: 'rgb(0,97,146)',
          data: response.claimStatusAndZoneWiseMonthlyClaimCountDto.rejectedStatusCount
        },
        {
          type: 'bar',
          label: 'In progress',
          backgroundColor: 'rgb(19,160,211)',
          data: response.claimStatusAndZoneWiseMonthlyClaimCountDto.inProgressStatusCount
        },
        {
          type: 'bar',
          label: 'Paid',
          backgroundColor: 'rgb(101, 196, 228)',
          data: response.claimStatusAndZoneWiseMonthlyClaimCountDto.paidStatusCount
        },
        {
          type: 'bar',
          label: 'Returned',
          backgroundColor: 'rgb(161, 225, 247)',
          data: response.claimStatusAndZoneWiseMonthlyClaimCountDto.returnStatusCount
        }
      ]
    };
    this.loading = false;
  }

  updateCallCenterUserChartData(response: any) {

    this.yearlyCallCenterUserBarData = {
      labels: ['Completed', 'Pending'],
      datasets: [
        {
          data: response.yearlyCount,
          backgroundColor: [
            'rgb(0, 17, 34)',
            'rgb(9, 64, 113)',],
          hoverBackgroundColor: [
            'rgb(19, 44, 66)',
            'rgb(9, 64, 113)',]
        }
      ]
    };

    this.monthlyCallCenterUserBarData = {
      labels: ['Completed', 'Pending'],
      datasets: [
        {
          data: response.monthlyCount,
          backgroundColor: [
            'rgb(0, 17, 34)',
            'rgb(9, 64, 113)',],
          hoverBackgroundColor: [
            'rgb(19, 44, 66)',
            'rgb(9, 64, 113)',]
        }
      ]
    };
    this.loading = false;
  }

  updateCallCenterDepartmentChartData(response: any) {

    this.yearlyCallCenterDepartmentBarData = {
      labels: ['Completed', 'Pending'],
      datasets: [
        {
          data: response.yearlyCount,
          backgroundColor: [
            'rgb(0, 17, 34)',
            'rgb(9, 64, 113)',],
          hoverBackgroundColor: [
            'rgb(19, 44, 66)',
            'rgb(9, 64, 113)',]
        }
      ]
    };

    this.monthlyCallCenterDepartmentBarData = {
      labels: ['Completed', 'Pending'],
      datasets: [
        {
          data: response.monthlyCount,
          backgroundColor: [
            'rgb(0, 17, 34)',
            'rgb(9, 64, 113)',],
          hoverBackgroundColor: [
            'rgb(19, 44, 66)',
            'rgb(9, 64, 113)',]
        }
      ]
    };
    this.loading = false;
  }

  createNewRequest() {
    this.router.navigate([
      '/dashboard/asp-management/create-claim-request']);
  }

  onTabChange(index: number) {
    this.activeTabIndex = index;
  }

  async loadUserPermission() {
    this.EnableTabList = false;
    this.userAllowedTabList = [];
    this.userAllowedPermissionList = [];
    const claimPermissionResponse: any = await this.getAspOnInitFunction().catch((error) => {
      console.log(error);
    });
    console.log(claimPermissionResponse);
    if (claimPermissionResponse.status == 200) {
      const rowComponentList: PermissionComponent[] = claimPermissionResponse.payload.componentList;
      this.userAllowedPermissionList = rowComponentList;
      // Filter Components based on the nameList
      this.userAllowedTabList = this.tabNameList.filter((component) => {
        return rowComponentList.some((nameItem) => nameItem.name === component.name)
      });
      const userRoleId: number = claimPermissionResponse.payload.role.id;
      localStorage.setItem('ASPUserRoleId', userRoleId.toString());
      this.EnableTabList = true;
    } else {
      this.EnableTabList = false;
    }

    console.log(this.userAllowedTabList);

  }

  get ifUserAllowedToCreateNewClaimRequest(): boolean {
    return this.userAllowedPermissionList.some((tab) => tab.name === this.createNewClaimRequest);
  }

  get isBranchUser(): boolean {
    return this.userAllowedPermissionList.some((tab) => tab.name === this.myownBrnachClaimTab);
  }

  get isFinanceUser(): boolean {
    return this.userAllowedPermissionList.some((tab) => tab.name === this.financeAll);
  }

  get ifUserHasOperationStatsPermission(): boolean {
    return this.userAllowedPermissionList.some((tab) => tab.name === this.operationStats);
  }

  get ifUserHasCallCenterStatsPermission(): boolean {
    return this.userAllowedPermissionList.some((tab) => tab.name === this.callcenterStats);
  }

  initCharts() {
    const documentStyle = getComputedStyle(document.documentElement);
    const textColor = documentStyle.getPropertyValue('--text-color');
    const textColorSecondary = documentStyle.getPropertyValue('--text-color-secondary');
    const surfaceBorder = documentStyle.getPropertyValue('--surface-border');

    // this.yearlyBarData = {
    //   labels: ['Assigned', 'Pending', 'Approved', 'Rejected', 'In progress', 'Paid'],
    //   datasets: [
    //     {
    //       data: [300, 50,120, 200, 20, 10],
    //       backgroundColor: [
    //         'rgb(0, 17, 34)',
    //         'rgb(0, 29, 58)',
    //         'rgb(5, 43, 77)',
    //         'rgb(9, 64, 113)',
    //         'rgb(50, 90, 130)',
    //         'rgb(100, 150, 200)'],
    //       hoverBackgroundColor: [
    //         'rgb(19, 44, 66)',
    //         'rgb(23, 45, 65)',
    //         'rgb(30, 61, 88)',
    //         'rgb(36, 81, 121)',
    //         'rgb(151, 189, 223)',
    //         'rgb(173, 187, 199)']
    //     }
    //   ]
    // };



    this.commonChartOptions = {
      maintainAspectRatio: false,
      aspectRatio: 0.8,
      cutout: '50%',
      plugins: {
        legend: {
          labels: {
            color: textColor
          }
        },
        title: {
          display: true,
          font: {
            size: 20
          },
          padding: {
            top: 10,
            bottom: 30
          }
        },
        borderWidth: (ctx) => ctx.raw === 0 ? 0 : 1,
        datalabels: {
          display: true,
          color: '#fff',
          font: {
            size: 16
          },
          formatter: (value: any) => {
            return value;
          }
        }
      }

    };
    this.yearlyChartOptions = {
      ...this.commonChartOptions,
      plugins: {
        ...this.commonChartOptions.plugins,
        title: {
          ...this.commonChartOptions.plugins.title,
          text: 'Current Year Claims'
        }
      }
    }
    this.monthlyChartOptions = {
      ...this.commonChartOptions,
      plugins: {
        ...this.commonChartOptions.plugins,
        title: {
          ...this.commonChartOptions.plugins.title,
          text: 'Current Month Claims'
        }
      }
    }
    this.zonewiseCommonChartOptions = {
      maintainAspectRatio: false,
      aspectRatio: 0.8,
      plugins: {
        datalabels: {  // Enables labels inside bars
          color: 'rgb(235, 235, 235)',  // Sets label text color to white
          anchor: 'center',  // Positions text inside the bar
          align: 'center',   // Centers text within the bar
          font: {
            weight: 'bold',
            size: 10
          }
        },
        tooltips: {
          mode: 'index',
          intersect: false
        },
        legend: {
          labels: {
            color: textColor
          }
        },
        title: {
          display: true,
          font: {
            size: 20
          },
          padding: {
            top: 10,
            bottom: 30
          }
        }
      },
      scales: {
        x: {
          stacked: true,
          ticks: {
            color: textColorSecondary
          },
          grid: {
            color: 'rgba(255, 255, 255, 0.2)', // Optional: Make grid lines faint
            drawBorder: false
          }
        },
        y: {
          stacked: true,
          ticks: {
            color: textColorSecondary
          },
          grid: {
            color: 'rgba(255, 255, 255, 0.2)', // Optional: Make grid lines faint
            drawBorder: false
          }
        }
      }
    }

    this.zonewiseYearlyChartOptions = {
      ...this.zonewiseCommonChartOptions,
      plugins: {
        ...this.zonewiseCommonChartOptions.plugins,
        title: {
          ...this.zonewiseCommonChartOptions.plugins.title,
          text: 'Current Year Claims'
        }
      }
    }

    this.zonewiseMonthlyChartOptions = {
      ...this.zonewiseCommonChartOptions,
      plugins: {
        ...this.zonewiseCommonChartOptions.plugins,
        title: {
          ...this.zonewiseCommonChartOptions.plugins.title,
          text: 'Current Month Claims'
        }
      }
    }
    this.yearlyCenterTextPlugin = {
      id: 'centerTextPlugin',
      beforeDraw: (chart: any) => {
        const { width, height, ctx } = chart;
        let total = 0;
        if (this.ifUserHasOperationStatsPermission && this.selectedOption == 'My Claims') {
          total = this.yearlyOperationUserBarData.datasets[0].data.reduce((a: number, b: number) => a + b, 0);
        } else if (this.ifUserHasCallCenterStatsPermission && this.selectedOption == 'My Claims') {
          total = this.yearlyCallCenterUserBarData.datasets[0].data.reduce((a: number, b: number) => a + b, 0);
        } else if (this.ifUserHasOperationStatsPermission && this.selectedOption == 'Department') {
          total = this.yearlyOperationDeaprtmentBarData.datasets[0].data.reduce((a: number, b: number) => a + b, 0);
        } else if (this.ifUserHasCallCenterStatsPermission && this.selectedOption == 'Department') {
          total = this.yearlyCallCenterDepartmentBarData.datasets[0].data.reduce((a: number, b: number) => a + b, 0);
        }
        const chartArea = chart.chartArea;
        if (!chartArea) return;

        const centerX = (chartArea.left + chartArea.right) / 2;
        const centerY = (chartArea.top + chartArea.bottom) / 2;

        ctx.save();
        ctx.font = `${height / 10}px Arial`;
        ctx.fillStyle = this.hovered ? '#FF5733' : '#000';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(this.hovered ? 'Total: ' + total : total.toString(), centerX, centerY);
        ctx.restore();
      }
    };
    this.monthlyCenterTextPlugin = {
      id: 'centerTextPlugin',
      beforeDraw: (chart: any) => {
        const { width, height, ctx } = chart;
        let total = 0;
        if (this.ifUserHasOperationStatsPermission && this.selectedOption == 'My Claims') {
          total = this.monthlyOperationUserBarData.datasets[0].data.reduce((a: number, b: number) => a + b, 0);
        } else if (this.ifUserHasCallCenterStatsPermission && this.selectedOption == 'My Claims') {
          total = this.monthlyCallCenterUserBarData.datasets[0].data.reduce((a: number, b: number) => a + b, 0);
        } else if (this.ifUserHasOperationStatsPermission && this.selectedOption == 'Department') {
          total = this.monthlyOperationDeaprtmentBarData.datasets[0].data.reduce((a: number, b: number) => a + b, 0);
        } else if (this.ifUserHasCallCenterStatsPermission && this.selectedOption == 'Department') {
          total = this.monthlyCallCenterDepartmentBarData.datasets[0].data.reduce((a: number, b: number) => a + b, 0);
        }
        const chartArea = chart.chartArea;
        if (!chartArea) return;

        const centerX = (chartArea.left + chartArea.right) / 2;
        const centerY = (chartArea.top + chartArea.bottom) / 2;

        ctx.save();
        ctx.font = `${height / 10}px Arial`;
        ctx.fillStyle = this.hovered ? '#FF5733' : '#000';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(this.hovered ? 'Total: ' + total : total.toString(), centerX, centerY);
        ctx.restore();
      }
    };

  }

  viewClaimRequest(id: number) {
    console.log(id);

    const requestId: string = encodeURIComponent('id?%' + id);
    this.router.navigate([
      '/dashboard/asp-management/view-claim-request/' + requestId], { queryParams: { navigate: 0 } }
    );
  }

  editClaimRequest(id: number) {
    const requestId: string = encodeURIComponent('id?%' + id);
    this.router.navigate([
      '/dashboard/asp-management/update-claim-request/' + requestId], { queryParams: { navigateIndex: 0 } }
    );
  }


  async getOperationStats() {
    const payload = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getOperationStats(payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getCallCenterStats() {
    const payload = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getCallCenterStats(payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getDepartmentStats() {
    const payload = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getDepartmentStats(payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getZoneStats() {
    const payload = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getZoneWiseStats(payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getAssignedJobsCount() {
    const payload = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getAssignedJobsCount(payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


  async getAspOnInitFunction() {
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .aspOnInitFunction(this.token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
