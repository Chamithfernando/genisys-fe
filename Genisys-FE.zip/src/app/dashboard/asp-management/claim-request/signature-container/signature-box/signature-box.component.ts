import { Component, ElementRef, HostListener, Input } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { AspModuleService } from '@app/shared/services/asp-module/asp-module.service';
import { AuthService } from '@app/shared/services/auth/auth.service';

@Component({
  selector: 'app-signature-box',
  templateUrl: './signature-box.component.html',
  styleUrls: ['./signature-box.component.scss']
})
export class SignatureBoxComponent {
  @Input() claimRequestId: number;
  token: any;
  signatureVerfication: FormGroup;

  public params: any;
  deliveryMethod: any;
  agree: boolean = false;
  public loading: boolean = false;
  public qaArray: any[] = [];
  panelOpenState = false;
  applicationId: any;

  isEnableSignatureSection: boolean = false;

  isSignatureEmply: boolean = false;

  applicationPanelOpenState = false;
  codeOfConductPanelOpenState = false;
  privacyPanelOpenState = false;
  dueDelligenceOpenState = false;

  scrollEnabled: boolean = false;
  isChecked: boolean = false;

  checked = false;
  indeterminate = false;
  labelPosition: 'before' | 'after' = 'after';
  pdfSrc: any;

  public screenWidth: number;
  public screenHeight: number;

  



  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private snackBar: MatSnackBar,
    private authService: AuthService,
    private aspServiceService: AspModuleService,
    private el: ElementRef
  ) {
    this.token = this.authService.getCurrentUserDetails().access_token;
    this.onResize();
   }

  ngOnInit(): void {
    console.log(this.screenWidth);
  }

  @HostListener('window:resize', ['$event'])
  onResize(event?) {
     this.screenHeight = window.innerHeight;
     this.screenWidth = window.innerWidth;
     console.log(this.screenHeight, this.screenWidth);
  } 
  
  public get year() : string {
    return new Date().getFullYear().toString();
  }
  

  pointChangeEvent(event) {
    if (event.length == 0) {
      this.isSignatureEmply = true;
    } else {
      this.isSignatureEmply = false;
    }
  }

  showImage(data) {

    let signatureImage = data;
    this.timeoutAlert(signatureImage);
  }

  saveSignature(image) {
    const data = {
      claimRequestId: this.claimRequestId,
      base64signature: image
    }
    if (!this.isSignatureEmply) {
      this.aspServiceService.saveSignature(this.token,data)
        .subscribe((response: any) => {

          if (response.status == 200) {
            this.loading = false;
            this.snackBar.open("Signature Added Successfully !", "", {
              duration: 2000,
              panelClass: ['success-snackbar']
            });

            const requestId: string = encodeURIComponent('id?%'+this.claimRequestId);
            this.router.navigate([
              '/base/service-portal/update/'+requestId],  { queryParams: { navigateIndex: 1 }}
            );
            
          }
          else {
            this.loading = false;
            this.snackBar.open("Signature Upload Failed !", "OK", {
              duration: 3000,
              panelClass: ['error-snackbar']
            });
          } 
        });
    } else {
      this.loading = false;
      this.snackBar.open("Signature Upload Failed !, Please Draw Your Signature on Signature Box", "OK", {
        duration: 3000,
        panelClass: ['error-snackbar']
      });
    }

  }

  timeoutAlert(image) {
    setTimeout(() => {
      this.saveSignature(image);
    }, 500);
  }



  
}



