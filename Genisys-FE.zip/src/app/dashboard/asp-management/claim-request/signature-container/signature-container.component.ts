import { Component, HostListener } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '@app/shared/services/api/api.service';
import { AspModuleService } from '@app/shared/services/asp-module/asp-module.service';
import { AuthService } from '@app/shared/services/auth/auth.service';
import Swal from 'sweetalert2';

export enum TYPE {
  ERROR='error',
  SUCCESS='success',
  WARNING='warning',
  INFO='info',
  QUESTION='question'
}

@Component({
  selector: 'app-signature-container',
  templateUrl: './signature-container.component.html',
  styleUrls: ['./signature-container.component.scss']
})
export class SignatureContainerComponent {
  isSignatureEmply: boolean = false;
  token:any;
  otpForm: any;
  loading: boolean = false;
  agent_code: any;
  enable_link: boolean;
  resendAttempt: any;
  resendLoading: boolean;
  routeExtras: any;

  isEnableSignatureOptionOne = false;
  isEnableSignatureOptionTwo = false;
  isEnableCustomerOtpSection = false;
  isEnableSignaturePad = false;

  isCustomerSendLinkAndOtp = false;
  isSelectSmSOptions = true;

  public screenWidth: number

  @HostListener('window:resize', ['$event'])
  onResize(event) {
  this.screenWidth = window.innerWidth;
  } 

  claimRequestId: number;

  constructor(
    private snackBar: MatSnackBar,
    private formBuilder: FormBuilder,
    private aspServiceService: AspModuleService,
    private authService: AuthService,
    private route: ActivatedRoute,
    private router: Router,
  ) { 
    this.token = this.authService.getCurrentUserDetails().access_token;
    this.screenWidth = window.innerWidth;
  }

  ngOnInit() {
   
    const claimRequestUrl : string = this.route.snapshot.params.claimId;
    const name = decodeURIComponent(claimRequestUrl);
    this.claimRequestId = Number(name.split('%').pop());

    console.log(this.claimRequestId);
    

    

    this.initForm();
    this.isEnableSignatureOptionOne = true;
    this.isEnableSignatureOptionTwo = true;

    this.enable_link = true;
    console.log(this.screenWidth);
    
  }

  initForm() {
    this.otpForm = this.formBuilder.group({
      inputOtp: ['',
      Validators.compose([Validators.required, Validators.pattern("^[0-9]*$")]) ],
      
    })
  }

  

  public checkError = (controlName: string, errorName: string) => {
    return this.otpForm.controls[controlName].hasError(errorName);
  }

  
  


  backToClaimRequestUpdate() {
    const requestId: string = encodeURIComponent('id?%'+this.claimRequestId.toString());
    this.router.navigate([
      '/dashboard/asp-management/update-claim-request/'+requestId],{ queryParams: { navigateIndex: 1 }}
    );
  }

  

  async submitOtp() {
    if (this.otpForm.valid) {
      const payload = {
        claimRequestId: this.claimRequestId,
        otp: this.otpForm.value.inputOtp,

      }
      const selectClaimSMSOptionResponse: any = await this.verfiyOtpwithCustomer(payload).catch((error) => {
        console.log(error);
      });
      console.log(selectClaimSMSOptionResponse);
      
      if (selectClaimSMSOptionResponse.payload == true) {
        this.isEnableCustomerOtpSection = false;
        this.isEnableSignaturePad = true;


        this.toast(TYPE.SUCCESS, true, 'Customer Verification Successfull');
      } else {
        const msg = selectClaimSMSOptionResponse.message;
        this.toast(TYPE.WARNING, true, msg);
      }

    } else {
      this.toast(TYPE.WARNING, true, 'Invalid OTP');
    }
  }

  async resendOtp(){
    const payload = {
      claimRequestId: this.claimRequestId,
      isOtpCustomer: true,

    }
    const resendOtpResponse: any = await this.resendOtpwithCustomer(payload).catch((error) => {
      console.log(error);
    });
    if (resendOtpResponse.status == 200) {
      this.toast(TYPE.INFO, true, "Resend OTP Requested "+resendOtpResponse.payload);
    }
  }

  sendSMSToCustomer(){
    Swal.fire({
      title: "Confirmation",
      text: "This action is irreversible and cannot be undone.",
      showCancelButton: true,
      confirmButtonText: "OK",
    }).then(async (result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        
        const payload = {
          claimRequestId: this.claimRequestId,
          customerSignInOptionId: 2
        } 
        const selectClaimSMSOptionResponse: any = await this.selectSignatureOption(payload).catch((error) => {
          console.log(error);
        });
        if (selectClaimSMSOptionResponse.status == 200) {
          this.toast(TYPE.INFO, true, 'Your Customer will receive both link and OTP to place signature');
          this.isSelectSmSOptions = false;
          this.isEnableCustomerOtpSection = true;
          this.isEnableCustomerOtpSection = false;
          this.isEnableSignaturePad = false;

          const payload = {
            isCustomerWithYou: false,
            claimRequestId: this.claimRequestId
          }
          const generateSMSWithPublicLinkResponse: any = await this.generateSMSWithPublicLink(payload).catch((error) => {
            console.log(error);
          });
          if (generateSMSWithPublicLinkResponse.status == 200) {
            console.log(generateSMSWithPublicLinkResponse);

            this.isCustomerSendLinkAndOtp = true;
            
          }
        }

      } 
    });


   
  }



  pointChangeEvent(event) {
    if (event.length == 0) {
      this.isSignatureEmply = true;
    } else {
      this.isSignatureEmply = false;
    }
  }

  toast(typeIcon = TYPE.SUCCESS, timerProgressBar: boolean = false, title: string) {
    Swal.fire({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      icon: typeIcon,
      timerProgressBar,
      timer: 8000,
      title: title
    })
  }

  async selectSignatureOption(payload: any) {
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .selectClaimRequestSignInOption(this.token,payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async generateSMSWithPublicLink(payload: any) {
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .generateSMSwithPublicLink(this.token,payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async verfiyOtpwithCustomer(payload: any) {
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .verifyCustomerOtp(this.token,payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async resendOtpwithCustomer(payload: any) {
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .resendCustomerOtp(this.token,payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
