import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Component, NgZone } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatStepper, StepperOrientation } from '@angular/material/stepper';
import { ActivatedRoute, Router } from '@angular/router';
import { AspModuleService } from '@app/shared/services/asp-module/asp-module.service';
import { AuthService } from '@app/shared/services/auth/auth.service';
import { PopupService } from '@app/shared/services/popup/popup.service';
import moment from 'moment';
import { Observable, Subscription } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { Model, SurveyNG } from 'survey-angular';
import * as Survey from 'survey-angular';
import Swal from 'sweetalert2';
import { log } from 'util';


const creatorOptions = {
  showLogicTab: true,
  isAutoSave: true
};

export interface InsuranceRequirement {
  name: string;
}

export interface type {
  id: number;
  name: string;
}

@Component({
  selector: 'app-create-claim-request',
  templateUrl: './create-claim-request.component.html',
  styleUrls: ['./create-claim-request.component.scss']
})
export class CreateClaimRequestComponent {

  userRoleId: number;
  token: any;
  loading: any;
  unstructuredClaim = 1;
  structuredClaim = 2;
  agentCode: string;
  isEnableFormUploadSection = false;
  isEnableFormUploadSectionDocData = false;
  isEnableDocumentUploadSection = false;
  isEnableDocumentUploadFormSection = false;
  documentData: any;

  documentFormData: any;

  filteredOptions: any;
  isFormSectionCompleted = false;
  isDocumentSectionCompleted = false;

  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  claimRequestForm: FormGroup;
  isDisable: boolean = true;
  admitionDate: string;

  selectedHospitalId: string;
  isDisplayNoEFormMessage: boolean = false

  isVisibleBankBranchNoAvilable: boolean = false

  emailPattern = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$"

  mainTypes: type[] = [
    {
      id: 1,
      name: 'Life'
    },
    {
      id: 2,
      name: 'Group Life'
    }
  ];

  userOptions: type[] = [
    {
      id: 1,
      name: 'Document Upload'
    },
    {
      id: 2,
      name: 'Fill E-Form'
    }
  ];

  claimTypes: any;
  claims: any;
  policyListForClaim: string[] = [];
  hospitalListForClaim: any[] = [];
  activeBankList: any;
  hospitalList: any[] = [];
  branchList: any;
  requiredDocumentTypes:any;

  contactNoPattern = "[0-9]{10}";
  orientation: StepperOrientation = 'horizontal';

  savedClaimRequestId: number;

  generatedClaimRequestNumber: string;

  insuranceRequirements: InsuranceRequirement[] = [
    { name: 'Health' },
    { name: 'Protection' },
    { name: 'Savings' },
    { name: 'Retirement' },
    { name: 'Investment' }
  ];
  claimRequest: FormGroup;
  digitalFormSubscription: Subscription;

  claimfilteredOptions: Observable<any[]>;
  hospitalfilteredOptions: Observable<any[]>;
  isPolicyVerified: boolean = false;

  constructor(
    
    private formBuilder: FormBuilder,
    private _formBuilder: FormBuilder,
    private _ngZone: NgZone,
    private route: Router,
    private _snackBar: MatSnackBar,
    private authService: AuthService,
    private poupService: PopupService,
    private activatedRoute: ActivatedRoute,
    private breakPointObserver: BreakpointObserver,
    private aspServiceService: AspModuleService) {
    breakPointObserver.observe([
      Breakpoints.XSmall,
      Breakpoints.Small
    ]).subscribe(result => {
      this.orientation = 'vertical';
    });

    this.token = this.authService.getCurrentUserDetails().access_token;
    this.agentCode = 'HQ11'

    this.claimRequestForm = _formBuilder.group({
      policyNumber: ['', Validators.required],
      mainType: ['', Validators.required],
      claim: ['', Validators.required],
      claimType: ['', Validators.required],
      fillOption: ['', Validators.required],
      claimant: ['', Validators.required],
      claimAmount: [''],
      claimantMobileNu: ['', Validators.pattern(this.contactNoPattern)],
      claimantEmail: ['', Validators.pattern(this.emailPattern)],
      remark: [''],
      accountHolderName: ['', Validators.required],
      accountNumber: ['', Validators.required],
      bankName: ['', Validators.required],
      branchName: ['', Validators.required],
      hospitalName: ['', Validators.required],
      dateOfAdmition: ['', Validators.required]
    });
  }

  async ngOnInit() {

    this.loading = true
    this.userRoleId = Number(localStorage.getItem('ASPUserRoleId'))
    console.log(this.userRoleId);
    
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });

    this.secondFormGroup = this.formBuilder.group({
      formType: new FormControl(null),
      digitalFormSelection: new FormControl(null),
      formUpload: new FormControl(null)
    });

    const claimListResponse: any = await this.getClaimList().catch((error) => {
      console.log(error);
    });
    if (claimListResponse.status == 200) {
      this.claims = claimListResponse.payload;
    }


    const claimTypeResponse: any = await this.getClaimType().catch((error) => {
      console.log(error);
    });
    if (claimTypeResponse.status == 200) {
      this.claimTypes = claimTypeResponse.payload;
    }

    const bankListResponse: any = await this.getActiveBankList().catch((error) => {
      console.log(error);
    });
    if (bankListResponse.status == 200) {
      this.activeBankList = bankListResponse.payload;
    }

    const HospitalListResponse: any = await this.getHospitalList().catch((error) => {
      console.log(error);
    });
    if (HospitalListResponse.status == 200) {
      this.hospitalListForClaim = HospitalListResponse.payload;
    }

    console.log(this.hospitalListForClaim);

    this.loading = false

  }

  private _filterHospital(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.hospitalListForClaim.filter(option =>  option.name.toLowerCase().includes(filterValue));
  }


  getSelectedHospitalId(hospitalName: string): any {
    const hospitalIds  = this.hospitalListForClaim.filter(h => h.name.toLowerCase().includes(hospitalName.toLowerCase())).map(h => h.hospitalId);
    return hospitalIds.length > 0 ? hospitalIds[0] : 'Hospital not found';
  }

  clearSelectedHospital(){
    this.claimRequestForm.get('hospitalName').setValue('');
  }


  get minDate(): Date {
    const today = new Date();
    return new Date(today.getFullYear(), today.getMonth(), today.getDate() - 14);
  }

  get maxDate(): Date {
    return new Date();
  }

  verifyPolicy(){
    if (this.claimRequestForm.value.policyNumber !== ''){
      const policyNumber: string = this.claimRequestForm.value.policyNumber
      this.getSelectedPolicy(policyNumber);
      
    } else {
      console.log('empty policy');
    }
  }

  clearSelectedPolicyNu(){
    this.claimRequestForm.get('policyNumber').setValue('');
    this.claimRequestForm.get('mainType').setValue('');
    this.claimRequestForm.get('claimant').setValue('');
    this.claimRequestForm.get('claimantMobileNu').setValue('');
    this.claimRequestForm.get('claimantEmail').patchValue('');
  }

  async getClaimList() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getHospitalList() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getHospitalList(paylaod)
        .subscribe(
          (res) => {
            this.hospitalfilteredOptions = this.claimRequestForm.get('hospitalName').valueChanges
            .pipe(
              startWith(''),
              map(value => this._filterHospital(value))
            );

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }



  validateAllFormFields(formGroup: FormGroup) {
    console.log('validateAllFormFields');
    
    Object.keys(formGroup.controls).forEach((field) => {
      //{2}
      const control = formGroup.get(field); //{3}
      if (control instanceof FormGroup || control instanceof FormGroup) {
        //{4}
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        //{5}
        control.markAsTouched({ onlySelf: true });
        this.validateAllFormFields(control); //{6}
      }
    });
  }

  async getClaimType() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimTypes(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getActiveBankList() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getActiveBankList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getBranchListByBankCode(bankCbankode: number) {
    const paylaod = {
      token: this.token,
      bankCode: bankCbankode
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getActiveBankBranchList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getClaimentDetails(policy: string) {
    const paylaod = {
      token: this.token,
      policyNumber: policy
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimentDetailsFromPolicy(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async saveClaimRequest(payload: any) {
    return new Promise((resolve, reject) => {
      const newPaylaod = {
        token: this.token,
        data: payload
      }
      this.aspServiceService
        .createClaimRequest(newPaylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  getClaimTypes() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.digitalFormSubscription = this.aspServiceService.getClaimTypes(paylaod).subscribe(response => {
        console.log(response);

      }, error => {
        reject(false);
      });
    });
  }

  async getRequiredDocumentList(claimId: number) {
    const paylaod = {
      token: this.token,
      claimId: claimId
    }
    return new Promise((resolve, reject) => {
      this.digitalFormSubscription = this.aspServiceService.getRequiredDocumentList(paylaod)
      .subscribe(
        (res) => {
          resolve(res);
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  async getHBForm() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.savedClaimRequestId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService.getHBForm(paylaod).subscribe(response => {
        resolve(response.payload);
      }, error => {
        reject(error);
      });
    });
  }

  async getTPDPPDForm() {
    console.log("inside getTPDPPDForm");
    const paylaod = {
      token: this.token,
      claimRequestId: this.savedClaimRequestId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService.createTPDPPDForm(paylaod).subscribe(response => {
        resolve(response.payload);
      }, error => {
        reject(error);
      });
    });
  }

  async getCIBForm() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.savedClaimRequestId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService.getCIBForm(paylaod).subscribe(response => {
        resolve(response.payload);
      }, error => {
        reject(error);
      });
    });
  }

  clearPolicyNumber() {
    this.claimRequestForm.get('policyNumber').setValue('');
  }

  get f() {
    return this.secondFormGroup.controls;
  }



  async changeDigitalFormSelection1(type: string, language: string) {
    this.isDisplayNoEFormMessage = false;
    let userToken=this.token;
    Survey.ChoicesRestfull.onBeforeSendRequest = function (sender, options) {
      options.request.setRequestHeader("Authorization", "Bearer "+userToken);
      // options.request.setRequestHeader("Access-Control-Allow-Origin", "*");
      // options.request.setRequestHeader("Access-Control-Allow-Methods", "GET, POST, PATCH, PUT, DELETE, OPTIONS");
      // options.request.setRequestHeader("Access-Control-Allow-Headers", "Origin, Content-Type, X-Auth-Token");
    };
    let survey: Model;
    let surveyJson: any = "";
    switch (type) {
      case 'hb':
        surveyJson = await this.getHBForm().catch((error) => {
          console.log(error);
        });
        survey = new Model(surveyJson);
        if (language == 'SI') {
          survey.locale = "si";
        }
        break;

      case 'tpd/ppd':
        surveyJson = await this.getTPDPPDForm().catch((error) => {
          console.log(error);
        });
        survey = new Model(surveyJson);
        break;

      case 'cib':
        surveyJson = await this.getCIBForm().catch((error) => {
          console.log(error);
        });
        survey = new Model(surveyJson);
        break;
      default:
        break;
    }

    survey.onUpdateQuestionCssClasses.add(function (_: any, options: { cssClasses: any; question: { getType: () => string; }; }) {
      const classes = options.cssClasses;
      if (options.question.getType() === "text") {
        classes.root += " input-height";
      }
      if (options.question.getType() === 'comment') {
        classes.root += ' textarea-height';
      }

    });

    survey.addNavigationItem({
      id: 'sv-nav-clear-page',
      title: 'Clear Form',
      action: () => {
        survey.currentPage.questions.forEach((question: { value: any;name:any }) => {
          if(!(question.name=="policyNumber" || question.name=="claimNumber" || question.name=="nameOfAssured")){
            question.value = undefined;
          }

        });
      },
      css: 'nav-button ',
      innerCss: 'sd-btn nav-input'
    });

    SurveyNG.render("surveyElement", {
      model: survey
    })
    survey.onComplete.add(async (survey, options) => {

      const claimRequestSaveResponse: any = await this.surveyComplete(survey,this.claimRequestForm.value.claim).catch((error) => {
        console.log(error);
        survey.clear(false, true);
        this._snackBar.open("There was a error in filled data. Please check and try again", 'Close', {
          duration: 2000,
        });
      });
      if (claimRequestSaveResponse.status == 200) {
        document.querySelector('div#surveyElement').innerHTML = "";
        // window.location.href = "#/base/service-portal/create?uuid=123456";
        this._ngZone.run(() => {
          // this.route.navigateByUrl('/base/service-portal/create?uuid=123456')

          console.log(this.savedClaimRequestId);

          if (this.savedClaimRequestId != null) {
            console.log(this.savedClaimRequestId);
            const encodeRequestID: string = encodeURIComponent('id?%'+this.savedClaimRequestId);

            this.route.navigate(['/dashboard/asp-management/service-portal/signature/claim/',
              encodeRequestID,
            ]);
          }
        });
        // this.stepper.next();
      }
    });

  }

   surveyComplete(survey: { data: any; },claimId:number) {
    console.log(survey.data);
    let claimType= this.claims.find(value => value.id ==claimId).name;
    console.log(claimType);
    switch (claimType) {
      case 'Hospital Cash Benefit - English':
      case 'Family Surgical Expenses - English':
      case 'Hospital Cash Benefit - Sinhala':
      case 'Family Surgical Expenses - Sinhala':
        return new Promise((resolve, reject) => {
          this.aspServiceService
            .saveHBForm(this.token,this.savedClaimRequestId,claimId,survey.data)
            .subscribe(
              (res) => {
                resolve(res);
              },
              (err) => {
                reject(err);
              }
            );
        });
      case 'Critical Illness Benefit':
        return new Promise((resolve, reject) => {
          this.aspServiceService
            .saveCIBForm(this.token,this.savedClaimRequestId,survey.data)
            .subscribe(
              (res) => {
                resolve(res);
              },
              (err) => {
                reject(err);
              }
            );
        });
      case 'Total Permanent Disability':
      case 'Partial Permanent Disability':
        return new Promise((resolve, reject) => {
          this.aspServiceService
            .saveTPDPPDForm(this.token,this.savedClaimRequestId,claimId,survey.data)
            .subscribe(
              (res) => {
                resolve(res);
              },
              (err) => {
                reject(err);
              }
            );
        });
    }

  }


  async claimRequestNext(stepper: MatStepper) {
    console.log(this.savedClaimRequestId);
    console.log(this.userRoleId);
    
    this.isEnableFormUploadSectionDocData = false;
    this.isEnableFormUploadSection = false;
    this.documentData = null;
    this.claimRequestForm.markAllAsTouched();
    this.admitionDate =  moment(
      this.claimRequestForm.value.dateOfAdmition || new Date()
    ).format("YYYY-MM-DD");
    this.selectedHospitalId = this.getSelectedHospitalId(this.claimRequestForm.value.hospitalName);
    if (this.claimRequestForm.valid) {
      if (this.savedClaimRequestId == null) {
        const payload = {
          agentCode: null,
          policyNumber: this.claimRequestForm.value.policyNumber,
          claimantsName: this.claimRequestForm.value.claimant,
          claimListId: this.claimRequestForm.value.claim,
          mainTypeId: this.claimRequestForm.value.mainType,
          claimantsMobileNumber: this.claimRequestForm.value.claimantMobileNu,
          claimantsEmail: this.claimRequestForm.value.claimantEmail,
          claimAmount: this.claimRequestForm.value.claimAmount,
          accountHolderName: this.claimRequestForm.value.accountHolderName,
          accountNumber: this.claimRequestForm.value.accountNumber,
          bankCode: this.claimRequestForm.value.bankName,
          bankBranchCode: this.claimRequestForm.value.branchName,
          remark: this.claimRequestForm.value.remark,
          hospitalId: this.selectedHospitalId,
          dateOfAdmission: this.admitionDate,
          fillOption: this.claimRequestForm.value.fillOption,
          roleId: this.userRoleId
        }

        console.log(payload);
        this.loading = true;
        const claimRequestSaveResponse: any = await this.saveClaimRequest(payload).catch((error) => {
          console.log(error);
          this.loading=false;
        });
        if (claimRequestSaveResponse.status == 200) {
          this.savedClaimRequestId = claimRequestSaveResponse.payload.id;
          this.generatedClaimRequestNumber = claimRequestSaveResponse.payload.claimRequestNumber;
          this.setSupportiveClaimDetail();
          stepper.next();
        }else if(claimRequestSaveResponse.status == 400){
          let field=claimRequestSaveResponse.payload[0].field;
          field=field.replace(/([A-Z])/g, ' $1')    
          .replace(/^./, str => str.toUpperCase()); 
          this._snackBar.open(field+' '+claimRequestSaveResponse.payload[0].error, 'Close', {
            duration: 2000,
          });
        }

        this.loading = false;

      } else {
        const payload = {
          id: this.savedClaimRequestId,
          agentCode: null,
          policyNumber: this.claimRequestForm.value.policyNumber,
          claimantsName: this.claimRequestForm.value.claimant,
          claimListId: this.claimRequestForm.value.claim,
          mainTypeId: this.claimRequestForm.value.mainType,
          claimantsMobileNumber: this.claimRequestForm.value.claimantMobileNu,
          claimantsEmail: this.claimRequestForm.value.claimantEmail,
          claimAmount: this.claimRequestForm.value.claimAmount,
          accountHolderName: this.claimRequestForm.value.accountHolderName,
          accountNumber: this.claimRequestForm.value.accountNumber,
          bankCode: this.claimRequestForm.value.bankName,
          bankBranchCode: this.claimRequestForm.value.branchName,
          remark: this.claimRequestForm.value.remark,
          hospitalId: this.selectedHospitalId,
          dateOfAdmission: this.claimRequestForm.value.dateOfAdmition,
          fillOption: this.claimRequestForm.value.fillOption,
          roleId: this.userRoleId
        }

        console.log(payload);
        this.loading = true;
        const claimRequestSaveResponse: any = await this.updateClaimRequest(payload).catch((error) => {
          console.log(error);
          this.loading=false;
        });
        if (claimRequestSaveResponse.status == 200) {
          this.setSupportiveClaimDetail();
          stepper.next();
        }else if(claimRequestSaveResponse.status == 400){
          let field=claimRequestSaveResponse.payload[0].field;
          field=field.replace(/([A-Z])/g, ' $1')    
          .replace(/^./, str => str.toUpperCase()); 
          this._snackBar.open(field+' '+claimRequestSaveResponse.payload[0].error, 'Close', {
            duration: 2000,
          });
        }
        this.loading = false;
      }
    } else {
      console.log('invalid document');
      console.log(this.claimRequestForm);
      for (let el in this.claimRequestForm.controls) {
        if (this.claimRequestForm.controls[el].invalid) {
          console.log(el);
        }
      }
      this.validateAllFormFields(this.claimRequestForm);
      this.isEnableFormUploadSection = false;

    }

  }

  setSupportiveClaimDetail() {
    console.log("inside setSupportiveClaimDetail");
    
    if (this.claimRequestForm.value.fillOption == 2) {
      this.isFormSectionCompleted=false;
      this.isEnableFormUploadSection = false;
      switch (this.claimRequestForm.value.claim) {
        case 3:
        case 4:
          this.changeDigitalFormSelection1('hb', 'EN');
          break;
        case 12:
        case 13:
          this.changeDigitalFormSelection1('hb', 'SI');
          break;
        case 6:
        case 7:
          this.changeDigitalFormSelection1('tpd/ppd', 'EN');
          break;
        case 8:
          this.changeDigitalFormSelection1('cib', 'EN');
          break;
        default:
          this.checkIsEFormExistsOrNot();
          break;
      }
    } else if (this.claimRequestForm.value.fillOption == 1) {
      if(document.querySelector('div#surveyElement')!=null){
        document.querySelector('div#surveyElement').innerHTML = "";
      }

      setTimeout(() => {
        this.isEnableFormUploadSection = true;
        this.isDisplayNoEFormMessage = false;
      }, 200);

      let claimId = this.claimRequestForm.value.claim;
      let originalPolicyNumber=this.claimRequestForm.value.policyNumber;
      let policySplit=originalPolicyNumber.split("/");
      const moreClaimData = {
        claimRequestId: this.savedClaimRequestId,
        policyNumber: policySplit[0]+policySplit[1],
        claimGeneratedCode: this.generatedClaimRequestNumber+"-form",


      }
      this.documentFormData = {
        title: this.claims.find(value => value.id == claimId).name,
        data: moreClaimData,
        isEnableDocView: false
      };

    } else {
      this.isEnableFormUploadSection = false;
    }
  }

  async secondFormGroupNext(stepper: MatStepper) {
    this.isEnableDocumentUploadSection = false;
    let claimId = this.claimRequestForm.value.claim;

      let originalPolicyNumber=this.claimRequestForm.value.policyNumber;
      let policySplit=originalPolicyNumber.split("/");
      this.documentData = {
        title: this.claims.find(value => value.id == this.claimRequestForm.value.claim).name,
        claimId: claimId,
        isdocumentUploadable:true,
        state:"create",
        policyNumber:policySplit[0]+policySplit[1],
        claimNumber:this.generatedClaimRequestNumber
      };
      this.isEnableDocumentUploadSection = true;
      stepper.next();
  }

  checkIsEFormExistsOrNot(){
    this.loading = false;
    this.isEnableFormUploadSection = false;
    this.isDisplayNoEFormMessage = true;
  }

  async updateClaimRequest(payload: any) {
    const newPaylaod = {
      token: this.token,
      data: payload
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .updateClaimRequest(newPaylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async submitClaim(){
    this.loading=true;
    const onBranchListResponse: any = await this.submitClaimRequest().catch((error) => {
      console.log(error);
      this.loading=false;
    });
    if (onBranchListResponse.status == 200) {
      this.loading=false;
      Swal.fire({
        title: "Success",
        text: "Claim submitted",
        confirmButtonText: "OK",
      }).then(async (result) => {
        if (result.isConfirmed) {
          this.route.navigate([
            '/dashboard/asp-management']
          );
        }
      });
    }
  }

  async submitClaimRequest() {
    return new Promise((resolve, reject) => {
      let claimModel:any={"claimStatus":"Updated","claimRequestId":this.savedClaimRequestId}
      const paylaod = {
        token: this.token,
        data: claimModel
      }
      this.digitalFormSubscription = this.aspServiceService.submitClaimRequest(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  insertSignature() {
    if (this.savedClaimRequestId != null) {
      console.log(this.savedClaimRequestId);

      let encodeRequestID = encodeURIComponent('id?%'+this.savedClaimRequestId);

      this.route.navigate(['/dashboard/asp-management/service-portal/signature/claim/',
        encodeRequestID,
      ]);
    }

  }

  ngAfterViewInit() {

  }
  

  public get policyNumberToRequest() : boolean {
    if (this.claimRequestForm.value.policyNumber == null ||
       this.claimRequestForm.value.policyNumber == "" ||
        this.claimRequestForm.value.policyNumber == undefined) {
      return false;
      
    } else {
      return true;
    }
     
  }

  
  public get policyNumber() : string {
    return this.claimRequestForm.value.policyNumber;
  }


  onClaimTypeChange() {
    this.claimRequestForm.get('claim').reset();
  }

  async onSelectActiveBankBranch($event) {
    this.claimRequestForm.get('branchName').enable();
    this.claimRequestForm.get('branchName').setValue('');
    this.isVisibleBankBranchNoAvilable = false;
    const onBranchListResponse: any = await this.getBranchListByBankCode($event.value).catch((error) => {
      console.log(error);
    });
    if (onBranchListResponse.status == 200) {
      if (onBranchListResponse.payload.length > 0) {
        this.branchList = onBranchListResponse.payload;
      } else {
        console.log("no bank avilable");
        
        this.claimRequestForm.get('branchName').disable();
        this.isVisibleBankBranchNoAvilable = true;
      }
    }

  }

  async claimRequestClear(){
    this.claimRequestForm.reset();
    this.ngOnInit();
  }

  onSelectClaimType($event) {
    this.claimRequestForm.get('claimType').reset();
    switch ($event.value) {
      case 10:
      case 9:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 11:
      case 12:
      case 13:
        this.claimRequestForm.get('claimType').setValue(2);
        break;
      case 1:
      case 2:
        this.claimRequestForm.get('claimType').setValue(1);
        break;
      default:
        this.claimRequestForm.get('claimType').reset();
        break;
    }

    this.setFillOptionOnClaim($event.value);
  }

  setFillOptionOnClaim(claimId: number){
    this.claimRequestForm.get('fillOption').reset();
    switch (claimId) {
      case 10:
      case 9:
      case 11:
      case 1:
      case 2:
      case 5:
        this.claimRequestForm.get('fillOption').setValue(1);
        break;
      default:
        break;
    }
  }

  
  public get calaimAmount() : string {
    return this.claimRequestForm.value.claimAmount;
  }
  

  onPolicyNumberInput(event: any) {
    let input = event.target.value.trim();

    if (input.length > 10) {
      input = input.substring(0, 10);
    }

    if (input.length <= 3) {
      const regexLetters = /^[a-zA-Z]*$/;
      if (!regexLetters.test(input)) {
        event.target.value = input.replace(/[^a-zA-Z]/g, '').toUpperCase();
        this.claimRequestForm.patchValue({policyNumber: event.target.value});
      }
    } else {

      const firstThreeLetters = input.substring(0, 3).toUpperCase();
      const remainingDigits = input.substring(3).replace(/[^0-9]/g, '');


      event.target.value = `${firstThreeLetters}/${remainingDigits}`;
      this.claimRequestForm.patchValue({policyNumber: event.target.value});
    }
  }


  async getSelectedPolicy(policy: any){
    this.isPolicyVerified = false;
    const claimntDetailsResponse: any = await this.getClaimentDetails(policy).catch((error) => {
      console.log(error);
    });
    if (claimntDetailsResponse.status == 200) {
      this.claimRequestForm.get('mainType').setValue(claimntDetailsResponse.payload.policyType);
      this.claimRequestForm.get('claimant').setValue(claimntDetailsResponse.payload.phName);
      this.claimRequestForm.get('claimantMobileNu').patchValue(claimntDetailsResponse.payload.mobileNumber);
      this.claimRequestForm.get('claimantEmail').patchValue(claimntDetailsResponse.payload.email);

      this.isPolicyVerified = true;
      this.poupService.success('Policy Verification Successful');
    } else {
      this.poupService.warning('Invalid Policy Number or Policy Verification Failed');
    }
  }

  backFromDocumentUpload(stepper: MatStepper){
    if (this.claimRequestForm.get('fillOption').value == 2) {
      this.isEnableDocumentUploadSection = false;
    } else {
      this.isEnableDocumentUploadSection = true;
      this.isEnableDocumentUploadFormSection = true;
    }

    this.setSupportiveClaimDetail();
    stepper.previous();

  }

  onFormLoadedEvent($event){
    console.log($event)
    if($event=="uploaded"){
      this.isFormSectionCompleted=true;
    }else{
      this.isFormSectionCompleted=false;
    }

  }

  onDocumentLoadedEvent($event){
    console.log($event)
    if($event=="no-data"){
      this.isDocumentSectionCompleted=false;
    }else{
      this.isDocumentSectionCompleted=true;
    }
  }




}
