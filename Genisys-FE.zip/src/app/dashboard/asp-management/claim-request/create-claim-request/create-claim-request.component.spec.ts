import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateClaimRequestComponent } from './create-claim-request.component';

describe('CreateClaimRequestComponent', () => {
  let component: CreateClaimRequestComponent;
  let fixture: ComponentFixture<CreateClaimRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateClaimRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateClaimRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
