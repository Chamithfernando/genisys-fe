import { ScrollStrategy, ScrollStrategyOptions } from '@angular/cdk/overlay';
import {Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatTable } from '@angular/material/table';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { AspModuleService } from '@app/shared/services/asp-module/asp-module.service';
import { EncryptDecryptService } from '@app/shared/services/encrypt-decrypt-service/encrypt-decrypt.service';
import { ImageCompresserService } from '@app/shared/services/image-compresser/image-compresser.service';
import { Observable } from 'rxjs';
import { take } from 'rxjs/operators';
import { DocumentViewerDialogComponent } from './document-viewer-dialog/document-viewer-dialog.component';
import { AuthService } from '@app/shared/services/auth/auth.service';

export interface FileData {
  documentType: string;
  fileNames: string;
  fileNameArray: any;
  files: any;
  required: string;
}

interface DmsFiles {
  extension: string,
  name: string,
  file: any
}
interface DmsRequestDTO {
  type: string,
  policyNo: string,
  contractNo: string,
  files: DmsFiles[]
}
interface DmsFilesRetrieve {
  policyNo: string,
  contractNo: string
}

export interface DmsPayload {
  dmsRequestDTOList: DmsRequestDTO[],
  status: string
}

const ELEMENT_DATA: FileData[] = [
];

const FILE_RESPONSE: DmsPayload = null;

@Component({
  selector: 'app-upload-documents',
  templateUrl: './upload-documents.component.html',
  styleUrls: ['./upload-documents.component.scss']
})
export class UploadDocumentsComponent implements OnInit {

  @Input() documentData: any;
  @ViewChild(MatTable) table: MatTable<FileData>;
  @ViewChild('fileInput') fileInputVariable: ElementRef<HTMLInputElement>;
  @Output() onDocumentLoaded = new EventEmitter<any>();

  displayedColumns: string[] = ['documentType', 'fileNames', 'edit', 'delete'];
  dataSource = [...ELEMENT_DATA];
  // documentTypes: any[] = [{ 'value': 'DT/ clinic book', "required": 'mandatory' }, { 'value': 'Claim form(Doctor’s form)', "required": 'mandatory' }, { 'value': 'ID / BC', "required": 'non-mandatory' }, { 'value': 'JMO/Police report', "required": 'non-mandatory' }, { 'value': 'Initial Dr referral', "required": 'non-mandatory' }, { 'value': 'Incident letter', "required": 'non-mandatory' }, { 'value': 'Driving license', "required": 'non-mandatory' }, { 'value': 'PMH', "required": 'non-mandatory' }, { 'value': 'Bank book', "required": 'mandatory' }, { 'value': 'Signature specimen form', "required": 'non-mandatory' }, { 'value': 'All medical records', "required": 'non-mandatory' }, { 'value': 'Questionnaires', "required": 'non-mandatory' }, { 'value': 'Hospital bill', "required": 'mandatory' }];
  // documentTypes: any[];
  mandatoryDocumentTypes: any[];
  nonMandatoryDocumentTypes: any[];
  allDocumentTypes: any[];
  selectedDocumentType: any;
  selectedDocumentIndex: number;
  policyNumber: string;
  claimNumber: string;

  validationMessage: string = "Please verify the required file type and Maximum file size is 10MB";
  validationFileSize: number = 10485760;

  noFileSelected: string = "Please submit all required documents !";
  isFileValid: boolean = false;

  dialogRef: MatDialogRef<any>;
  documentUploadTitle: string;
  isdocumentUploadable: boolean;
  isEditMode: boolean;

  selectedFiles: any = [];
  documentList: any = [];
  submitReadyFileList: any = [];
  progressInfos = [];
  message = '';
  files = [];
  scrollStrategy: ScrollStrategy;
  documentLoading: any;
  mandatoryFiles = [...ELEMENT_DATA];

  token: any;
  supportDocumentUploadFrom: FormGroup;


  constructor(private aspService: AspModuleService,
              private formBuilder: FormBuilder,
              private encryptDecryptService: EncryptDecryptService,
              public dialog: MatDialog,
              private sanitizer: DomSanitizer,
              private _snackBar: MatSnackBar,
              private authService: AuthService,
              private route: Router,
              private readonly sso: ScrollStrategyOptions,
              private imageCompressor: ImageCompresserService) {

    this.token = this.authService.getCurrentUserDetails().access_token;
    this.scrollStrategy = this.sso.reposition();
    this.supportDocumentUploadFrom = this.formBuilder.group({
      docTypeId: [''],
    });
  }


  async ngOnInit() {
    console.log(this.documentData);
    
    this.documentLoading = false;
    this.isEditMode = true;
    this.documentUploadTitle = this.documentData.title;
    this.policyNumber = this.documentData.policyNumber;
    this.claimNumber = this.documentData.claimNumber;

    // this.documentTypes.splice(this.selectedDocumentIndex, 1);
    this.isdocumentUploadable = this.documentData.isdocumentUploadable;
    if (this.documentData.state == "update" || this.documentData.state === "create") {
      this.loadDocumentsFromDMS();
    } else if (this.documentData.state == "view") {
      this.loadDocumentsFromDMS();
      this.isdocumentUploadable = false;
      this.displayedColumns = ['documentType', 'fileNames', 'view'];
    } 
    this.loadDocumentTypes();

  }

  nonMandatoryfileUpload() {
    this.fileInputVariable.nativeElement.click();
  }

  async loadDocumentTypes() {
    const documentListResponse: any = await this.getRequiredDocumentList(this.documentData.claimId).catch((error) => {
      console.log(error);
    });
    if (documentListResponse.status == 200) {
      this.mandatoryDocumentTypes = documentListResponse.payload.mandatoryClaimRelatedDocumentList;
      this.nonMandatoryDocumentTypes = documentListResponse.payload.nonMandatoryClaimRelatedDocumentList;
      this.allDocumentTypes = documentListResponse.payload.allClaimRelatedDocumentList;
    }
  }

  async getRequiredDocumentList(claimId: number) {
    const payload = {
      token: this.token,
      claimId: claimId
    }
    return new Promise((resolve, reject) => {
      this.aspService.getRequiredDocumentList(payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async selectMandatoryFiles(event: any, name: string) {
    let index = event.target.attributes.id.nodeValue;
    let pFileList = event.target.files;
    await this.selectFiles(pFileList, index);
    if (this.mandatoryFiles[index] != undefined) {
      this.changeToViewMode(index);
    }

  }

  changeToViewMode(index: number) {
    let uploadelement = document.getElementById("docupload" + index);

    uploadelement.classList.remove("document-visible");
    uploadelement.classList.add("document-invisible");

    let viewelement = document.getElementById("viewDoc" + index);
    viewelement.classList.remove("document-invisible");
    viewelement.classList.add("document-visible");
  }

  changeToUploadMode(index: number) {
    let uploadelement = document.getElementById("docupload" + index);

    uploadelement.classList.remove("document-invisible");
    uploadelement.classList.add("document-visible");

    let viewelement = document.getElementById("viewDoc" + index);
    viewelement.classList.remove("document-visible");
    viewelement.classList.add("document-invisible");
  }

  editMandatory(index: number, documentType: any) {
    this.viewDocumentItem(this.mandatoryFiles[index], index, documentType, true);
  }

  async selectFiles(pFileList: File[], index: number) {
    this.documentList = Object.keys(pFileList).map(key => pFileList[key]);
    for (let i = 0; i < this.documentList.length; i++) {
      let file = this.documentList[i];
      if (file.size < this.validationFileSize) {
        if (file.type === "application/pdf" || file.type === "image/jpeg" || file.type === "image/png") {
          this.isFileValid = true;
        } else {
          this.isFileValid = false;
        }
      } else {
        this.isFileValid = false;
      }

    }


    if (this.isFileValid) {

      for (let i = 0; i < this.documentList.length; i++) {
        let file = this.documentList[i];
        if (file.type === "image/jpg" || file.type === "image/jpeg" || file.type === "image/png") {
          file = await this.compressImage(file);
        }
        this.selectedFiles.push(file);
      }
      this.files = [];
      for (let i = 0; i < this.selectedFiles.length; i++) {
        this.files.push(this.selectedFiles[i].name);
      }
      if (index == null) {
        this.dataSource.push({ documentType: this.selectedDocumentType.name, fileNames: this.files.join(","), fileNameArray: this.files, files: this.selectedFiles, required: this.selectedDocumentType.mandatory });

        this.table.renderRows();
        this.nonMandatoryDocumentTypes.splice(this.selectedDocumentIndex, 1);
      } else {
        this.mandatoryFiles[index] = { documentType: this.mandatoryDocumentTypes[index].name, fileNames: this.files.join(","), fileNameArray: this.files, files: this.selectedFiles, required: this.mandatoryDocumentTypes[index].mandatory }
      }
      this.selectedFiles = [];
      this.fileInputVariable.nativeElement.value = null;
      this.selectedDocumentType = null;
      this.selectedDocumentIndex = null;
      this._snackBar.open("File ready to upload!", 'Close', {
        duration: 2000,
      });

    } else if (!this.isFileValid) {
      this.resetDocuments();
      this._snackBar.open(this.validationMessage, 'Close', {
        duration: 2000,
      });
    }
  }

  checkDocumentType(event: any) {
    if (this.selectedDocumentType == null) {
      this._snackBar.open("Please select document type first !", 'Close', {
        duration: 2000,
      });
      event.preventDefault();
      event.stopPropagation();
      return false;
    }
  }

  compressImage(image) {
    return new Promise((resolve, reject) => {
      this.imageCompressor.compress(image)
        .pipe(take(1))
        .subscribe(compressedImage => {
          resolve(compressedImage);
        }, error => {
          reject(error);
        });
    });
  }

  resetDocuments() {
    this.documentList = [];
    this.fileInputVariable.nativeElement.value = "";
  }

  edit(index: any, documentType: any) {
    this.viewDocumentItem(this.dataSource[index], index, documentType, false);
  }

  delete(row: any, documentTypeGet: string, required: string) {
    let entry = { 'name': documentTypeGet, 'mandatory': required };
    this.dataSource.splice(row, 1);
    this.nonMandatoryDocumentTypes.push(entry);
    this.table.renderRows();
    this.supportDocumentUploadFrom.get('docTypeId').setValue('');
  }

  deleteMandatory(index: any) {
    this.mandatoryFiles[index] = undefined;
    this.changeToUploadMode(index);
  }

  removeDocument(index: number): void {
    this.selectedFiles.splice(index, 1);
  }

  changeSelectedDocument(index: number) {
    this.selectedDocumentIndex = index;
    this.selectedDocumentType = this.nonMandatoryDocumentTypes[index];
  }

  validateDocuments() {
    var validEntry = true;
    if (this.mandatoryFiles.includes(undefined) || this.mandatoryFiles.length < this.mandatoryDocumentTypes.length) {
      validEntry = false;
    }
    if (validEntry) {
      this.uploadDocuments();
    } else {
      this._snackBar.open(this.noFileSelected, 'Close', {
        duration: 2000,
      });
    }
  }

  async uploadDocuments() {
    let dmsRequestmodel: DmsRequestDTO[] = [];
    await this.includeNonMandatoryFiles(dmsRequestmodel);
    await this.includeMandatoryFiles(dmsRequestmodel);
    let status;
    if (this.documentData.state == "update") {
      status = "update";
    } else {
      status = "upload";
    }
    this.documentLoading = true;
    let dmsPayloadModel: DmsPayload = { dmsRequestDTOList: dmsRequestmodel, status: "update" }
    const documentUploadResponse: any = await this.saveClaimDocuments(dmsPayloadModel).catch((error) => {
      console.log(error);
      this.documentLoading = false;
    });
    if (documentUploadResponse.status == 200) {
      this.documentLoading = false;
      // this.route.navigateByUrl('/base/service-portal')
      this.onDocumentLoaded.emit("has-data");
      this.dataSource = [];
      await this.loadDocumentsFromDMS();
      console.log("successfully uploaded");
      this._snackBar.open("Document upload completed!", 'Close', {
        duration: 2000,
      });
    }
  }
  async includeMandatoryFiles(dmsRequestmodel: DmsRequestDTO[]) {
    for (let i = 0; i < this.mandatoryFiles.length; i++) {
      let dmsFileModel: DmsFiles[] = [];
      for (let j = 0; j < this.mandatoryFiles[i].files.length; j++) {
        if (!(typeof this.mandatoryFiles[i].files[j] != "object" && this.mandatoryFiles[i].files[j].includes("data:"))) {
          const base64 = await this.encryptDecryptService.fileToDataURL(this.mandatoryFiles[i].files[j]);
          this.mandatoryFiles[i].files[j] = base64;
        }
        let fileName = this.mandatoryFiles[i].fileNameArray[j].split(".");
        if (fileName[1] == undefined || this.mandatoryFiles[i].files[j].includes("application/pdf")) {
          fileName[1] = "pdf";
        }
        dmsFileModel.push({ extension: fileName[1], name: fileName[0], file: this.mandatoryFiles[i].files[j] });

      }
      dmsRequestmodel.push({ type: this.mandatoryFiles[i].documentType, policyNo: this.policyNumber, contractNo: this.claimNumber, files: dmsFileModel })
    }
  }

  async includeNonMandatoryFiles(dmsRequestmodel: DmsRequestDTO[]) {
    for (let i = 0; i < this.dataSource.length; i++) {
      let dmsFileModel: DmsFiles[] = [];
      for (let j = 0; j < this.dataSource[i].files.length; j++) {
        if (!(typeof this.dataSource[i].files[j] != "object" && this.dataSource[i].files[j].includes("data:"))) {
          const base64 = await this.encryptDecryptService.fileToDataURL(this.dataSource[i].files[j]);
          this.dataSource[i].files[j] = base64;
        }
        let fileName = this.dataSource[i].fileNameArray[j].split(".");
        if (fileName[1] == undefined || this.dataSource[i].files[j].includes("application/pdf")) {
          fileName[1] = "pdf";
        }
        dmsFileModel.push({ extension: fileName[1], name: fileName[0], file: this.dataSource[i].files[j] });

      }
      dmsRequestmodel.push({ type: this.dataSource[i].documentType, policyNo: this.policyNumber, contractNo: this.claimNumber, files: dmsFileModel })
    }
  }

  viewDocumentItem(submitReadyDocList: any, index: number, documentType: string, mandatory: boolean) {
    const dialogRef = this.dialog.open(DocumentViewerDialogComponent, {
      width: '95%',
      data: {
        docs: submitReadyDocList,
        isdocumentUploadable: this.isdocumentUploadable,
        documentType: documentType
      },
      disableClose: true,

    });

    dialogRef.afterClosed().subscribe(result => {
      if (mandatory) {
        this.mandatoryFiles[index].fileNameArray = result.responseFileNames;
        this.mandatoryFiles[index].fileNames = result.responseFileNames.join(",");
        this.mandatoryFiles[index].files = result.responseFiles;
        if (result.responseFiles.length == 0) {
          this.deleteMandatory(index);
        }
        console.log(this.mandatoryFiles)
      } else {
        this.dataSource[index].fileNames = result.responseFileNames;
        this.dataSource[index].files = result.responseFiles;
        if (result.responseFiles.length == 0) {
          this.delete(index, this.dataSource[index].documentType, this.dataSource[index].required);
        }
      }
    });

  }

  async saveClaimDocuments(payload: any) {
    return new Promise((resolve, reject) => {
      this.aspService
        .saveClaimDocuments(this.token,payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getClaimDocuments(payload: any) {
    return new Promise((resolve, reject) => {
      this.aspService
        .getClaimDocuments(this.token, payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async loadDocumentsFromDMS() {
    this.documentLoading = true;
    let dmsPayloadModel: DmsFilesRetrieve = { policyNo: this.policyNumber, contractNo: this.claimNumber };
    const documentretreiveResponse: any = await this.getClaimDocuments(dmsPayloadModel).catch((error) => {
      console.log(error);
      this.documentLoading = false;
      this.onDocumentLoaded.emit("no-data");
    });
    if (documentretreiveResponse.status == 200) {
      this.onDocumentLoaded.emit("has-data");
      let response = documentretreiveResponse.payload;
      for (let i = 0; i < response.length; i++) {
        let isMandatory = "false";
        for (let x = 0; x < this.allDocumentTypes.length; x++) {
          if (response[i].type == this.allDocumentTypes[x].name) {
            isMandatory = this.allDocumentTypes[x].mandatory;
          }
        }

        for (let j = 0; j < response[i].files.length; j++) {
          this.selectedFiles.push(response[i].files[j].file);
          this.files.push(response[i].files[j].name);
        }

        if (isMandatory) {
          let doc_index = this.getMandatoryFilesIndex(response[i].type);
          this.mandatoryFiles[doc_index] = { documentType: response[i].type, fileNames: this.files.join(","), fileNameArray: this.files, files: this.selectedFiles, required: "true" };
          this.changeToViewMode(doc_index);
        } else {
          this.dataSource.push({ documentType: response[i].type, fileNames: this.files.join(","), fileNameArray: this.files, files: this.selectedFiles, required: "false" });
        }

        this.selectedFiles = [];
        this.files = [];

      }
      this.table.renderRows();
      this.removeLoadedDocumentTypes(response);
      this.documentLoading = false;
    } else {
      this.documentLoading = false;
    }
  }
  getMandatoryFilesIndex(type: any) {
    for (let index = 0; index < this.mandatoryDocumentTypes.length; index++) {
      if (this.mandatoryDocumentTypes[index].name == type) {
        return index;
      }
    }
    return 0;
  }

  removeLoadedDocumentTypes(response: any) {
    for (let i = 0; i < response.length; i++) {
      for (let x = 0; x < this.nonMandatoryDocumentTypes.length; x++) {
        if (response[i].type == this.nonMandatoryDocumentTypes[x].name) {
          this.nonMandatoryDocumentTypes.splice(x, 1);
        }
      }
    }
  }

}


