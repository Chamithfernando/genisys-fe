import { ChangeDetectionStrategy, Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { DomSanitizer } from '@angular/platform-browser';
import { EncryptDecryptService } from '@app/shared/services/encrypt-decrypt-service/encrypt-decrypt.service';
import { ImageCompresserService } from '@app/shared/services/image-compresser/image-compresser.service';
import { take } from 'rxjs/operators';


@Component({
  selector: 'app-document-viewer-dialog',
  templateUrl: './document-viewer-dialog.component.html',
  styleUrls: ['./document-viewer-dialog.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DocumentViewerDialogComponent implements OnInit {


  documentData: any;
  dataSource:any;
  dataList:any;
  validationMessage: string = "Please verify the required file type and Maximum file size is 10MB";
  validationFileSize: number = 10485760;
  selecteddocumentList: any = [];

  noFileSelected: string = "Please submit all required documents !";
  isFileValid: boolean = false;
  pdfViewable:boolean=false; 
  docImageViewable:boolean=false; 
  docImage: any;
  filesChanged:boolean=false;

  @ViewChild(MatTable) table: MatTable<any>;

  pdfSrc: any;

  displayedColumns = ['fileName','view', 'update', 'download', 'delete'];
  @ViewChild('fileInput') fileInput: ElementRef<HTMLInputElement>;


  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
  private _snackBar: MatSnackBar,
  private dialogRef: MatDialogRef<DocumentViewerDialogComponent>,
  private encryptDecryptService: EncryptDecryptService,
  public sanitizer: DomSanitizer,
  private imageCompressor: ImageCompresserService) { 
    this.initializeData();
  }

  initializeData(){
    this.dataList= this.renderInput(this.data.docs.files,this.data.docs.fileNameArray);
    console.log(this.dataList);
    this.dataSource = new MatTableDataSource([]);
    this.dataSource = new MatTableDataSource(this.dataList);
    console.log(this.dataSource)
    if(this.data.isdocumentUploadable==false){
      this.displayedColumns = [];
      this.displayedColumns = ['fileName', 'view','download'];
    }
  }

  ngOnInit() {
    
  }

  fileUpload() {
    this.fileInput.nativeElement.click();
  }

  renderInput(fileList:any,filenames:any){
    const retrieve=fileList;
    for(let i=0;i<retrieve.length;i++){
      if(retrieve[i].name==undefined){
        if(retrieve[i].includes("data:image/jpeg;base64")){
          let blob=this.encryptDecryptService.dataURItoBlob(retrieve[i]);
          var file = new File([blob], filenames[i]+'.jpg', {
            type: "'image/jpeg'"
          });
          retrieve[i]=file;
        }else if( retrieve[i].includes("data:image/png;base64")){
          let blob=this.encryptDecryptService.dataURItoBlob(retrieve[i]);
          var file = new File([blob], filenames[i]+'.png', {
            type: "'image/png'"
          });
          retrieve[i]=file;
        }else if(retrieve[i].includes("data:application/pdf;base64") || retrieve[i].includes("data:'application/pdf';base64")){
          let blob=this.encryptDecryptService.dataURItoBlob(retrieve[i]);
          var file = new File([blob], filenames[i]+'.pdf', {
            type: "'application/pdf'"
          });
          retrieve[i]=file;
        }
      }
      
      retrieve[i].selectable=false;
    }
    return retrieve;
  }

  edit(index:number){
    this.dataList[index].selectable=true;
    this.dataSource = new MatTableDataSource(this.dataList);

    this.clearDocViewer();
  }

  download(index:number){
        let file = this.dataList[index];
        const newBlob = new Blob([file]);
        const data = window.URL.createObjectURL(newBlob);
        const downloadLink = document.createElement("a");
        downloadLink.href = data;
        downloadLink.download = file.name;
        downloadLink.click();
        
  }

  remove(index: number): void {
    this.dataList.splice(index, 1);
    this.dataSource = new MatTableDataSource(this.dataList);
    this.filesChanged=true;
    this.clearDocViewer();
  }

  async selectNewFiles(pFileList: File[]){
    this.clearDocViewer();
    this.selecteddocumentList = Object.keys(pFileList).map(key => pFileList[key]);
    for (let i = 0; i < this.selecteddocumentList.length; i++) {
      let file = this.selecteddocumentList[i];
      if (file.size < this.validationFileSize) {
        if (file.type === "application/pdf" || file.type === "image/jpeg" || file.type === "image/png") {
          this.isFileValid = true;
        } else {
          this.isFileValid = false;
        }
      } else {
        this.isFileValid = false;
      }

    }


    if (this.isFileValid) {
      for (let i = 0; i < this.selecteddocumentList.length; i++) {
        let file = this.selecteddocumentList[i];
        if (file.type === "image/jpg" || file.type === "image/jpeg" || file.type === "image/png") {
          file =await this.compressImage(file);
        }
        this.dataList.push(file);
      }
      console.log("datalist",this.dataList);
      
      this.dataSource = new MatTableDataSource(this.dataList);
      this.table.renderRows();
      this.initializeData();

      this._snackBar.open("File ready to upload!", 'Close', {
        duration: 2000,
      });
      this.filesChanged=true;

    } else if (!this.isFileValid) {
      this._snackBar.open(this.validationMessage, 'Close', {
        duration: 2000,
      });
    }

  }

  async selectFiles(pFileList: File[],index:number) {
    this.selecteddocumentList = Object.keys(pFileList).map(key => pFileList[key]);
    for (let i = 0; i < this.selecteddocumentList.length; i++) {
      let file = this.selecteddocumentList[i];
      if (file.size < this.validationFileSize) {
        if (file.type === "application/pdf" || file.type === "image/jpeg" || file.type === "image/png") {
          this.isFileValid = true;
        } else {
          this.isFileValid = false;
        }
      } else {
        this.isFileValid = false;
      }

    }


    if (this.isFileValid) {

      for (let i = 0; i < this.selecteddocumentList.length; i++) {
        let file = this.selecteddocumentList[i];
        if (file.type === "image/jpg" || file.type === "image/jpeg" || file.type === "image/png") {
          file =await this.compressImage(file);
        }
        this.dataList[index]=file;
      }
      this.dataList[index].selectable=false;
      this.dataSource = new MatTableDataSource(this.dataList);

      this._snackBar.open("File ready to upload!", 'Close', {
        duration: 2000,
      });
      this.filesChanged=true;

    } else if (!this.isFileValid) {
      this._snackBar.open(this.validationMessage, 'Close', {
        duration: 2000,
      });
    }
  }

  getFilesNames(){
    let fileNames=[];
    for (let i = 0; i < this.dataList.length; i++) {
      fileNames.push(this.dataList[i].name);
    }
    return fileNames;
  }

  compressImage(image) {
    return new Promise((resolve, reject) => {
      this.imageCompressor.compress(image)
        .pipe(take(1))
        .subscribe(compressedImage => {
          resolve(compressedImage);
        }, error => {
          reject(error);
        });
    });
  }

  async view(index:number){
    console.log(this.dataList[index])
    if(this.dataList[index].name==undefined){
      if(this.dataList[index].includes("data:image/jpeg;base64")){
        this.docImageViewable=true;
        const file = new Blob([this.dataList[index]], {type: 'image/jpeg'});
        let fileUrl = URL.createObjectURL(file);
        this.pdfSrc = fileUrl;
      }else if(this.dataList[index].includes("data:image/jpg;base64")){
        this.docImageViewable=true;
        const file = new Blob([this.dataList[index]], {type: 'image/jpg'});
        let fileUrl = URL.createObjectURL(file);
        this.pdfSrc = fileUrl;
      }else if( this.dataList[index].includes("data:image/png;base64")){
        this.docImageViewable=true;
        const file = new Blob([this.dataList[index]], {type: 'image/png'});
        let fileUrl = URL.createObjectURL(file);
        this.pdfSrc = fileUrl;
      }else if(this.dataList[index].includes("data:application/pdf;base64") || this.dataList[index].includes("data:'application/pdf';base64")){
        this.pdfViewable=true;
        const file = new Blob([this.dataList[index]], {type: 'application/pdf'});
        let fileUrl = URL.createObjectURL(file);
        this.pdfSrc = fileUrl;
      }
    }else{
      if(this.dataList[index].name.includes("jpeg")){
        this.docImageViewable=true;
        const file = new Blob([this.dataList[index]], {type: 'image/jpeg'});
        let fileUrl = this.sanitizer.bypassSecurityTrustUrl(URL.createObjectURL(file));
        this.docImage=fileUrl;
      }else if(this.dataList[index].name.includes("jpg")){
        this.docImageViewable=true;
        const file = new Blob([this.dataList[index]], {type: 'image/jpg'});
        let fileUrl = this.sanitizer.bypassSecurityTrustUrl(URL.createObjectURL(file));
        this.docImage=fileUrl;
      }else if( this.dataList[index].name.includes("png")){
        this.docImageViewable=true;
        const file = new Blob([this.dataList[index]], {type: 'image/png'});
        let fileUrl = this.sanitizer.bypassSecurityTrustUrl(URL.createObjectURL(file));
        this.docImage=fileUrl;
      }else if(this.dataList[index].name.includes("pdf") ){
        this.pdfViewable=true;
        const file = new Blob([this.dataList[index]], {type: 'application/pdf'});
        let fileUrl = URL.createObjectURL(file);
        this.pdfSrc = fileUrl;
      }
    }
      
  }

  openDocument(document: File) {
    const fileReader: FileReader = new FileReader();
    fileReader.onload = () => {
      // @ts-ignore
      this.pdfViewer.openDocument(new Uint8Array(fileReader.result));
    };
    fileReader.readAsArrayBuffer(document);
  }

  closeDialog(){
    this.dialogRef.close({responseFiles:this.dataList,responseFileNames:this.getFilesNames(),isFileChanged:this.filesChanged});
  }

  clearDocViewer(){
    this.pdfViewable = false;
    this.docImageViewable = false;
  }

}
