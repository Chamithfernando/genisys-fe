import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { StepperOrientation } from '@angular/cdk/stepper';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, UntypedFormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatStepper } from '@angular/material/stepper';
import { ActivatedRoute, Router } from '@angular/router';
import { AspModuleService } from '@app/shared/services/asp-module/asp-module.service';
import { AuthService } from '@app/shared/services/auth/auth.service';
import { Observable, Subscription } from 'rxjs';
import { SurveyNG, Model } from "survey-angular";
import * as Survey from 'survey-angular';
import { DocumentViewerDialogComponent } from '../upload-documents/document-viewer-dialog/document-viewer-dialog.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ImageCompresserService } from '@app/shared/services/image-compresser/image-compresser.service';
import { take } from 'rxjs/operators';
import { EncryptDecryptService } from '@app/shared/services/encrypt-decrypt-service/encrypt-decrypt.service';
import { DmsPayload } from '../upload-claim-form/upload-claim-form.component';
import { element } from 'protractor';

const creatorOptions = {
  showLogicTab: true,
  isAutoSave: true
};

export interface featuresComponent {
  id: number;
  name: string;
}

export interface InsuranceRequirement {
  name: string;
}

export interface type {
  id: number;
  name: string;
}

export interface FileData {
  fileNameArray: any;
  files: any;
}

interface DmsFilesRetrieve {
  policyNo: string,
  contractNo: string
}

const ELEMENT_DATA: FileData[] = [
];

@Component({
  selector: 'app-view-claim-request',
  templateUrl: './view-claim-request.component.html',
  styleUrls: ['./view-claim-request.component.scss']
})
export class ViewClaimRequestComponent implements OnInit {

  @ViewChild('decisionSummary') decisionSummary: ElementRef<HTMLInputElement>;

  token: any;
  loading: any;
  selectedIndex: number;

  documentFormData: any;

  claimRequestId: number
  unstructuredClaim = 1;
  structuredClaim = 2;
  agentCode: string;
  isEnableDocumentUploadSection = false;

  dialogRef: MatDialogRef<any>;

  isFileValid: boolean = false;
  selectedFiles: any = [];
  documentList: any = [];
  submitReadyFileList: any = [];
  files = [];
  displayedColumns: string[] = ['documentType', 'fileNames', 'edit', 'delete'];
  dataSource = [...ELEMENT_DATA];

  
  showSecondLevelAction = false;
  otherDocumentEditable = false;
  synopsisDocumentEditable = false;
  isReturned=false;
  approvalReceived = false;
  pendingReceived = false;
  rejectReceived = false;
  showSecondLevelDecisionReceived = false;
  decisionTakenUser: string;
  returnReason:string;

  otherFiles: FileData;
  synopsisFiles: FileData;
  creditNoteFiles: FileData;
  pendingLetterFiles: FileData;
  rejectionLetterFiles: FileData;

  isEnableDocumentUploadFormSection = false;
  claimRequestUserAction = 0;
  documentData: any;
  generatedClaimRequestNumber: string;
  claimRequestAction: boolean;

  filteredOptions: any;

  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;
  claimRequestForm: FormGroup;
  claimRequestData: any;
  
  actionClaimRequest: FormGroup;
  actionFirstLevelReview: FormGroup;
  decisionReceivedClaimRequest: FormGroup;
  actionFinanceReview: FormGroup;

  emailPattern = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$"

  mainTypes: type[] = [
    {
      id: 1,
      name: 'Life'
    },
    {
      id: 2,
      name: 'Group Life'
    }
  ];

  userOptions: type[] = [
    {
      id: 1,
      name: 'Document Upload'
    },
    {
      id: 2,
      name: 'Fill E-Form'
    }
  ];

  claimTypes: any;
  claims: any;
  claimActionFeatures: featuresComponent[] = [];
  policyListForClaim: string[] = [];
  activeBankList: any;
  hospitalList: any;
  branchList: any;

  contactNoPattern = "[0-9]{10}";
  orientation: StepperOrientation = 'horizontal';



  insuranceRequirements: InsuranceRequirement[] = [
    { name: 'Health' },
    { name: 'Protection' },
    { name: 'Savings' },
    { name: 'Retirement' },
    { name: 'Investment' }
  ];
  public personNameForm: any;
  digitalFormSubscription: Subscription;

  claimfilteredOptions: Observable<any[]>;
  showFinanceReview: boolean;

  constructor(
    private formBuilder: FormBuilder,
    private _formBuilder: FormBuilder,
    private route: Router,
    public dialog: MatDialog,
    private _snackBar: MatSnackBar,
    private activatedRoute: ActivatedRoute,
    private breakPointObserver: BreakpointObserver,
    private authService: AuthService,
    private router: Router,
    private aspServiceService: AspModuleService,
    private imageCompressor: ImageCompresserService) {
    breakPointObserver.observe([
      Breakpoints.XSmall,
      Breakpoints.Small
    ]).subscribe(result => {
      this.orientation = 'vertical';
    });

    this.token = this.authService.getCurrentUserDetails().access_token;

    this.claimRequestForm = _formBuilder.group({
      policyNumber: ['', Validators.required],
      mainType: ['', Validators.required],
      claim: ['', Validators.required],
      claimType: ['', Validators.required],
      fillOption: ['', Validators.required],
      claimant: ['', Validators.required],
      claimAmount: ['', Validators.required],
      claimantMobileNu: ['', Validators.pattern(this.contactNoPattern)],
      claimantEmail: ['', Validators.pattern(this.emailPattern)],
      remark: [''],
      accountHolderName: ['', Validators.required],
      accountNumber: ['', Validators.required],
      bankName: ['', Validators.required],
      branchName: ['', Validators.required],
      hospitalName: ['', Validators.required],
      dateOfAdmition: ['', Validators.required]
    });

    this.actionClaimRequest = this._formBuilder.group({
      claimNumber: [''],
      sumAssured: [''],
      paymentMode: [''],
      decisionSummary: [''],
      action: ['']
    });

    this.decisionReceivedClaimRequest = this._formBuilder.group({
      claimNumber: [''],
      sumAssured: [''],
      paymentMode: [''],
      decisionSummary: [''],
      secondApproval: [''],
      decisionRemark: ['']
    });
    this.actionFinanceReview = _formBuilder.group({
      claimNumber: [''],
      sumAssured: [''],
      paymentMode: [''],
      decisionSummary: [''],
      secondApproval: [''],
      decisionRemark: ['']
    });
    
  }

  async ngOnInit() {

    this.loading = true;
    const claimRequestUrl: string = this.activatedRoute.snapshot.params.claimId;
    console.log(claimRequestUrl);

    const name = decodeURIComponent(claimRequestUrl);
    console.log(name);

    this.claimRequestId = Number(name.split('%').pop());
    console.log(this.claimRequestId);

    this.activatedRoute.queryParamMap.subscribe((p: any) => this.selectedIndex = Number(p['params'].navigateIndex));
    let actionRequest;
    this.activatedRoute.queryParamMap.subscribe((p: any) => actionRequest = p['params'].action);
    if (actionRequest == "false") {
      this.claimRequestAction = false;
    } else if (actionRequest == "true") {
      this.claimRequestAction = true;
    }
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });

    this.secondFormGroup = this.formBuilder.group({
      formType: new FormControl(null),
      digitalFormSelection: new FormControl(null),
      formUpload: new FormControl(null)
    });


    const claimListResponse: any = await this.getClaimList().catch((error) => {
      console.log(error);
    });
    if (claimListResponse.status == 200) {
      this.claims = claimListResponse.payload;
    }


    const claimTypeResponse: any = await this.getClaimType().catch((error) => {
      console.log(error);
    });
    if (claimTypeResponse.status == 200) {
      this.claimTypes = claimTypeResponse.payload;
    }

    const bankListResponse: any = await this.getActiveBankList().catch((error) => {
      console.log(error);
    });
    if (bankListResponse.status == 200) {
      this.activeBankList = bankListResponse.payload;
      console.log(this.activeBankList);

    }

    const HospitalListResponse: any = await this.getHospitalList().catch((error) => {
      console.log(error);
    });
    if (HospitalListResponse.status == 200) {
      this.hospitalList = HospitalListResponse.payload;
    }


    const claimRequestDataResponse: any = await this.getClaimRequestById(this.claimRequestId).catch((error) => {
      console.log(error);
    });
    if (claimRequestDataResponse.status == 200) {
      const claimData: any = claimRequestDataResponse.payload;
      console.log(claimData);
      this.claimRequestData = claimData;
      this.setData(claimData);

    }
    this.loading = false;
    this.claimRequestNext();
    this.secondFormGroupNext();

    const currentAssignResponse: any = await this.getCurrentAssignDetails().catch((error) => {
      console.log(error);
    });
    if (currentAssignResponse.status == 200) {
      let firstAssignUser = currentAssignResponse.payload.firstAssignedUserId;
      let currentAssignUser = currentAssignResponse.payload.currentAssignedUserId;
      let internalStatus = currentAssignResponse.payload.internalStatus;
      let department = currentAssignResponse.payload.departmentId;
      let previousAssignedUser = currentAssignResponse.payload.previousAssignedUserId;
      if ((firstAssignUser == currentAssignUser && internalStatus == "Assigned") || firstAssignUser==0 ) {
        
      } else if (department == 2) {
        this.showSecondLevelAction = false;
        this.showSecondLevelDecisionReceived = false;
        this.showFinanceReview = true;
        const claimReviewResponse: any = await this.getClaimReviewDetails().catch((error) => {
          console.log(error);
        });
        if (claimListResponse.status == 200) {
          this.actionFinanceReview = this._formBuilder.group({
            claimNumber: [claimReviewResponse.payload.claimNumber],
            sumAssured: [claimReviewResponse.payload.sumAssured],
            paymentMode: [claimReviewResponse.payload.paymentMode],
            decisionSummary: [claimReviewResponse.payload.decisionSummary],
            decisionRemark: ['', Validators.required]
          });
        }
        this.loadSavedSynopsisFilesFromClaimRequest(this.claimRequestId);
        this.loadSavedOtherFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedCreditnoteFilesFromClaimRequest(this.claimRequestId);

        this.decisionSummary.nativeElement.style.height = 'auto';
        this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;
      } else if (internalStatus == "Returned") {
        this.isReturned=true;
        this.returnReason=this.claimRequestData.remarkList[0].remark;
      } else if (internalStatus == "Assigned") {
        this.showSecondLevelAction = true;
        this.showSecondLevelDecisionReceived = false;
        this.synopsisDocumentEditable = false;
        this.otherDocumentEditable = false;
        this.loadSavedOtherFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedSynopsisFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedpendingLetterFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedRejectionLetterFilesFromClaimRequest(this.claimRequestId);
        const claimReviewResponse: any = await this.getClaimReviewDetails().catch((error) => {
          console.log(error);
        });
        if (claimListResponse.status == 200) {
          this.actionClaimRequest = this._formBuilder.group({
            claimNumber: [claimReviewResponse.payload.claimNumber],
            sumAssured: [claimReviewResponse.payload.sumAssured],
            paymentMode: [claimReviewResponse.payload.paymentMode],
            decisionSummary: [claimReviewResponse.payload.decisionSummary],
            action: ['']
          });
        }
        await this.loadSavedCreditnoteFilesFromClaimRequest(this.claimRequestId);
        this.decisionSummary.nativeElement.style.height = 'auto';
        this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;
      } else {
        this.showSecondLevelAction = false;
        this.showSecondLevelDecisionReceived = true;
        const claimReviewResponse: any = await this.getClaimReviewDetails().catch((error) => {
          console.log(error);
        });
        if (claimListResponse.status == 200) {
          this.decisionReceivedClaimRequest = this._formBuilder.group({
            claimNumber: [claimReviewResponse.payload.claimNumber],
            sumAssured: [claimReviewResponse.payload.sumAssured],
            paymentMode: [claimReviewResponse.payload.paymentMode],
            decisionSummary: [claimReviewResponse.payload.decisionSummary],
          });
        }
        const claimDecisionUserResponse: any = await this.getClaimDecisionUserDetails(previousAssignedUser).catch((error) => {
          console.log(error);
        });
        if (claimListResponse.status == 200) {
          this.decisionTakenUser = claimDecisionUserResponse.payload.name
        }
        this.loadSavedOtherFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedSynopsisFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedCreditnoteFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedpendingLetterFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedRejectionLetterFilesFromClaimRequest(this.claimRequestId);
        if (internalStatus == "Approved") {
          this.approvalReceived = true;
          this.pendingReceived = false;
          this.rejectReceived = false;
        } else if (internalStatus == "Pending") {
          this.approvalReceived = false;
          this.pendingReceived = true;
          this.rejectReceived = false;
        } else if (internalStatus == "Rejected") {
          this.approvalReceived = false;
          this.pendingReceived = false;
          this.rejectReceived = true;
        }
        this.decisionSummary.nativeElement.style.height = 'auto';
        this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;
      }
    }

  }

  public get actionClaimRequestsumAssured(): string {
    return this.actionClaimRequest.value.sumAssured;
  }

  public get decisionReceivedsumAssured(): string {
    return this.decisionReceivedClaimRequest.value.sumAssured;
  }

  async getAssigneeUserList() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId,
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getAssigneeUserList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getCurrentAssignDetails() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId,
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getCurrentAssignDetails(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getClaimReviewDetails() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimReviewDetails(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getClaimDecisionUserDetails(userId: number) {
    const paylaod = {
      token: this.token,
      userId: userId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimDecisionUserDetails(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async loadSavedOtherFilesFromClaimRequest(requestId: number) {
    this.loading = true;
    let dmsPayloadModel: DmsFilesRetrieve = { policyNo: this.claimRequestData.policyNumber.replace('/', ''), contractNo: this.claimRequestData.claimRequestNumber + '-other' };
    const documentretreiveResponse: any = await this.getClaimDocuments(dmsPayloadModel).catch((error) => {
      console.log(error);
    });
    if (documentretreiveResponse.status == 200) {

      this.otherDocumentEditable = false;
      this.loading = false;
      let documentListFromDMS = documentretreiveResponse.payload[0];
      for (let j = 0; j < documentListFromDMS.files.length; j++) {
        this.selectedFiles.push(documentListFromDMS.files[j].file);
        this.files.push(documentListFromDMS.files[j].name);
      }
      this.otherFiles = { fileNameArray: this.files, files: this.selectedFiles }
      this.files = [];
      this.selectedFiles = [];
    } else {
      this.loading = false;
    }
    this.loading = false;

  }

  async loadSavedSynopsisFilesFromClaimRequest(requestId: number) {
    this.loading = true;
    let dmsPayloadModel: DmsFilesRetrieve = { policyNo: this.claimRequestData.policyNumber.replace('/', ''), contractNo: this.claimRequestData.claimRequestNumber + '-synopsis' };
    const documentretreiveResponse: any = await this.getClaimDocuments(dmsPayloadModel).catch((error) => {
      console.log(error);
    });
    if (documentretreiveResponse.status == 200) {

      this.synopsisDocumentEditable = false;
      this.loading = false;
      let documentListFromDMS = documentretreiveResponse.payload[0];
      for (let j = 0; j < documentListFromDMS.files.length; j++) {
        this.selectedFiles.push(documentListFromDMS.files[j].file);
        this.files.push(documentListFromDMS.files[j].name);
      }
      this.synopsisFiles = { fileNameArray: this.files, files: this.selectedFiles }
      this.files = [];
      this.selectedFiles = [];
    } else {
      this.loading = false;
    }
    this.loading = false;

  }

  async getClaimDocuments(payload: any) {
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimDocuments(this.token, payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  viewSynopsisDocuments() {
    const dialogRef = this.dialog.open(DocumentViewerDialogComponent, {
      width: '95%',
      data: {
        docs: this.synopsisFiles,
        isdocumentUploadable: false,
        documentType: 'Synopsis Documents'
      },
      disableClose: true,

    });

    dialogRef.afterClosed().subscribe(result => {
      this.synopsisFiles.fileNameArray = result.responseFileNames;
      this.synopsisFiles.files = result.responseFiles;
    });
  }

  

  viewCreditNoteDocuments() {
    const dialogRef = this.dialog.open(DocumentViewerDialogComponent, {
      width: '95%',
      data: {
        docs: this.creditNoteFiles,
        isdocumentUploadable: false,
        documentType: 'Credit Note'
      },
      disableClose: true,

    });

    dialogRef.afterClosed().subscribe(result => {
      this.creditNoteFiles.fileNameArray = result.responseFileNames;
      this.creditNoteFiles.files = result.responseFiles;
    });
  }

  viewOtherDocuments() {
    const dialogRef = this.dialog.open(DocumentViewerDialogComponent, {
      width: '95%',
      data: {
        docs: this.otherFiles,
        isdocumentUploadable: false,
        documentType: 'Other Documents'
      },
      disableClose: true,

    });

    dialogRef.afterClosed().subscribe(result => {
      this.otherFiles.fileNameArray = result.responseFileNames;
      this.otherFiles.files = result.responseFiles;
    });
  }

  public get calaimAmount(): string {
    return this.claimRequestForm.value.claimAmount;
  }

  setData(data: any) {
    const remarkData: any[] = data.remarkList;
    let claimRemarkObj;
    if (remarkData.length == 0) {
      claimRemarkObj = "";
    } else {
      claimRemarkObj = remarkData.pop();
    }

    this.claimRequestForm.patchValue({
      policyNumber: data.policyNumber,
      mainType: data.mainTypeId,
      claim: data.claimListId,
      claimType: data.claimTypeId,
      fillOption: data.fillOption,
      claimant: data.claimantsName,
      claimAmount: data.claimAmount,
      claimantMobileNu: data.claimantsMobileNumber,
      claimantEmail: data.claimantsEmail,
      remark: claimRemarkObj.remark,
      accountHolderName: data.accountHolderName,
      accountNumber: data.accountNumber,
      bankName: data.bankCode,
      dateOfAdmition: data.dateOfAdmission
    });
    this.onSelectActiveBankBranchSet(data);
    this.onSelectHospitalSet(data);
    this.generatedClaimRequestNumber = data.claimRequestNumber;

    this.claimRequestForm.disable();
  }

  get minDate(): Date {
    const today = new Date();
    return new Date(today.getFullYear(), today.getMonth(), today.getDate() - 14);
  }

  get maxDate(): Date {
    return new Date();
  }

  clearPolicyNumber() {
    this.claimRequestForm.get('policyNumber').setValue('');
  }

  
  changeDigitalFormSelection() {
    const selection = this.secondFormGroup.get('digitalFormSelection').value;
    const formType = this.secondFormGroup.get('formType').value;
    console.log(selection);
    console.log(formType);
    if (selection == "yes") {
      let authToken = this.token;
      Survey.ChoicesRestfull.onBeforeSendRequest = function (sender, options) {
        options.request.setRequestHeader("Authorization", "Bearer " + authToken);
        options.request.setRequestHeader("Access-Control-Allow-Origin", "*");
        options.request.setRequestHeader("Access-Control-Allow-Methods", "GET, POST, PATCH, PUT, DELETE, OPTIONS");
        // options.request.setRequestHeader("Access-Control-Allow-Headers", "Origin, Content-Type, X-Auth-Token");
      };
      let survey: Model;
      if (formType == 1) {
        // survey = new Model(hbJson);
        survey.locale = "en";
      } else if (formType == 2) {
        // survey = new Model(tpdjson);
        survey.locale = "en";
      } else if (formType == 3) {
        // survey = new Model(cibJson);
        survey.locale = "en";
      } else if (formType == 4) {
        // survey = new Model(hbJson);
        survey.locale = "si";
      }

      survey.onUpdateQuestionCssClasses.add(function (_: any, options: { cssClasses: any; question: { getType: () => string; }; }) {
        const classes = options.cssClasses;
        if (options.question.getType() === "text") {
          classes.root += " input-height";
        }
        if (options.question.getType() === 'comment') {
          classes.root += ' textarea-height';
        }

      });

      survey.addNavigationItem({
        id: 'sv-nav-clear-page',
        title: 'Clear Form',
        action: () => {
          survey.currentPage.questions.forEach((question: { value: any; }) => {
            question.value = undefined;
          });
        },
        css: 'nav-button ',
        innerCss: 'sd-btn nav-input'
      });


      SurveyNG.render("surveyElement", {
        model: survey
      })
      // survey.onComplete.add(this.surveyComplete);
    } else {
      document.querySelector('div#surveyElement').innerHTML = "";
    }
  }
  get f() {
    return this.secondFormGroup.controls;
  }


  clearSelectedPolicyNu() {
    this.claimRequestForm.get('policyNumber').setValue('');
  }

  async changeDigitalFormSelection1(type: string, language: string) {
    let authToken = this.token;
    Survey.ChoicesRestfull.onBeforeSendRequest = function (sender, options) {
      options.request.setRequestHeader("Authorization", "Bearer " + authToken);
    };
    let survey: Model;
    let surveyJson: any = "";
    switch (type) {
      case 'hb':
        surveyJson = await this.getViewHBForm().catch((error) => {
          console.log(error);
        });
        survey = new Model(surveyJson);
        if (language == 'SI') {
          survey.locale = "si";
        }
        break;

      case 'tpd/ppd':
        surveyJson = await this.getViewTPDPPDForm().catch((error) => {
          console.log(error);
        });
        survey = new Model(surveyJson);
        break;

      case 'cib':
        surveyJson = await this.getViewCIBForm().catch((error) => {
          console.log(error);
        });
        survey = new Model(surveyJson);
        break;
      default:
        break;
    }

    survey.onUpdateQuestionCssClasses.add(function (_: any, options: { cssClasses: any; question: { getType: () => string; }; }) {
      const classes = options.cssClasses;
      if (options.question.getType() === "text") {
        classes.root += " input-height";
      }
      if (options.question.getType() === 'comment') {
        classes.root += ' textarea-height';
      }

    });

    survey.showNavigationButtons = false;


    SurveyNG.render("surveyElement", {
      model: survey
    })

  }




  async claimRequestNext() {

    let claimId = this.claimRequestForm.value.claim
    this.loading = true;
    this.isEnableDocumentUploadFormSection = false;
    this.claimRequestForm.markAllAsTouched();


    if (this.claimRequestForm.value.fillOption == 2) {
      this.isEnableDocumentUploadFormSection = false;
      console.log(this.claimRequestForm.value.claim)
      switch (this.claimRequestForm.value.claim) {
        case 3:
        case 4:
          this.changeDigitalFormSelection1('hb', 'EN');
          break;
        case 12:
        case 13:
          this.changeDigitalFormSelection1('hb', 'SI');
          break;
        case 6:
        case 7:
          this.changeDigitalFormSelection1('tpd/ppd', 'EN');
          break;
        case 8:
          this.changeDigitalFormSelection1('cib', 'EN');
          break;

        default:

          break;
      }
    } else if (this.claimRequestForm.value.fillOption == 1) {

      setTimeout(() => {
        this.isEnableDocumentUploadFormSection = true;
      }, 500);

      let originalPolicyNumber = this.claimRequestForm.value.policyNumber;
      let policySplit = originalPolicyNumber.split("/");
      const moreClaimData = {
        claimRequestId: this.claimRequestId,
        policyNumber: policySplit[0] + policySplit[1],
        claimGeneratedCode: this.generatedClaimRequestNumber + "-form"

      }
      this.documentFormData = {
        title: this.claims.find(value => value.id == claimId).name,
        data: moreClaimData,
        isEnableDocView: true
      };


      this.isEnableDocumentUploadFormSection = true;
    } else {
      this.isEnableDocumentUploadFormSection = false;
    }

    // stepper.next();
    this.loading = false;



  }


  insertSignature() {
    this.route.navigateByUrl('/base/service-portal/signature');
  }

  ngAfterViewInit() {

  }

  async secondFormGroupNext() {
    this.isEnableDocumentUploadSection = false;
    let claimId = this.claimRequestForm.value.claim;
    const documentListResponse: any = await this.getRequiredDocumentList(claimId).catch((error) => {
      console.log(error);
    });
    if (documentListResponse.status == 200) {

      const claimRequestDataResponse: any = await this.getClaimRequestById(this.claimRequestId).catch((error) => {
        console.log(error);
      });
      if (claimRequestDataResponse.status == 200) {
        this.generatedClaimRequestNumber = claimRequestDataResponse.payload.claimRequestNumber;


      }
      let originalPolicyNumber = this.claimRequestForm.value.policyNumber;
      let policySplit = originalPolicyNumber.split("/");
      this.documentData = {
        title: this.claims.find(value => value.id == this.claimRequestForm.value.claimType).name,
        claimId: claimId,
        isdocumentUploadable: true,
        state: "view",
        policyNumber: policySplit[0] + policySplit[1],
        claimNumber: this.generatedClaimRequestNumber
      };
      this.isEnableDocumentUploadSection = true;
      // stepper.next();
    }
  }



  async backFromClaimAction(stepper: MatStepper) {
    this.isEnableDocumentUploadSection = false;
    let claimId = this.claimRequestForm.value.claim;
    const documentListResponse: any = await this.getRequiredDocumentList(claimId).catch((error) => {
      console.log(error);
    });
    if (documentListResponse.status == 200) {

      const claimRequestDataResponse: any = await this.getClaimRequestById(this.claimRequestId).catch((error) => {
        console.log(error);
      });
      if (claimRequestDataResponse.status == 200) {
        this.generatedClaimRequestNumber = claimRequestDataResponse.payload.claimRequestNumber;


      }
      let originalPolicyNumber = this.claimRequestForm.value.policyNumber;
      let policySplit = originalPolicyNumber.split("/");
      this.documentData = {
        title: this.claims.find(value => value.id == this.claimRequestForm.value.claimType).name,
        claimId: claimId,
        isdocumentUploadable: true,
        state: "view",
        policyNumber: policySplit[0] + policySplit[1],
        claimNumber: this.generatedClaimRequestNumber
      };
      this.isEnableDocumentUploadSection = true;
      stepper.previous();
    }
  }

  onClaimTypeChange() {
    this.claimRequestForm.get('claim').reset();
  }


  backFromDocumentUpload(stepper: MatStepper) {
    if (this.claimRequestForm.get('fillOption').value == 2) {
      this.isEnableDocumentUploadSection = false;
    } else {
      this.isEnableDocumentUploadSection = true;
      this.isEnableDocumentUploadFormSection = true;
    }

    this.claimRequestNext();
    stepper.previous();

  }



  onSelectClaimType($event) {
    switch ($event.value) {
      case 10:
      case 9:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 11:
      case 12:
      case 13:
        this.claimRequestForm.get('claimType').setValue(2);
        break;
      case 1:
      case 2:
        this.claimRequestForm.get('claimType').setValue(1);
        break;
      default:
        this.claimRequestForm.get('claimType').reset();
        break;
    }

    this.setFillOptionOnClaim($event.value);
  }

  setFillOptionOnClaim(claimId: number) {
    this.claimRequestForm.get('fillOption').reset();
    switch (claimId) {
      case 10:
      case 9:
      case 11:
      case 1:
      case 2:
      case 5:
        this.claimRequestForm.get('fillOption').setValue(1);
        break;
      default:
        break;
    }
  }

  // request/response - api call
  async getRequiredDocumentList(claimId: number) {
    const paylaod = {
      token: this.token,
      claimId: claimId
    }
    return new Promise((resolve, reject) => {
      this.digitalFormSubscription = this.aspServiceService.getRequiredDocumentList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async onSelectActiveBankBranch($event) {
    console.log($event);
    const onBranchListResponse: any = await this.getBranchListByBankId($event.value).catch((error) => {
      console.log(error);
    });
    if (onBranchListResponse.status == 200) {
      this.branchList = onBranchListResponse.payload;
    }

  }
  async onSelectActiveBankBranchSet(data: any) {
    const onBranchListResponse: any = await this.getBranchListByBankId(data.bankCode).catch((error) => {
      console.log(error);
    });
    if (onBranchListResponse.status == 200) {
      this.branchList = onBranchListResponse.payload;
      this.claimRequestForm.patchValue({
        branchName: data.bankBranchCode,
      });

    }
  }
  async onSelectHospitalSet(data: any) {
    const HospitalListResponse: any = await this.getHospitalList().catch((error) => {
      console.log(error);
    });
    if (HospitalListResponse.status == 200) {
      this.hospitalList = HospitalListResponse.payload;

      console.log(this.hospitalList, 'hospitalList Response');
      console.log(data.hospitalId, 'hospital id');


      this.claimRequestForm.patchValue({
        hospitalName: data.hospitalId,
      });
    }
  }
  async getClaimList() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getRejectReasons() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getRejectReasons(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getJobAssignFeatures() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getJobAssignFeatures(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getPendingReasons() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getPendingReasons(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  
  async getClaimRequestById(claimRequestId: number) {
    const paylaod = {
      token: this.token,
      claimRequestId: claimRequestId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimRequestByClaimId(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getHospitalList() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getHospitalList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getClaimType() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimTypes(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getActiveBankList() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getActiveBankList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getBranchListByBankId(bankId: number) {
    const paylaod = {
      token: this.token,
      bankCode: bankId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getActiveBankBranchList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getClaimTypes() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.digitalFormSubscription = this.aspServiceService.getClaimTypes(paylaod).subscribe(response => {
        console.log(response);

      }, error => {
        reject(false);
      });
    });
  }
  async getViewHBForm() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService.getViewHBForm(paylaod).subscribe(response => {
        resolve(response.payload);
      }, error => {
        reject(error);
      });
    });
  }
  async getViewTPDPPDForm() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService.getViewTPDPPDForm(paylaod).subscribe(response => {
        resolve(response.payload);
      }, error => {
        reject(error);
      });
    });
  }
  async getViewCIBForm() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService.getViewCIBForm(paylaod).subscribe(response => {
        resolve(response.payload);
      }, error => {
        reject(error);
      });
    });
  }



  validateAllFormFields(formGroup: FormGroup) {
    //{1}
    Object.keys(formGroup.controls).forEach((field) => {
      //{2}
      const control = formGroup.get(field); //{3}
      if (control instanceof FormGroup || control instanceof FormGroup) {
        //{4}
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        //{5}
        control.markAsTouched({ onlySelf: true });
        this.validateAllFormFields(control); //{6}
      }
    });
  }
  
  async loadSavedCreditnoteFilesFromClaimRequest(requestId: number) {
    this.loading = true;
    let dmsPayloadModel: DmsFilesRetrieve = { policyNo: this.claimRequestData.policyNumber.replace('/', ''), contractNo: this.claimRequestData.claimRequestNumber + '-creditNote' };
    const documentretreiveResponse: any = await this.getClaimDocuments(dmsPayloadModel).catch((error) => {
      console.log(error);
    });
    if (documentretreiveResponse.status == 200) {

      this.otherDocumentEditable = false;
      this.loading = false;
      let documentListFromDMS = documentretreiveResponse.payload[0];
      for (let j = 0; j < documentListFromDMS.files.length; j++) {
        this.selectedFiles.push(documentListFromDMS.files[j].file);
        this.files.push(documentListFromDMS.files[j].name);
      }
      this.creditNoteFiles = { fileNameArray: this.files, files: this.selectedFiles }
      this.files = [];
      this.selectedFiles = [];
    } else {
      this.loading = false;
    }
    this.loading = false;

  }
  
  async loadSavedpendingLetterFilesFromClaimRequest(requestId: number) {
    this.loading = true;
    let dmsPayloadModel: DmsFilesRetrieve = { policyNo: this.claimRequestData.policyNumber.replace('/', ''), contractNo: this.claimRequestData.claimRequestNumber + '-pendingLetter' };
    const documentretreiveResponse: any = await this.getClaimDocuments(dmsPayloadModel).catch((error) => {
      console.log(error);
    });
    if (documentretreiveResponse.status == 200) {
      this.loading = false;
      let documentListFromDMS = documentretreiveResponse.payload[0];
      for (let j = 0; j < documentListFromDMS.files.length; j++) {
        this.selectedFiles.push(documentListFromDMS.files[j].file);
        this.files.push(documentListFromDMS.files[j].name);
      }
      this.pendingLetterFiles = { fileNameArray: this.files, files: this.selectedFiles }
      this.files = [];
      this.selectedFiles = [];
    } else {
      this.loading = false;
    }
    this.loading = false;

  }

  async loadSavedRejectionLetterFilesFromClaimRequest(requestId: number) {
    this.loading = true;
    let dmsPayloadModel: DmsFilesRetrieve = { policyNo: this.claimRequestData.policyNumber.replace('/', ''), contractNo: this.claimRequestData.claimRequestNumber + '-rejectionLetter' };
    const documentretreiveResponse: any = await this.getClaimDocuments(dmsPayloadModel).catch((error) => {
      console.log(error);
    });
    if (documentretreiveResponse.status == 200) {
      this.loading = false;
      let documentListFromDMS = documentretreiveResponse.payload[0];
      for (let j = 0; j < documentListFromDMS.files.length; j++) {
        this.selectedFiles.push(documentListFromDMS.files[j].file);
        this.files.push(documentListFromDMS.files[j].name);
      }
      this.rejectionLetterFiles = { fileNameArray: this.files, files: this.selectedFiles }
      this.files = [];
      this.selectedFiles = [];
    } else {
      this.loading = false;
    }
    this.loading = false;

  }

  
  public get policyNumberToRequest() : boolean {
    if (this.claimRequestForm.value.policyNumber == null ||
       this.claimRequestForm.value.policyNumber == "" ||
        this.claimRequestForm.value.policyNumber == undefined) {
      return false;
      
    } else {
      return true;
    }
     
  }

  
  public get policyNumber() : string {
    return this.claimRequestForm.value.policyNumber;
  }

  viewPendingLetterDocuments() {
    let documentEditable = false;
    const dialogRef = this.dialog.open(DocumentViewerDialogComponent, {
      width: '95%',
      data: {
        docs: this.pendingLetterFiles,
        isdocumentUploadable: documentEditable,
        documentType: 'Letter Of Pending'
      },
      disableClose: true,

    });

    dialogRef.afterClosed().subscribe(async result => {
      this.pendingLetterFiles.fileNameArray = result.responseFileNames;
      this.pendingLetterFiles.files = result.responseFiles;
      
    });
  }

  viewrejectionLetterDocuments() {
    let documentEditable = false;
    const dialogRef = this.dialog.open(DocumentViewerDialogComponent, {
      width: '95%',
      data: {
        docs: this.rejectionLetterFiles,
        isdocumentUploadable: documentEditable,
        documentType: 'Rejection Letter'
      },
      disableClose: true,

    });

    dialogRef.afterClosed().subscribe(async result => {
      this.rejectionLetterFiles.fileNameArray = result.responseFileNames;
      this.rejectionLetterFiles.files = result.responseFiles;
    });
  }
  


}
