import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewClaimRequestComponent } from './view-claim-request.component';

describe('ViewClaimRequestComponent', () => {
  let component: ViewClaimRequestComponent;
  let fixture: ComponentFixture<ViewClaimRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewClaimRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewClaimRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
