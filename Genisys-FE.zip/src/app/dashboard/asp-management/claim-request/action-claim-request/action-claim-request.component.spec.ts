import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActionClaimRequestComponent } from './action-claim-request.component';

describe('ActionClaimRequestComponent', () => {
  let component: ActionClaimRequestComponent;
  let fixture: ComponentFixture<ActionClaimRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ActionClaimRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ActionClaimRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
