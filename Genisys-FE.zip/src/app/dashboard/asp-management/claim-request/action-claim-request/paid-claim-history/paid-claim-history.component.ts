import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ApiReportService } from '@app/shared/services/api-report/api-report.service';
import { AspModuleService } from '@app/shared/services/asp-module/asp-module.service';
import { AuthService } from '@app/shared/services/auth/auth.service';
import { PopupService } from '@app/shared/services/popup/popup.service';

@Component({
  selector: 'app-paid-claim-history',
  templateUrl: './paid-claim-history.component.html',
  styleUrls: ['./paid-claim-history.component.scss']
})
export class PaidClaimHistoryComponent implements OnInit {
  isEnableEdit: boolean = false;
  displayedColumns = ['claimOf', 'policyNumber', 'agent', 'agentName',
    'salesBranch', 'sumAssuredOfBenifits', 'occuredOn', 'trnAmountCy', 'policyHolder',
    'claimedLifeAssured', 'proffectionActivity', 'noOfPreviousClaim',
    'previousClaimTotalSettelment', 'policyAgentAtClaimDate',
    'noOfDaysHospitalizedInStandardUnit', 'placeOfClaim', 'causeOfClaim', 'xGracia', 'claimType'];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  token: any;
  dialogRef: MatDialogRef<any>;

  @Input() claimRequestId: number = 0;

  constructor(
    public dialog: MatDialog,
    private popupservice: PopupService,
    private _snackBar: MatSnackBar,
    private aspService: AspModuleService,
    private authService: AuthService
  ) {
    this.token = this.authService.getCurrentUserDetails().access_token;
  }

  dataSource = new MatTableDataSource([]);


  ngOnInit(): void {
    this.getAllPaidClaimByClaimRequestNumber(this.claimRequestId);
  }

  
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }


  	async getAllPaidClaimByClaimRequestNumber(claimRequestId: number) {

    const paidClaimResponse: any = await this.getPaidClaimDetails(claimRequestId).catch((error) => {
      console.log(error);
    });
    if (paidClaimResponse.status == 200 && paidClaimResponse.payload != null) {
      console.log("paidClaim", paidClaimResponse.payload);
      
      this.dataSource = new MatTableDataSource(paidClaimResponse.payload);
      this.dataSource.paginator = this.paginator;
    }
  }

 


  async getPaidClaimDetails(claimRequestNu: number) {
    const paylaod = {
      token: this.token,
      claimRequestId: claimRequestNu
    }
    console.log(paylaod);
    
    return new Promise((resolve, reject) => {
      this.aspService
        .getPaidClaimDetailsByClaimRequestId(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }




}
