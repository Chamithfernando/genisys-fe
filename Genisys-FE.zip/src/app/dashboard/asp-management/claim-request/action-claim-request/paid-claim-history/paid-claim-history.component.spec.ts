import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaidClaimHistoryComponent } from './paid-claim-history.component';

describe('PaidClaimHistoryComponent', () => {
  let component: PaidClaimHistoryComponent;
  let fixture: ComponentFixture<PaidClaimHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaidClaimHistoryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PaidClaimHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
