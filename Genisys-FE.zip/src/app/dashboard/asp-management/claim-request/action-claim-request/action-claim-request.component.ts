import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { StepperOrientation } from '@angular/cdk/stepper';
import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, UntypedFormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatStepper } from '@angular/material/stepper';
import { ActivatedRoute, Router } from '@angular/router';
import { AspModuleService } from '@app/shared/services/asp-module/asp-module.service';
import { AuthService } from '@app/shared/services/auth/auth.service';
import { Observable, Subscription } from 'rxjs';
import { SurveyNG, Model } from "survey-angular";
import * as Survey from 'survey-angular';
import { DocumentViewerDialogComponent } from '../upload-documents/document-viewer-dialog/document-viewer-dialog.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ImageCompresserService } from '@app/shared/services/image-compresser/image-compresser.service';
import { take } from 'rxjs/operators';
import { EncryptDecryptService } from '@app/shared/services/encrypt-decrypt-service/encrypt-decrypt.service';
import { DmsPayload } from '../upload-claim-form/upload-claim-form.component';
import { element } from 'protractor';
import Swal from 'sweetalert2';

const creatorOptions = {
  showLogicTab: true,
  isAutoSave: true
};

interface DmsFiles {
  extension: string,
  name: string,
  file: any
}
interface DmsRequestDTO {
  type: string,
  policyNo: string,
  contractNo: string,
  files: DmsFiles[]
}

interface DmsFilesRetrieve {
  policyNo: string,
  contractNo: string
}

export interface featuresComponent {
  id: number;
  name: string;
}

export interface InsuranceRequirement {
  name: string;
}

export interface type {
  id: number;
  name: string;
}

export interface FileData {
  fileNameArray: any;
  files: any;
}
const ELEMENT_DATA: FileData[] = [
];

@Component({
  selector: 'app-action-claim-request',
  templateUrl: './action-claim-request.component.html',
  styleUrls: ['./action-claim-request.component.scss']
})
export class ActionClaimRequestComponent implements OnInit, AfterViewInit {

  @ViewChild('fileInput') fileInputVariable: ElementRef<HTMLInputElement>;
  @ViewChild('synopsisInput') synopsisInputVariable: ElementRef<HTMLInputElement>;
  @ViewChild('docsynopsisupload') docsynopsisuploadElement: ElementRef;
  @ViewChild('creditNoteInput') creditNoteInputElement: ElementRef<HTMLInputElement>;
  @ViewChild('pendingLetterInput') pendingLetterInputElement: ElementRef<HTMLInputElement>;
  @ViewChild('rejectionLetterInput') rejectionLetterInputElement: ElementRef<HTMLInputElement>;
  @ViewChild('decisionSummary') decisionSummary: ElementRef<HTMLInputElement>;

  token: any;
  loading: any;
  selectedIndex: number;

  documentFormData: any;

  claimRequestId: number
  unstructuredClaim = 1;
  structuredClaim = 2;
  agentCode: string;
  isEnableDocumentUploadSection = false;

  dialogRef: MatDialogRef<any>;
  validationMessage: string = "Please verify the required file type and Maximum file size is 10MB";
  validationFileSize: number = 10485760;

  noFileSelected: string = "Please submit all required documents !";
  isFileValid: boolean = false;
  internalStatus: any;
  selectedFiles: any = [];
  documentList: any = [];
  submitReadyFileList: any = [];
  files = [];
  displayedColumns: string[] = ['documentType', 'fileNames', 'edit', 'delete'];
  dataSource = [...ELEMENT_DATA];

  otherFiles: FileData;
  synopsisFiles: FileData;
  creditNoteFiles: FileData;
  pendingLetterFiles: FileData;
  rejectionLetterFiles: FileData;

  isEnableDocumentUploadFormSection = false;
  claimRequestUserAction = 0;
  isFirstLevelApproval = true;
  hasClaimNumber = false;
  hasOtherComments = false;
  isSecondLevelAssign = false;
  isCallCenterAssign = false;
  isAdvisorAssign = false;
  isFinanceAssign = false;
  documentData: any;
  generatedClaimRequestNumber: string;
  claimRequestAction: boolean;

  filteredOptions: any;

  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;
  claimRequestForm: FormGroup;
  actionClaimRequest: FormGroup;
  actionFirstLevelReview: FormGroup;
  returnRequestForm: FormGroup;
  actionCallcenterReview: FormGroup;
  decisionReceivedClaimRequest: FormGroup;
  claimRequestData: any;

  isVisibleBankBranchNoAvilable: boolean = false

  emailPattern = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$"

  mainTypes: type[] = [
    {
      id: 1,
      name: 'Life'
    },
    {
      id: 2,
      name: 'Group Life'
    }
  ];

  userOptions: type[] = [
    {
      id: 1,
      name: 'Document Upload'
    },
    {
      id: 2,
      name: 'Fill E-Form'
    }
  ];

  claimTypes: any;
  claims: any;
  rejectReasons: any;
  pendingReasons: any;
  assignableUsers: any;
  claimRequestNumber: any;
  bankDetailsEditable = false;
  showReject = false;
  showPending = false;
  showApprove = false;
  showAssign = false;
  firstLevelEditable = false;
  showFirstLevelReview = false;
  showCallCenterReview = false;
  showFinanceReview = false;
  showSecondLevelAction = false;
  otherDocumentEditable = false;
  synopsisDocumentEditable = false;
  creditNoteEditable = false;
  pendingLetterEditable = false;
  rejectionLetterEditable = false;
  approvalReceived = false;
  initialCallcenterRemarkReceived = false;
  pendingReceived = false;
  rejectReceived = false;
  callCenterUpdated = false;
  showSecondLevelDecisionReceived = false;
  decisionTakenUser: string;
  claimActionFeatures: featuresComponent[] = [];
  policyListForClaim: string[] = [];
  activeBankList: any;
  hospitalList: any;
  branchList: any;

  contactNoPattern = "[0-9]{10}";
  orientation: StepperOrientation = 'horizontal';



  insuranceRequirements: InsuranceRequirement[] = [
    { name: 'Health' },
    { name: 'Protection' },
    { name: 'Savings' },
    { name: 'Retirement' },
    { name: 'Investment' }
  ];
  public personNameForm: any;
  digitalFormSubscription: Subscription;

  claimfilteredOptions: Observable<any[]>;


  constructor(
    private formBuilder: FormBuilder,
    private _formBuilder: FormBuilder,
    private route: Router,
    public dialog: MatDialog,
    private _snackBar: MatSnackBar,
    private activatedRoute: ActivatedRoute,
    private encryptDecryptService: EncryptDecryptService,
    private breakPointObserver: BreakpointObserver,
    private authService: AuthService,
    private router: Router,
    private elements: ElementRef,
    private aspServiceService: AspModuleService,
    private imageCompressor: ImageCompresserService) {
    breakPointObserver.observe([
      Breakpoints.XSmall,
      Breakpoints.Small
    ]).subscribe(result => {
      this.orientation = 'vertical';
    });

    this.token = this.authService.getCurrentUserDetails().access_token;

    this.claimRequestForm = _formBuilder.group({
      policyNumber: ['', Validators.required],
      mainType: ['', Validators.required],
      claim: ['', Validators.required],
      claimType: ['', Validators.required],
      fillOption: ['', Validators.required],
      claimant: ['', Validators.required],
      claimAmount: ['', Validators.required],
      claimantMobileNu: ['', Validators.pattern(this.contactNoPattern)],
      claimantEmail: ['', Validators.pattern(this.emailPattern)],
      remark: [''],
      accountHolderName: ['', Validators.required],
      accountNumber: ['', Validators.required],
      bankName: ['', Validators.required],
      branchName: ['', Validators.required],
      hospitalName: ['', Validators.required],
      dateOfAdmition: ['', Validators.required],
      aditionalRemark: ['']
    });

    this.actionFirstLevelReview = _formBuilder.group({
      claimNumber: ['', Validators.required],
      sumAssured: ['', Validators.required],
      paymentMode: ['', Validators.required],
      decisionRemark: [''],
      decisionSummary: ['', Validators.required],
      secondApproval: ['', Validators.required],
      action: [''],
    });

    this.returnRequestForm = _formBuilder.group({
      decisionRemark: ['', Validators.required],
    });

    this.actionCallcenterReview = _formBuilder.group({
      claimNumber: [''],
      sumAssured: [''],
      paymentMode: [''],
      decisionSummary: [''],
      secondApproval: [''],
      decisionRemark: ['']
    });

    this.actionClaimRequest = this._formBuilder.group({
      claimNumber: [''],
      sumAssured: [''],
      paymentMode: [''],
      decisionSummary: [''],
      action: ['', Validators.required]
    });

    this.decisionReceivedClaimRequest = this._formBuilder.group({
      claimNumber: [''],
      sumAssured: [''],
      paymentMode: [''],
      decisionSummary: [''],
      secondApproval: [''],
      decisionRemark: [''],
      action: ['']
    });
  }

  async ngOnInit() {

    this.loading = true;
    const claimRequestUrl: string = this.activatedRoute.snapshot.params.claimId;
    console.log(claimRequestUrl);

    const name = decodeURIComponent(claimRequestUrl);
    console.log(name);

    this.claimRequestId = Number(name.split('%').pop());
    console.log(this.claimRequestId);

    this.activatedRoute.queryParamMap.subscribe((p: any) => this.selectedIndex = Number(p['params'].navigateIndex));
    let actionRequest;
    this.activatedRoute.queryParamMap.subscribe((p: any) => actionRequest = p['params'].action);
    if (actionRequest == "false") {
      this.claimRequestAction = false;
    } else if (actionRequest == "true") {
      this.claimRequestAction = true;
    }
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });

    this.secondFormGroup = this.formBuilder.group({
      formType: new FormControl(null),
      digitalFormSelection: new FormControl(null),
      formUpload: new FormControl(null)
    });


    const claimListResponse: any = await this.getClaimList().catch((error) => {
      console.log(error);
    });
    if (claimListResponse.status == 200) {
      this.claims = claimListResponse.payload;
    }


    const claimTypeResponse: any = await this.getClaimType().catch((error) => {
      console.log(error);
    });
    if (claimTypeResponse.status == 200) {
      this.claimTypes = claimTypeResponse.payload;
    }

    const bankListResponse: any = await this.getActiveBankList().catch((error) => {
      console.log(error);
    });
    if (bankListResponse.status == 200) {
      this.activeBankList = bankListResponse.payload;
      console.log(this.activeBankList);

    }

    const HospitalListResponse: any = await this.getHospitalList().catch((error) => {
      console.log(error);
    });
    if (HospitalListResponse.status == 200) {
      this.hospitalList = HospitalListResponse.payload;
    }


    const claimRequestDataResponse: any = await this.getClaimRequestById(this.claimRequestId).catch((error) => {
      console.log(error);
    });
    if (claimRequestDataResponse.status == 200) {
      const claimData: any = claimRequestDataResponse.payload;
      console.log(claimData);
      this.claimRequestData = claimData;
      this.setData(claimData);

    }
    this.loading = false;
    this.claimRequestNext();
    this.secondFormGroupNext();
    this.showPending = true;
    this.showApprove = true;
    this.showReject = true;
    this.showAssign = true;

    const currentAssignResponse: any = await this.getCurrentAssignDetails().catch((error) => {
      console.log(error);
    });
    if (currentAssignResponse.status == 200) {
      this.internalStatus = currentAssignResponse.payload.internalStatus;
      let previousAssignedUser = currentAssignResponse.payload.previousAssignedUserId;
      let department = currentAssignResponse.payload.departmentId;
      let assignedLevel = currentAssignResponse.payload.assignedLevelId;
      let additionalStatus = currentAssignResponse.payload.additionalStatus
      if (department == 1 && assignedLevel == 1 && this.internalStatus == "Assigned" && additionalStatus != "Appealed") {
        this.showFirstLevelReview = true;
        this.showSecondLevelAction = false;
        this.showSecondLevelDecisionReceived = false;
        this.showCallCenterReview = false;
        this.firstLevelEditable = false;
        this.showFinanceReview = false;

        this.synopsisDocumentEditable = true;
        this.otherDocumentEditable = true;
        const claimReviewResponse: any = await this.getClaimReviewDetails().catch((error) => {
          console.log(error);
        });
        if (claimListResponse.status == 200) {
          
          this.actionClaimRequest.patchValue({
            decisionSummary: [claimReviewResponse.payload.decisionSummary]
          })
        }
      } else if (department == 1 && assignedLevel == 2 && this.internalStatus == "Assigned") {
        this.showFirstLevelReview = false;
        this.showSecondLevelAction = true;
        this.showSecondLevelDecisionReceived = false;
        this.showCallCenterReview = false;
        this.showFinanceReview = false;



        const claimReviewResponse: any = await this.getClaimReviewDetails().catch((error) => {
          console.log(error);
        });
        if (claimReviewResponse.status == 200) {
          this.actionClaimRequest = this._formBuilder.group({
            claimNumber: [claimReviewResponse.payload.claimNumber],
            sumAssured: [claimReviewResponse.payload.sumAssured],
            paymentMode: [claimReviewResponse.payload.paymentMode],
            decisionSummary: [claimReviewResponse.payload.decisionSummary],
            action: ['', Validators.required]
          });

        }
        await this.loadSavedOtherFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedSynopsisFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedpendingLetterFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedRejectionLetterFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedCreditnoteFilesFromClaimRequest(this.claimRequestId)
        if (this.synopsisFiles == null) {
          this.synopsisDocumentEditable = true;
        }
        if (this.otherFiles == null) {
          this.otherDocumentEditable = true;
        }
        this.decisionSummary.nativeElement.style.height = 'auto';
        this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;


      } else if (department == 3) {
        this.showFirstLevelReview = false;
        this.showSecondLevelAction = false;
        this.showSecondLevelDecisionReceived = false;
        this.showCallCenterReview = true;
        this.showFinanceReview = false;
        const claimReviewResponse: any = await this.getClaimReviewDetails().catch((error) => {
          console.log(error);
        });
        if (claimListResponse.status == 200) {
          this.actionCallcenterReview = this._formBuilder.group({
            claimNumber: [claimReviewResponse.payload.claimNumber],
            sumAssured: [claimReviewResponse.payload.sumAssured],
            paymentMode: [claimReviewResponse.payload.paymentMode],
            decisionSummary: [claimReviewResponse.payload.decisionSummary],
            decisionRemark: ['', Validators.required]
          });
        }

        this.loadSavedSynopsisFilesFromClaimRequest(this.claimRequestId);
        this.loadSavedOtherFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedpendingLetterFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedRejectionLetterFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedCreditnoteFilesFromClaimRequest(this.claimRequestId)

        this.decisionSummary.nativeElement.style.height = 'auto';
        this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;
      } else if (department == 2) {
        this.showFirstLevelReview = false;
        this.showSecondLevelAction = false;
        this.showSecondLevelDecisionReceived = false;
        this.showCallCenterReview = false;
        this.showFinanceReview = true;
        const claimReviewResponse: any = await this.getClaimReviewDetails().catch((error) => {
          console.log(error);
        });
        if (claimListResponse.status == 200) {
          this.actionCallcenterReview = this._formBuilder.group({
            claimNumber: [claimReviewResponse.payload.claimNumber],
            sumAssured: [claimReviewResponse.payload.sumAssured],
            paymentMode: [claimReviewResponse.payload.paymentMode],
            decisionSummary: [claimReviewResponse.payload.decisionSummary],
            decisionRemark: ['', Validators.required]
          });
        }
        await this.loadSavedSynopsisFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedOtherFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedCreditnoteFilesFromClaimRequest(this.claimRequestId);

        this.decisionSummary.nativeElement.style.height = 'auto';
        this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;
      } else {
        this.showFirstLevelReview = false;
        this.showSecondLevelAction = false;
        this.showSecondLevelDecisionReceived = true;
        this.showCallCenterReview = false;
        this.showFinanceReview = false;
        const claimReviewResponse: any = await this.getClaimReviewDetails().catch((error) => {
          console.log(error);
        });
        if (claimListResponse.status == 200) {
          this.decisionReceivedClaimRequest = this._formBuilder.group({
            claimNumber: [claimReviewResponse.payload.claimNumber],
            sumAssured: [claimReviewResponse.payload.sumAssured],
            paymentMode: [claimReviewResponse.payload.paymentMode],
            decisionSummary: [claimReviewResponse.payload.decisionSummary],
            secondApproval: [''],
            decisionRemark: [''],
            action: ['']
          });
        }
        const claimDecisionUserResponse: any = await this.getClaimDecisionUserDetails(previousAssignedUser).catch((error) => {
          console.log(error);
        });
        if (claimListResponse.status == 200) {
          this.decisionTakenUser = claimDecisionUserResponse.payload.name
        }
        this.loadSavedSynopsisFilesFromClaimRequest(this.claimRequestId);
        await this.loadSavedOtherFilesFromClaimRequest(this.claimRequestId);
        if (this.otherFiles == null) {
          this.otherDocumentEditable = true;
        }
        await this.loadSavedpendingLetterFilesFromClaimRequest(this.claimRequestId);
        if (this.pendingLetterFiles == null) {
          this.pendingLetterEditable = true;
        }

        await this.loadSavedRejectionLetterFilesFromClaimRequest(this.claimRequestId);
        if (this.rejectionLetterFiles == null) {
          this.rejectionLetterEditable = true;
        }

        await this.loadSavedCreditnoteFilesFromClaimRequest(this.claimRequestId);
        if (this.creditNoteFiles == null) {
          this.creditNoteEditable = true;
        }

        if (this.internalStatus == "Pending-Call Center Updated") {
          this.initialCallcenterRemarkReceived = false;
          this.approvalReceived = false;
          this.pendingReceived = true;
          this.rejectReceived = false;
          this.callCenterUpdated = true;
          this.decisionReceivedClaimRequest = this._formBuilder.group({
            claimNumber: [claimReviewResponse.payload.claimNumber],
            sumAssured: [claimReviewResponse.payload.sumAssured],
            paymentMode: [claimReviewResponse.payload.paymentMode],
            decisionSummary: [claimReviewResponse.payload.decisionSummary],
            secondApproval: [''],
            decisionRemark: [''],
            pendingReason: ['', Validators.required],
            action: ['', Validators.required]
          });
          const pendingreasonResponse: any = await this.getPendingReasons().catch((error) => {
            console.log(error);
          });
          if (pendingreasonResponse.status == 200) {
            this.pendingReasons = pendingreasonResponse.payload;
          }
        } else if (this.internalStatus == "Rejected - Call Center Updated") {

          this.initialCallcenterRemarkReceived = false;
          this.approvalReceived = false;
          this.pendingReceived = false;
          this.rejectReceived = true;
          this.callCenterUpdated = true;
          this.decisionReceivedClaimRequest = this._formBuilder.group({
            claimNumber: [claimReviewResponse.payload.claimNumber],
            sumAssured: [claimReviewResponse.payload.sumAssured],
            paymentMode: [claimReviewResponse.payload.paymentMode],
            decisionSummary: [claimReviewResponse.payload.decisionSummary],
            secondApproval: [''],
            decisionRemark: [''],
            rejectReason: ['', Validators.required],
            action: ['', Validators.required]
          });
          const rejectreasonResponse: any = await this.getRejectReasons().catch((error) => {
            console.log(error);
          });
          if (rejectreasonResponse.status == 200) {
            this.rejectReasons = rejectreasonResponse.payload;
          }
        } else if (this.internalStatus == "Intimate - Call Center Updated") {
          this.initialCallcenterRemarkReceived = true;
          this.approvalReceived = false;
          this.pendingReceived = false;
          this.rejectReceived = false;
          this.callCenterUpdated = true;
        } else if (this.internalStatus == "Approved - Call Center Updated") {
          await this.loadSavedCreditnoteFilesFromClaimRequest(this.claimRequestId);
          this.initialCallcenterRemarkReceived = false;
          this.approvalReceived = true;
          this.pendingReceived = false;
          this.rejectReceived = false;
          this.callCenterUpdated = true;
        } else if (this.internalStatus == "Approved") {
          this.initialCallcenterRemarkReceived = false;
          this.approvalReceived = true;
          this.pendingReceived = false;
          this.rejectReceived = false;
        } else if (this.internalStatus == "Pending") {
          this.initialCallcenterRemarkReceived = false;
          this.approvalReceived = false;
          this.pendingReceived = true;
          this.rejectReceived = false;
          this.decisionReceivedClaimRequest = this._formBuilder.group({
            claimNumber: [claimReviewResponse.payload.claimNumber],
            sumAssured: [claimReviewResponse.payload.sumAssured],
            paymentMode: [claimReviewResponse.payload.paymentMode],
            decisionSummary: [claimReviewResponse.payload.decisionSummary],
            secondApproval: [''],
            decisionRemark: [''],
            pendingReason: ['', Validators.required],
            action: ['', Validators.required]
          });
          const pendingreasonResponse: any = await this.getPendingReasons().catch((error) => {
            console.log(error);
          });
          if (pendingreasonResponse.status == 200) {
            this.pendingReasons = pendingreasonResponse.payload;
          }
        } else if (this.internalStatus == "Pending Clearance") {
          this.initialCallcenterRemarkReceived = false;
          this.approvalReceived = false;
          this.pendingReceived = true;
          this.rejectReceived = false;
          this.callCenterUpdated = true;
          this.decisionReceivedClaimRequest = this._formBuilder.group({
            claimNumber: [claimReviewResponse.payload.claimNumber],
            sumAssured: [claimReviewResponse.payload.sumAssured],
            paymentMode: [claimReviewResponse.payload.paymentMode],
            decisionSummary: [claimReviewResponse.payload.decisionSummary],
            secondApproval: [''],
            decisionRemark: [''],
            pendingReason: ['', Validators.required],
            action: ['', Validators.required]
          });
          const pendingreasonResponse: any = await this.getPendingReasons().catch((error) => {
            console.log(error);
          });
          if (pendingreasonResponse.status == 200) {
            this.pendingReasons = pendingreasonResponse.payload;
          }
        } else if (additionalStatus == "Appealed" && this.internalStatus == "Assigned") {
          this.initialCallcenterRemarkReceived = false;
          this.approvalReceived = false;
          this.pendingReceived = false;
          this.rejectReceived = true;
          this.callCenterUpdated = true;
          this.decisionReceivedClaimRequest = this._formBuilder.group({
            claimNumber: [claimReviewResponse.payload.claimNumber],
            sumAssured: [claimReviewResponse.payload.sumAssured],
            paymentMode: [claimReviewResponse.payload.paymentMode],
            decisionSummary: [claimReviewResponse.payload.decisionSummary],
            secondApproval: [''],
            decisionRemark: [''],
            rejectReason: ['', Validators.required],
            action: ['', Validators.required]
          });
          const rejectreasonResponse: any = await this.getRejectReasons().catch((error) => {
            console.log(error);
          });
          if (rejectreasonResponse.status == 200) {
            this.rejectReasons = rejectreasonResponse.payload;
          }
        } else if (this.internalStatus == "Rejected") {
          this.initialCallcenterRemarkReceived = false;
          this.approvalReceived = false;
          this.pendingReceived = false;
          this.rejectReceived = true;
          this.decisionReceivedClaimRequest = this._formBuilder.group({
            claimNumber: [claimReviewResponse.payload.claimNumber],
            sumAssured: [claimReviewResponse.payload.sumAssured],
            paymentMode: [claimReviewResponse.payload.paymentMode],
            decisionSummary: [claimReviewResponse.payload.decisionSummary],
            secondApproval: [''],
            decisionRemark: [''],
            rejectReason: ['', Validators.required],
            action: ['', Validators.required]
          });
          const rejectreasonResponse: any = await this.getRejectReasons().catch((error) => {
            console.log(error);
          });
          if (rejectreasonResponse.status == 200) {
            this.rejectReasons = rejectreasonResponse.payload;
          }
        }

        this.decisionSummary.nativeElement.style.height = 'auto';
        this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;
      }
    }


  }

  ngAfterViewInit() {
  }


  public get calaimAmount(): string {
    return this.claimRequestForm.value.claimAmount;
  }
  public get firstLevelReviewSumAssured(): string {
    return this.actionFirstLevelReview.value.sumAssured;
  }
  public get actionClaimRequestSumAssured(): string {
    return this.actionClaimRequest.value.sumAssured;
  }
  public get actionCallcenterReviewSumAssured(): string {
    return this.actionCallcenterReview.value.sumAssured;
  }
  public get decisionReceivedSumAssured(): string {
    return this.decisionReceivedClaimRequest.value.sumAssured;
  }

  setData(data: any) {
    const remarkData: any[] = data.remarkList;
    let claimRemarkObj;
    if (remarkData.length == 0) {
      claimRemarkObj = "";
    } else {
      claimRemarkObj = remarkData.pop();
    }

    this.claimRequestNumber = data.claimRequestNumber;

    this.claimRequestForm.patchValue({
      policyNumber: data.policyNumber,
      mainType: data.mainTypeId,
      claim: data.claimListId,
      claimType: data.claimTypeId,
      fillOption: data.fillOption,
      claimant: data.claimantsName,
      claimAmount: data.claimAmount,
      claimantMobileNu: data.claimantsMobileNumber,
      claimantEmail: data.claimantsEmail,
      remark: claimRemarkObj.remark,
      accountHolderName: data.accountHolderName,
      accountNumber: data.accountNumber,
      bankName: data.bankCode,
      dateOfAdmition: data.dateOfAdmission
    });
    this.onSelectActiveBankBranchSet(data);
    this.onSelectHospitalSet(data);
    this.generatedClaimRequestNumber = data.claimRequestNumber;

    this.claimRequestForm.disable();
  }

  enablebankDetails() {
    this.claimRequestForm.controls['accountHolderName'].enable();
    this.claimRequestForm.controls['accountNumber'].enable();
    this.claimRequestForm.controls['bankName'].enable();
    this.claimRequestForm.controls['branchName'].enable();
    this.claimRequestForm.controls['aditionalRemark'].enable();
    this.bankDetailsEditable = true;
  }

  updateBankDetails() {
    console.log(this.claimRequestForm.value.aditionalRemark)
    if (this.claimRequestForm.value.aditionalRemark == null || this.claimRequestForm.value.aditionalRemark == "") {
      this._snackBar.open("Remark is required!", 'Close', {
        duration: 2000,
      });
    } else {

      Swal.fire({
        title: "Confirmation",
        text: "You are responsible for updating bank details. Are you sure?",
        showCancelButton: true,
        confirmButtonText: "OK",
      }).then(async (result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
          const assignResponse: any = await this.updateBankBranchDetails().catch((error) => {
            console.log(error);
          });
          if (assignResponse.status == 200) {
            Swal.fire({
              title: "Success",
              text: "Claim details updated",
              confirmButtonText: "OK",
            }).then(async (result) => {
              if (result.isConfirmed) {
                window.location.reload();
              }
            });
          }


        }
      });

    }
  }

  get minDate(): Date {
    const today = new Date();
    return new Date(today.getFullYear(), today.getMonth(), today.getDate() - 14);
  }

  get maxDate(): Date {
    return new Date();
  }

  clearPolicyNumber() {
    this.claimRequestForm.get('policyNumber').setValue('');
  }

  async selectOtherFiles(event: any) {
    let pFileList = event.target.files;
    await this.selectFiles(pFileList, "other");
    this.otherDocumentEditable = false;
    if (this.otherFiles != null && !this.showFirstLevelReview) {
      this.loading = true;
      let dmsRequestmodel: DmsRequestDTO[] = [];
      await this.includeOtherFiles(dmsRequestmodel);

      let dmsPayloadModel: DmsPayload = { dmsRequestDTOList: dmsRequestmodel, status: "update" }
      const documentUploadResponse: any = await this.saveClaimDocuments(dmsPayloadModel).catch((error) => {
        console.log(error);
        this.loading = false;
      });
      if (documentUploadResponse.status == 200) {
        this.loading = false;
        let remark = "Other documents modified";
        const assignResponse: any = await this.addRemarkForClaimRequest(remark).catch((error) => {
          console.log(error);
        });
        if (assignResponse.status == 200) {
          Swal.fire({
            title: "Success",
            text: "Other documents changed succesfully",
            confirmButtonText: "OK",
          }).then(async (result) => {
            if (result.isConfirmed) {
              const claimReviewResponse: any = await this.getClaimReviewDetails().catch((error) => {
                console.log(error);
              });
              if (claimReviewResponse.status == 200) {
                if (this.showSecondLevelAction) {
                  this.actionClaimRequest.patchValue({
                    decisionSummary: [claimReviewResponse.payload.decisionSummary]
                  })
                  this.decisionSummary.nativeElement.style.height = 'auto';
                  this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;
                }
              }
            }
          });

        }

      }
    }
  }

  async selectSynopsisFiles(event: any) {
    let pFileList = event.target.files;
    await this.selectFiles(pFileList, "synopsis");
    this.synopsisDocumentEditable = false;
  }

  async selectCreditNoteFiles(event: any) {
    let pFileList = event.target.files;
    await this.selectFiles(pFileList, "creditNote");
    this.creditNoteEditable = false;
  }

  async selectPendingLetterFiles(event: any) {
    let pFileList = event.target.files;
    await this.selectFiles(pFileList, "pendingLetter");
    this.pendingLetterEditable = false;
  }

  async selectrejectionLetterFiles(event: any) {
    let pFileList = event.target.files;
    await this.selectFiles(pFileList, "rejectionLetter");
    this.rejectionLetterEditable = false;
  }

  async selectFiles(pFileList: File[], type: string) {
    this.documentList = Object.keys(pFileList).map(key => pFileList[key]);
    for (let i = 0; i < this.documentList.length; i++) {
      let file = this.documentList[i];
      if (file.size < this.validationFileSize) {
        if (file.type === "application/pdf" || file.type === "image/jpeg" || file.type === "image/png") {
          this.isFileValid = true;
        } else {
          this.isFileValid = false;
        }
      } else {
        this.isFileValid = false;
      }

    }


    if (this.isFileValid) {

      for (let i = 0; i < this.documentList.length; i++) {
        let file = this.documentList[i];
        if (file.type === "image/jpg" || file.type === "image/jpeg" || file.type === "image/png") {
          file = await this.compressImage(file);
        }
        this.selectedFiles.push(file);
      }
      this.files = [];
      for (let i = 0; i < this.selectedFiles.length; i++) {
        this.files.push(this.selectedFiles[i].name);
      }
      if (type == "other") {
        this.otherFiles = { fileNameArray: this.files, files: this.selectedFiles }
        this.fileInputVariable.nativeElement.value = null;
      } else if (type == "synopsis") {
        this.synopsisFiles = { fileNameArray: this.files, files: this.selectedFiles }
        this.synopsisInputVariable.nativeElement.value = null;
      } else if (type == "creditNote") {
        this.creditNoteFiles = { fileNameArray: this.files, files: this.selectedFiles }
        this.creditNoteInputElement.nativeElement.value = null;
      } else if (type == "pendingLetter") {
        this.pendingLetterFiles = { fileNameArray: this.files, files: this.selectedFiles }
        this.pendingLetterInputElement.nativeElement.value = null;
      } else if (type == "rejectionLetter") {
        this.rejectionLetterFiles = { fileNameArray: this.files, files: this.selectedFiles }
        this.rejectionLetterInputElement.nativeElement.value = null;
      }

      this.selectedFiles = [];
      this._snackBar.open("File ready to upload!", 'Close', {
        duration: 2000,
      });

    } else if (!this.isFileValid) {
      this.resetDocuments();
      this._snackBar.open(this.validationMessage, 'Close', {
        duration: 2000,
      });
    }
  }
  compressImage(image) {
    return new Promise((resolve, reject) => {
      this.imageCompressor.compress(image)
        .pipe(take(1))
        .subscribe(compressedImage => {
          resolve(compressedImage);
        }, error => {
          reject(error);
        });
    });
  }

  resetDocuments() {
    this.documentList = [];
    this.fileInputVariable.nativeElement.value = "";
  }

  viewSynopsisDocuments() {
    let documentEditable = true;
    if (this.showCallCenterReview || this.showFinanceReview) {
      documentEditable = false;
    }
    const dialogRef = this.dialog.open(DocumentViewerDialogComponent, {
      width: '95%',
      data: {
        docs: this.synopsisFiles,
        isdocumentUploadable: documentEditable,
        documentType: 'Synopsis Documents'
      },
      disableClose: true,

    });

    dialogRef.afterClosed().subscribe(async result => {
      this.synopsisFiles.fileNameArray = result.responseFileNames;
      this.synopsisFiles.files = result.responseFiles;
      if (this.synopsisFiles.files.length === 0) {
        this.synopsisDocumentEditable = true;
      } else if (!this.showFirstLevelReview && result.isFileChanged) {
        this.loading = true;
        let dmsRequestmodel: DmsRequestDTO[] = [];
        await this.includeSynopsisFiles(dmsRequestmodel);

        let dmsPayloadModel: DmsPayload = { dmsRequestDTOList: dmsRequestmodel, status: "update" }
        const documentUploadResponse: any = await this.saveClaimDocuments(dmsPayloadModel).catch((error) => {
          console.log(error);
          this.loading = false;
        });
        if (documentUploadResponse.status == 200) {
          this.loading = false;
          let remark = "Synopsis documents modified";
          const assignResponse: any = await this.addRemarkForClaimRequest(remark).catch((error) => {
            console.log(error);
          });
          if (assignResponse.status == 200) {
            Swal.fire({
              title: "Success",
              text: "Synopsis documents changed succesfully",
              confirmButtonText: "OK",
            }).then(async (result) => {
              if (result.isConfirmed) {
                const claimReviewResponse: any = await this.getClaimReviewDetails().catch((error) => {
                  console.log(error);
                });
                if (claimReviewResponse.status == 200) {
                  if (this.showSecondLevelAction) {
                    this.actionClaimRequest.patchValue({
                      decisionSummary: [claimReviewResponse.payload.decisionSummary]
                    })
                    this.decisionSummary.nativeElement.style.height = 'auto';
                    this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;
                  } else if (this.showSecondLevelDecisionReceived) {
                    this.decisionReceivedClaimRequest.patchValue({
                      decisionSummary: [claimReviewResponse.payload.decisionSummary]
                    })
                    this.decisionSummary.nativeElement.style.height = 'auto';
                    this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;
                  }
                }
              }
            });

          }

        }
      }
    });
  }

  viewCreditNoteDocuments() {
    let documentEditable = true;
    if (this.showCallCenterReview || this.showFinanceReview) {
      documentEditable = false;
    }
    const dialogRef = this.dialog.open(DocumentViewerDialogComponent, {
      width: '95%',
      data: {
        docs: this.creditNoteFiles,
        isdocumentUploadable: documentEditable,
        documentType: 'Credit Note'
      },
      disableClose: true,

    });

    dialogRef.afterClosed().subscribe(async result => {
      this.creditNoteFiles.fileNameArray = result.responseFileNames;
      this.creditNoteFiles.files = result.responseFiles;
      if (this.creditNoteFiles.files.length === 0) {
        this.creditNoteEditable = true;
      } else if (!this.showFirstLevelReview && result.isFileChanged) {
        this.loading = true;
        let dmsRequestmodel: DmsRequestDTO[] = [];
        await this.includeCreditNoteFiles(dmsRequestmodel);

        let dmsPayloadModel: DmsPayload = { dmsRequestDTOList: dmsRequestmodel, status: "update" }
        const documentUploadResponse: any = await this.saveClaimDocuments(dmsPayloadModel).catch((error) => {
          console.log(error);
          this.loading = false;
        });
        if (documentUploadResponse.status == 200) {
          this.loading = false;
          let remark = "Credit note documents modified";
          const assignResponse: any = await this.addRemarkForClaimRequest(remark).catch((error) => {
            console.log(error);
          });
          if (assignResponse.status == 200) {
            Swal.fire({
              title: "Success",
              text: "Credit note documents changed succesfully",
              confirmButtonText: "OK",
            }).then(async (result) => {
              if (result.isConfirmed) {
                const claimReviewResponse: any = await this.getClaimReviewDetails().catch((error) => {
                  console.log(error);
                });
                if (claimReviewResponse.status == 200) {
                  if (this.showSecondLevelAction) {
                    this.actionClaimRequest.patchValue({
                      decisionSummary: [claimReviewResponse.payload.decisionSummary]
                    })
                    this.decisionSummary.nativeElement.style.height = 'auto';
                    this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;
                  } else if (this.showSecondLevelDecisionReceived) {
                    this.decisionReceivedClaimRequest.patchValue({
                      decisionSummary: [claimReviewResponse.payload.decisionSummary]
                    })
                    this.decisionSummary.nativeElement.style.height = 'auto';
                    this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;
                  }
                }
              }
            });

          }

        }
      }
    });
  }

  viewPendingLetterDocuments() {
    let documentEditable = true;
    if (this.showCallCenterReview || this.showFinanceReview) {
      documentEditable = false;
    }
    const dialogRef = this.dialog.open(DocumentViewerDialogComponent, {
      width: '95%',
      data: {
        docs: this.pendingLetterFiles,
        isdocumentUploadable: documentEditable,
        documentType: 'Letter Of Pending'
      },
      disableClose: true,

    });

    dialogRef.afterClosed().subscribe(async result => {
      this.pendingLetterFiles.fileNameArray = result.responseFileNames;
      this.pendingLetterFiles.files = result.responseFiles;
      if (this.pendingLetterFiles.files.length === 0) {
        this.pendingLetterEditable = true;
      } else if (result.isFileChanged && !this.showFirstLevelReview) {
        this.loading = true;
        let dmsRequestmodel: DmsRequestDTO[] = [];
        await this.includependingLetterFiles(dmsRequestmodel);

        let dmsPayloadModel: DmsPayload = { dmsRequestDTOList: dmsRequestmodel, status: "update" }
        const documentUploadResponse: any = await this.saveClaimDocuments(dmsPayloadModel).catch((error) => {
          console.log(error);
          this.loading = false;
        });
        if (documentUploadResponse.status == 200) {
          this.loading = false;
          let remark = "Pending letter documents modified";
          const assignResponse: any = await this.addRemarkForClaimRequest(remark).catch((error) => {
            console.log(error);
          });
          if (assignResponse.status == 200) {
            Swal.fire({
              title: "Success",
              text: "Pending letter documents changed succesfully",
              confirmButtonText: "OK",
            }).then(async (result) => {
              if (result.isConfirmed) {
                const claimReviewResponse: any = await this.getClaimReviewDetails().catch((error) => {
                  console.log(error);
                });
                if (claimReviewResponse.status == 200) {
                  if (this.showSecondLevelAction) {
                    this.actionClaimRequest.patchValue({
                      decisionSummary: [claimReviewResponse.payload.decisionSummary]
                    })
                    this.decisionSummary.nativeElement.style.height = 'auto';
                    this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;
                  } else if (this.showSecondLevelDecisionReceived) {
                    this.decisionReceivedClaimRequest.patchValue({
                      decisionSummary: [claimReviewResponse.payload.decisionSummary]
                    })
                    this.decisionSummary.nativeElement.style.height = 'auto';
                    this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;
                  }
                }
              }
            });

          }

        }
      }
    });
  }

  viewrejectionLetterDocuments() {
    let documentEditable = true;
    if (this.showCallCenterReview || this.showFinanceReview) {
      documentEditable = false;
    }
    const dialogRef = this.dialog.open(DocumentViewerDialogComponent, {
      width: '95%',
      data: {
        docs: this.rejectionLetterFiles,
        isdocumentUploadable: documentEditable,
        documentType: 'Rejection Letter'
      },
      disableClose: true,

    });

    dialogRef.afterClosed().subscribe(async result => {
      this.rejectionLetterFiles.fileNameArray = result.responseFileNames;
      this.rejectionLetterFiles.files = result.responseFiles;

      if (this.rejectionLetterFiles.files.length === 0) {
        this.rejectionLetterEditable = true;
      } else if (result.isFileChanged && !this.showFirstLevelReview) {
        this.loading = true;
        let dmsRequestmodel: DmsRequestDTO[] = [];
        await this.includeRejectionLetterFiles(dmsRequestmodel);

        let dmsPayloadModel: DmsPayload = { dmsRequestDTOList: dmsRequestmodel, status: "update" }
        const documentUploadResponse: any = await this.saveClaimDocuments(dmsPayloadModel).catch((error) => {
          console.log(error);
          this.loading = false;
        });
        if (documentUploadResponse.status == 200) {
          this.loading = false;
          let remark = "Rejection letter documents modified";
          const assignResponse: any = await this.addRemarkForClaimRequest(remark).catch((error) => {
            console.log(error);
          });
          if (assignResponse.status == 200) {
            Swal.fire({
              title: "Success",
              text: "Rejection letter documents changed succesfully",
              confirmButtonText: "OK",
            }).then(async (result) => {
              if (result.isConfirmed) {
                const claimReviewResponse: any = await this.getClaimReviewDetails().catch((error) => {
                  console.log(error);
                });
                if (claimReviewResponse.status == 200) {
                  if (this.showSecondLevelAction) {
                    this.actionClaimRequest.patchValue({
                      decisionSummary: [claimReviewResponse.payload.decisionSummary]
                    })
                    this.decisionSummary.nativeElement.style.height = 'auto';
                    this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;
                  } else if (this.showSecondLevelDecisionReceived) {
                    this.decisionReceivedClaimRequest.patchValue({
                      decisionSummary: [claimReviewResponse.payload.decisionSummary]
                    })
                    this.decisionSummary.nativeElement.style.height = 'auto';
                    this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;
                  }
                }
              }
            });

          }

        }
      }
    });
  }

  viewOtherDocuments() {
    let documentEditable = true;
    if (this.showCallCenterReview || this.showFinanceReview) {
      documentEditable = false;
    }
    const dialogRef = this.dialog.open(DocumentViewerDialogComponent, {
      width: '95%',
      data: {
        docs: this.otherFiles,
        isdocumentUploadable: documentEditable,
        documentType: 'Other Documents'
      },
      disableClose: true,

    });

    dialogRef.afterClosed().subscribe(async result => {
      this.otherFiles.fileNameArray = result.responseFileNames;
      this.otherFiles.files = result.responseFiles;

      if (this.otherFiles.files.length === 0) {
        this.otherDocumentEditable = true;
      } else if (result.isFileChanged && !this.showFirstLevelReview) {
        this.loading = true;
        let dmsRequestmodel: DmsRequestDTO[] = [];
        await this.includeOtherFiles(dmsRequestmodel);

        let dmsPayloadModel: DmsPayload = { dmsRequestDTOList: dmsRequestmodel, status: "update" }
        const documentUploadResponse: any = await this.saveClaimDocuments(dmsPayloadModel).catch((error) => {
          console.log(error);
          this.loading = false;
        });
        if (documentUploadResponse.status == 200) {
          this.loading = false;
          let remark = "Other documents modified";
          const assignResponse: any = await this.addRemarkForClaimRequest(remark).catch((error) => {
            console.log(error);
          });
          if (assignResponse.status == 200) {
            Swal.fire({
              title: "Success",
              text: "Other documents changed succesfully",
              confirmButtonText: "OK",
            }).then(async (result) => {
              if (result.isConfirmed) {
                const claimReviewResponse: any = await this.getClaimReviewDetails().catch((error) => {
                  console.log(error);
                });
                if (claimReviewResponse.status == 200) {
                  if (this.showSecondLevelAction) {
                    this.actionClaimRequest.patchValue({
                      decisionSummary: [claimReviewResponse.payload.decisionSummary]
                    })
                    this.decisionSummary.nativeElement.style.height = 'auto';
                    this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;
                  } else if (this.showSecondLevelDecisionReceived) {
                    this.decisionReceivedClaimRequest.patchValue({
                      decisionSummary: [claimReviewResponse.payload.decisionSummary]
                    })
                    this.decisionSummary.nativeElement.style.height = 'auto';
                    this.decisionSummary.nativeElement.style.height = `${this.decisionSummary.nativeElement.scrollHeight}px`;
                  }
                }
              }
            });

          }

        }
      }
    });
  }


  changeDigitalFormSelection() {
    const selection = this.secondFormGroup.get('digitalFormSelection').value;
    const formType = this.secondFormGroup.get('formType').value;
    console.log(selection);
    console.log(formType);
    if (selection == "yes") {
      let authToken = this.token;
      Survey.ChoicesRestfull.onBeforeSendRequest = function (sender, options) {
        options.request.setRequestHeader("Authorization", "Bearer " + authToken);
        options.request.setRequestHeader("Access-Control-Allow-Origin", "*");
        options.request.setRequestHeader("Access-Control-Allow-Methods", "GET, POST, PATCH, PUT, DELETE, OPTIONS");
        // options.request.setRequestHeader("Access-Control-Allow-Headers", "Origin, Content-Type, X-Auth-Token");
      };
      let survey: Model;
      if (formType == 1) {
        // survey = new Model(hbJson);
        survey.locale = "en";
      } else if (formType == 2) {
        // survey = new Model(tpdjson);
        survey.locale = "en";
      } else if (formType == 3) {
        // survey = new Model(cibJson);
        survey.locale = "en";
      } else if (formType == 4) {
        // survey = new Model(hbJson);
        survey.locale = "si";
      }

      survey.onUpdateQuestionCssClasses.add(function (_: any, options: { cssClasses: any; question: { getType: () => string; }; }) {
        const classes = options.cssClasses;
        if (options.question.getType() === "text") {
          classes.root += " input-height";
        }
        if (options.question.getType() === 'comment') {
          classes.root += ' textarea-height';
        }

      });

      survey.addNavigationItem({
        id: 'sv-nav-clear-page',
        title: 'Clear Form',
        action: () => {
          survey.currentPage.questions.forEach((question: { value: any; }) => {
            question.value = undefined;
          });
        },
        css: 'nav-button ',
        innerCss: 'sd-btn nav-input'
      });


      SurveyNG.render("surveyElement", {
        model: survey
      })
      // survey.onComplete.add(this.surveyComplete);
    } else {
      document.querySelector('div#surveyElement').innerHTML = "";
    }
  }
  get f() {
    return this.secondFormGroup.controls;
  }


  clearSelectedPolicyNu() {
    this.claimRequestForm.get('policyNumber').setValue('');
  }

  async changeDigitalFormSelection1(type: string, language: string) {
    let authToken = this.token;
    Survey.ChoicesRestfull.onBeforeSendRequest = function (sender, options) {
      options.request.setRequestHeader("Authorization", "Bearer " + authToken);
    };
    let survey: Model;
    let surveyJson: any = "";
    switch (type) {
      case 'hb':
        surveyJson = await this.getViewHBForm().catch((error) => {
          console.log(error);
        });
        survey = new Model(surveyJson);
        if (language == 'SI') {
          survey.locale = "si";
        }
        break;

      case 'tpd/ppd':
        surveyJson = await this.getViewTPDPPDForm().catch((error) => {
          console.log(error);
        });
        survey = new Model(surveyJson);
        break;

      case 'cib':
        surveyJson = await this.getViewCIBForm().catch((error) => {
          console.log(error);
        });
        survey = new Model(surveyJson);
        break;
      default:
        break;
    }

    survey.onUpdateQuestionCssClasses.add(function (_: any, options: { cssClasses: any; question: { getType: () => string; }; }) {
      const classes = options.cssClasses;
      if (options.question.getType() === "text") {
        classes.root += " input-height";
      }
      if (options.question.getType() === 'comment') {
        classes.root += ' textarea-height';
      }

    });

    survey.showNavigationButtons = false;


    SurveyNG.render("surveyElement", {
      model: survey
    })

  }




  async claimRequestNext() {

    let claimId = this.claimRequestForm.value.claim
    this.loading = true;
    this.isEnableDocumentUploadFormSection = false;
    this.claimRequestForm.markAllAsTouched();


    if (this.claimRequestForm.value.fillOption == 2) {
      this.isEnableDocumentUploadFormSection = false;
      console.log(this.claimRequestForm.value.claim)
      switch (this.claimRequestForm.value.claim) {
        case 3:
        case 4:
          this.changeDigitalFormSelection1('hb', 'EN');
          break;
        case 12:
        case 13:
          this.changeDigitalFormSelection1('hb', 'SI');
          break;
        case 6:
        case 7:
          this.changeDigitalFormSelection1('tpd/ppd', 'EN');
          break;
        case 8:
          this.changeDigitalFormSelection1('cib', 'EN');
          break;

        default:

          break;
      }
    } else if (this.claimRequestForm.value.fillOption == 1) {

      setTimeout(() => {
        this.isEnableDocumentUploadFormSection = true;
      }, 500);

      let originalPolicyNumber = this.claimRequestForm.value.policyNumber;
      let policySplit = originalPolicyNumber.split("/");
      const moreClaimData = {
        claimRequestId: this.claimRequestId,
        policyNumber: policySplit[0] + policySplit[1],
        claimGeneratedCode: this.generatedClaimRequestNumber + "-form"

      }
      this.documentFormData = {
        title: this.claims.find(value => value.id == claimId).name,
        data: moreClaimData,
        isEnableDocView: true
      };


      this.isEnableDocumentUploadFormSection = true;
    } else {
      this.isEnableDocumentUploadFormSection = false;
    }

    // stepper.next();
    this.loading = false;



  }


  insertSignature() {
    this.route.navigateByUrl('/base/service-portal/signature');
  }



  async secondFormGroupNext() {
    this.isEnableDocumentUploadSection = false;
    let claimId = this.claimRequestForm.value.claim;
    const documentListResponse: any = await this.getRequiredDocumentList(claimId).catch((error) => {
      console.log(error);
    });
    if (documentListResponse.status == 200) {

      const claimRequestDataResponse: any = await this.getClaimRequestById(this.claimRequestId).catch((error) => {
        console.log(error);
      });
      if (claimRequestDataResponse.status == 200) {
        this.generatedClaimRequestNumber = claimRequestDataResponse.payload.claimRequestNumber;


      }
      let originalPolicyNumber = this.claimRequestForm.value.policyNumber;
      let policySplit = originalPolicyNumber.split("/");
      this.documentData = {
        title: this.claims.find(value => value.id == this.claimRequestForm.value.claimType).name,
        claimId: claimId,
        isdocumentUploadable: true,
        state: "view",
        policyNumber: policySplit[0] + policySplit[1],
        claimNumber: this.generatedClaimRequestNumber
      };
      this.isEnableDocumentUploadSection = true;
      // stepper.next();
    }
  }



  async backFromClaimAction(stepper: MatStepper) {
    this.isEnableDocumentUploadSection = false;
    let claimId = this.claimRequestForm.value.claim;
    const documentListResponse: any = await this.getRequiredDocumentList(claimId).catch((error) => {
      console.log(error);
    });
    if (documentListResponse.status == 200) {

      const claimRequestDataResponse: any = await this.getClaimRequestById(this.claimRequestId).catch((error) => {
        console.log(error);
      });
      if (claimRequestDataResponse.status == 200) {
        this.generatedClaimRequestNumber = claimRequestDataResponse.payload.claimRequestNumber;


      }
      let originalPolicyNumber = this.claimRequestForm.value.policyNumber;
      let policySplit = originalPolicyNumber.split("/");
      this.documentData = {
        title: this.claims.find(value => value.id == this.claimRequestForm.value.claimType).name,
        claimId: claimId,
        isdocumentUploadable: true,
        state: "view",
        policyNumber: policySplit[0] + policySplit[1],
        claimNumber: this.generatedClaimRequestNumber
      };
      this.isEnableDocumentUploadSection = true;
      stepper.previous();
    }
  }


  async documentFormGroupNext() {
    const featuresResponse: any = await this.getJobAssignFeatures().catch((error) => {
      console.log(error);
    });
    if (featuresResponse.status == 200) {

      this.claimActionFeatures = featuresResponse.payload;
      this.showReject = this.claimActionFeatures.find(item => item.name === "Reject") !== undefined;
      this.showPending = this.claimActionFeatures.find(item => item.name === "Pending") !== undefined;
      this.showApprove = this.claimActionFeatures.find(item => item.name === "Approve") !== undefined;
      this.showAssign = this.claimActionFeatures.find(item => item.name === "Higher Management Assign") !== undefined;
    }




  }



  onClaimTypeChange() {
    this.claimRequestForm.get('claim').reset();
  }


  backFromDocumentUpload(stepper: MatStepper) {
    if (this.claimRequestForm.get('fillOption').value == 2) {
      this.isEnableDocumentUploadSection = false;
    } else {
      this.isEnableDocumentUploadSection = true;
      this.isEnableDocumentUploadFormSection = true;
    }

    this.claimRequestNext();
    stepper.previous();

  }



  onSelectClaimType($event) {
    switch ($event.value) {
      case 10:
      case 9:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 11:
      case 12:
      case 13:
        this.claimRequestForm.get('claimType').setValue(2);
        break;
      case 1:
      case 2:
        this.claimRequestForm.get('claimType').setValue(1);
        break;
      default:
        this.claimRequestForm.get('claimType').reset();
        break;
    }

    this.setFillOptionOnClaim($event.value);
  }

  setFillOptionOnClaim(claimId: number) {
    this.claimRequestForm.get('fillOption').reset();
    switch (claimId) {
      case 10:
      case 9:
      case 11:
      case 1:
      case 2:
      case 5:
        this.claimRequestForm.get('fillOption').setValue(1);
        break;
      default:
        break;
    }
  }

  // request/response - api call
  async getRequiredDocumentList(claimId: number) {
    const paylaod = {
      token: this.token,
      claimId: claimId
    }
    return new Promise((resolve, reject) => {
      this.digitalFormSubscription = this.aspServiceService.getRequiredDocumentList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async onSelectActiveBankBranch($event) {
    this.claimRequestForm.get('branchName').enable();
    this.claimRequestForm.get('branchName').setValue('');
    this.isVisibleBankBranchNoAvilable = false;
    const onBranchListResponse: any = await this.getBranchListByBankId($event.value).catch((error) => {
      console.log(error);
    });
    if (onBranchListResponse.status == 200) {
      if (onBranchListResponse.payload.length > 0) {
        this.branchList = onBranchListResponse.payload;
      } else {
        console.log("no bank avilable");

        this.claimRequestForm.get('branchName').disable();
        this.isVisibleBankBranchNoAvilable = true;
      }
    }

  }
  async onSelectActiveBankBranchSet(data: any) {
    const onBranchListResponse: any = await this.getBranchListByBankId(data.bankCode).catch((error) => {
      console.log(error);
    });
    if (onBranchListResponse.status == 200) {
      this.branchList = onBranchListResponse.payload;
      this.claimRequestForm.patchValue({
        branchName: data.bankBranchCode,
      });

    }
  }
  async onSelectHospitalSet(data: any) {
    const HospitalListResponse: any = await this.getHospitalList().catch((error) => {
      console.log(error);
    });
    if (HospitalListResponse.status == 200) {
      this.hospitalList = HospitalListResponse.payload;

      console.log(this.hospitalList, 'hospitalList Response');
      console.log(data.hospitalId, 'hospital id');


      this.claimRequestForm.patchValue({
        hospitalName: data.hospitalId,
      });
    }
  }
  async getClaimList() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getRejectReasons() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getRejectReasons(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getJobAssignFeatures() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getJobAssignFeatures(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getPendingReasons() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getPendingReasons(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getClaimReviewDetails() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimReviewDetails(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getClaimDecisionUserDetails(userId: number) {
    const paylaod = {
      token: this.token,
      userId: userId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimDecisionUserDetails(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getClaimRequestById(claimRequestId: number) {
    const paylaod = {
      token: this.token,
      claimRequestId: claimRequestId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimRequestByClaimId(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getHospitalList() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getHospitalList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getClaimType() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimTypes(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getActiveBankList() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getActiveBankList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getBranchListByBankId(bankId: number) {
    const paylaod = {
      token: this.token,
      bankCode: bankId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getActiveBankBranchList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getClaimTypes() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.digitalFormSubscription = this.aspServiceService.getClaimTypes(paylaod).subscribe(response => {
        console.log(response);

      }, error => {
        reject(false);
      });
    });
  }
  async getViewHBForm() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService.getViewHBForm(paylaod).subscribe(response => {
        resolve(response.payload);
      }, error => {
        reject(error);
      });
    });
  }
  async getViewTPDPPDForm() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService.getViewTPDPPDForm(paylaod).subscribe(response => {
        resolve(response.payload);
      }, error => {
        reject(error);
      });
    });
  }
  async getViewCIBForm() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService.getViewCIBForm(paylaod).subscribe(response => {
        resolve(response.payload);
      }, error => {
        reject(error);
      });
    });
  }



  validateAllFormFields(formGroup: FormGroup) {
    //{1}
    Object.keys(formGroup.controls).forEach((field) => {
      //{2}
      const control = formGroup.get(field); //{3}
      if (control instanceof FormGroup || control instanceof FormGroup) {
        //{4}
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        //{5}
        control.markAsTouched({ onlySelf: true });
        this.validateAllFormFields(control); //{6}
      }
    });
  }
  ApproveClaimRequestGroup(): UntypedFormGroup {
    return this.formBuilder.group({
      action: ['approve', Validators.required],
      actionRemark: [''],
      secondApproval: ['', Validators.required],
    });
  }
  AssignClaimRequestGroup(): UntypedFormGroup {
    return this.formBuilder.group({
      action: ['assign', Validators.required],
      actionRemark: [''],
      secondApproval: ['', Validators.required],
    });
  }
  SecondLevelApproveClaimRequestGroup(): UntypedFormGroup {
    return this.formBuilder.group({
      action: ['approve', Validators.required],
      actionRemark: ['']
    });
  }
  HigherAssignClaimRequestGroup(): UntypedFormGroup {
    return this.formBuilder.group({
      action: ['higherManagement', Validators.required],
      actionRemark: [''],
      higherManagement: ['', Validators.required],
    });
  }
  RejectClaimRequestGroup(): UntypedFormGroup {
    return this.formBuilder.group({
      action: ['reject', Validators.required],
      actionRemark: ['', Validators.required],
    });
  }
  RejectClaimRequestGroupWithOther(reason): UntypedFormGroup {
    return this.formBuilder.group({
      action: ['reject', Validators.required],
      actionRemark: [''],
      rejectReason: [reason, Validators.required],
      otherReason: ['', Validators.required]
    });
  }
  pendingClaimRequestGroup(): UntypedFormGroup {
    return this.formBuilder.group({
      action: ['pending', Validators.required],
      actionRemark: ['', Validators.required]
    });
  }
  pendingClaimRequestGroupWithOther(reason): UntypedFormGroup {
    return this.formBuilder.group({
      claimNumber: [this.decisionReceivedClaimRequest.value.claimNumber],
      sumAssured: [this.decisionReceivedClaimRequest.value.sumAssured],
      paymentMode: [this.decisionReceivedClaimRequest.value.paymentMode],
      decisionSummary: [this.decisionReceivedClaimRequest.value.decisionSummary],
      secondApproval: [this.decisionReceivedClaimRequest.value.secondApproval],
      decisionRemark: [this.decisionReceivedClaimRequest.value.decisionRemark],
      action: [''],
      pendingReason: [reason, Validators.required],
      otherReason: ['', Validators.required]
    });
  }

  fileUploadCreditNote() {
    this.creditNoteInputElement.nativeElement.click();
  }

  fileUploadOpsis() {
    this.synopsisInputVariable.nativeElement.click();
  }

  fileUploadPendingLetterDocument() {
    this.pendingLetterInputElement.nativeElement.click();
  }

  fileUploadLetterOfRejectionDocument() {
    this.rejectionLetterInputElement.nativeElement.click();
  }

  fileUploadOtherDocument() {
    this.fileInputVariable.nativeElement.click();
  }

  async onChangeAction(event: any) {
    let action = this.actionClaimRequest.value.action;
    if (action == "approve") {
      this.hasOtherComments = false;
      this.claimRequestUserAction = 1;
      this.isFirstLevelApproval = false;
      this.actionClaimRequest = this.SecondLevelApproveClaimRequestGroup();
    } else if (action == "pending") {
      this.hasOtherComments = false;
      this.claimRequestUserAction = 2;
      this.actionClaimRequest = this.pendingClaimRequestGroup();
    } else if (action == "reject") {
      this.hasOtherComments = false;
      this.claimRequestUserAction = 3;
      this.actionClaimRequest = this.RejectClaimRequestGroup();
    } else if (action == "assign") {
      this.hasOtherComments = false;
      this.claimRequestUserAction = 4;
      this.isFirstLevelApproval = true;
      this.actionClaimRequest = this.AssignClaimRequestGroup();
      const assignedusersResponse: any = await this.getAssigneeUserListHO().catch((error) => {
        console.log(error);
      });
      if (assignedusersResponse.status == 200) {
        this.assignableUsers = assignedusersResponse.payload;
      }
    }
  }

  async onChangeAssigngningLevel(event: any) {
    this.decisionReceivedClaimRequest.patchValue({ 'secondApproval': '' });
    this.actionFirstLevelReview.patchValue({ 'secondApproval': '' });
    let action = event.value;
    if (action == "secondlevel") {
      const assignedusersResponse: any = await this.getAssigneeUserListHO().catch((error) => {
        console.log(error);
      });
      if (assignedusersResponse.status == 200) {
        this.assignableUsers = assignedusersResponse.payload;
      }
      this.isSecondLevelAssign = true;
      this.isCallCenterAssign = false;
      this.isAdvisorAssign = false;
      this.isFinanceAssign = false;
    } else if (action == "callcenter") {
      const assignedusersResponse: any = await this.getAssigneeUserListCallCenter().catch((error) => {
        console.log(error);
      });
      if (assignedusersResponse.status == 200) {
        this.assignableUsers = assignedusersResponse.payload;
      }
      this.isSecondLevelAssign = false;
      this.isCallCenterAssign = true;
      this.isAdvisorAssign = false;
      this.isFinanceAssign = false;
    } else if (action == "advisor") {
      this.isSecondLevelAssign = false;
      this.isCallCenterAssign = false;
      this.isAdvisorAssign = true;
      this.isFinanceAssign = false;
    } else if (action == "finance") {
      this.isSecondLevelAssign = false;
      this.isCallCenterAssign = false;
      this.isAdvisorAssign = false;
      this.isFinanceAssign = true;
    }
  }

  onChangeRejectReason(event: any) {
    if (this.decisionReceivedClaimRequest.value.rejectReason.toLowerCase().includes("other")) {
      this.hasOtherComments = true;
      this.decisionReceivedClaimRequest = this.RejectClaimRequestGroupWithOther(this.decisionReceivedClaimRequest.value.rejectReason);
    } else {
      this.hasOtherComments = false;
    }
  }

  onChangePendingReason(event: any) {
    if (this.decisionReceivedClaimRequest.value.pendingReason.toLowerCase().includes("other")) {
      console.log("hasOtherComments")
      this.hasOtherComments = true;
      this.decisionReceivedClaimRequest = this.pendingClaimRequestGroupWithOther(this.decisionReceivedClaimRequest.value.pendingReason);
    } else {
      this.hasOtherComments = false;
    }
  }

  async claimRequestActionSubmit() {
    this.actionClaimRequest.markAllAsTouched();
    this.validateAllFormFields(this.actionClaimRequest);
    if (this.actionClaimRequest.valid) {
      const assignResponse: any = await this.assignClaimRequest().catch((error) => {
        console.log(error);
      });
      if (assignResponse.status == 200) {
        Swal.fire({
          title: "Success",
          text: "Your review is submitted",
          confirmButtonText: "OK",
        }).then(async (result) => {
          if (result.isConfirmed) {
            this.router.navigate([
              '/dashboard/asp-management']);
          }
        });
      }

    }
  }

  async assignToSecondLevel() {
    const assignResponse: any = await this.assignClaimRequestToSecondLevelAfterFirstLevel().catch((error) => {
      console.log(error);
    });
    if (assignResponse.status == 200) {
      Swal.fire({
        title: "Success",
        text: "Claim is now assigned to second level user",
        confirmButtonText: "OK",
      }).then(async (result) => {
        if (result.isConfirmed) {
          this.router.navigate([
            '/dashboard/asp-management']);
        }
      });

    }
  }

  async initialLevelSubmit() {
    if (this.isSecondLevelAssign && this.initialCallcenterRemarkReceived) {
      await this.firstLevelReviewAfterCallcenter();
    } else if (this.isSecondLevelAssign) {
      await this.firstLevelReview();
    } else if (this.isCallCenterAssign && this.initialCallcenterRemarkReceived) {
      await this.InitialToCallCenterAfterCallCenterDecision();
    }else if (this.isCallCenterAssign) {
      await this.InitialToCallCenter();
    } else {
      this._snackBar.open("Select assigning person!", 'Close', {
        duration: 2000,
      });
    }
  }

  async afterApprovalSubmit() {
    if (this.isSecondLevelAssign) {
      await this.reEvaluate("approved");
    } else if (this.isCallCenterAssign) {
      await this.ApproveToCallCenter();
    } else if (this.isFinanceAssign) {
      await this.submitToFinance();
    } else {
      this._snackBar.open("Select assigning person!", 'Close', {
        duration: 2000,
      });
    }
  }

  async afterPendingSubmit() {
    if (this.isSecondLevelAssign) {
      await this.reEvaluate("pending");
    } else if (this.isCallCenterAssign) {
      await this.PendingToCallCenter();
    } else if (this.isAdvisorAssign) {
      await this.PendingToAdvisor();
    } else {
      this._snackBar.open("Select assigning person!", 'Close', {
        duration: 2000,
      });
    }
  }

  async afterRejectSubmit() {
    if (this.isSecondLevelAssign) {
      await this.reEvaluate("reject");
    } else if (this.isCallCenterAssign) {
      await this.rejectToCallCenter();
    } else if (this.isAdvisorAssign) {
      await this.rejectToAdvisor();
    } else {
      this._snackBar.open("Select assigning person!", 'Close', {
        duration: 2000,
      });
    }
  }

  async firstLevelReview() {
    this.actionFirstLevelReview.markAllAsTouched();
    this.validateAllFormFields(this.actionFirstLevelReview);
    console.log(this.actionFirstLevelReview)
    if (this.actionFirstLevelReview.valid) {
      let dmsRequestmodel: DmsRequestDTO[] = [];
      await this.includeSynopsisFiles(dmsRequestmodel);

      if (dmsRequestmodel.length != 0) {
        await this.includeOtherFiles(dmsRequestmodel);
        this.loading = true;
        const updateDetailsResponse: any = await this.updateClaimReviewDetails().catch((error) => {
          console.log(error);
          this.loading = false;
        });
        if (updateDetailsResponse.status == 200) {
          let dmsPayloadModel: DmsPayload = { dmsRequestDTOList: dmsRequestmodel, status: "update" }
          const documentUploadResponse: any = await this.saveClaimDocuments(dmsPayloadModel).catch((error) => {
            console.log(error);
            this.loading = false;
          });
          if (documentUploadResponse.status == 200) {
            this.loading = false;
            console.log("successfully uploaded");
            this._snackBar.open("Document upload completed!", 'Close', {
              duration: 2000,
            });

          }

          const assignResponse: any = await this.assignClaimRequestToSecondLevel().catch((error) => {
            console.log(error);
          });
          if (assignResponse.status == 200) {
            Swal.fire({
              title: "Success",
              text: "Claim is now assigned to second level user",
              confirmButtonText: "OK",
            }).then(async (result) => {
              if (result.isConfirmed) {
                this.router.navigate([
                  '/dashboard/asp-management']);
              }
            });

          }
        } else if (updateDetailsResponse.status == 400) {
          this._snackBar.open(updateDetailsResponse.message, 'Close', {
            duration: 2000,
          });
        } else {
          this._snackBar.open("Failed to update review data!", 'Close', {
            duration: 2000,
          });
        }
      } else {
        this._snackBar.open("Synopsis document is required!", 'Close', {
          duration: 2000,
        });
      }
    }
  }

  async firstLevelReviewAfterCallcenter() {
    this.decisionReceivedClaimRequest.controls['secondApproval'].addValidators([Validators.required])
    this.decisionReceivedClaimRequest.controls['secondApproval'].updateValueAndValidity()
    this.decisionReceivedClaimRequest.markAllAsTouched();
    this.validateAllFormFields(this.actionFirstLevelReview);
    console.log(this.decisionReceivedClaimRequest)
    if (this.decisionReceivedClaimRequest.valid) {
      const assignResponse: any = await this.assignClaimRequestToSecondLevelAfterCallcenter().catch((error) => {
        console.log(error);
      });
      if (assignResponse.status == 200) {
        Swal.fire({
          title: "Success",
          text: "Claim is now assigned to second level user",
          confirmButtonText: "OK",
        }).then(async (result) => {
          if (result.isConfirmed) {
            this.router.navigate([
              '/dashboard/asp-management']);
          }
        });

      }
    }
  }

  async returnClaimRequest() {
    this.returnRequestForm.markAllAsTouched();
    if (!this.returnRequestForm.valid) {
      this._snackBar.open("Remark is required!", 'Close', {
        duration: 2000,
      });
      this.validateAllFormFields(this.returnRequestForm);
    } else {
      Swal.fire({
        title: "Confirmation",
        text: "This can not be undone. Are you sure, you want to return this claim request?",
        showCancelButton: true,
        confirmButtonText: "OK",
      }).then(async (result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
          const assignResponse: any = await this.returnClaimRequestToAdvisor().catch((error) => {
            console.log(error);
          });
          if (assignResponse.status == 200) {
            this.router.navigate([
              '/dashboard/asp-management']);
          }
        }
      });
    }
  }

  sendSMSToCustomer() {
    Swal.fire({
      title: "Confirmation",
      text: "This action is irreversible and cannot be undone.",
      showCancelButton: true,
      confirmButtonText: "OK",
    }).then(async (result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {


      }
    });
  }

  async reEvaluate(status: any) {
    this.decisionReceivedClaimRequest.controls['secondApproval'].addValidators([Validators.required])
    this.decisionReceivedClaimRequest.controls['secondApproval'].updateValueAndValidity()

    if (status == "pending") {
      this.decisionReceivedClaimRequest.controls['pendingReason'].clearValidators()
      this.decisionReceivedClaimRequest.controls['pendingReason'].updateValueAndValidity()
    } else if (status == "reject") {
      this.decisionReceivedClaimRequest.controls['rejectReason'].clearValidators()
      this.decisionReceivedClaimRequest.controls['rejectReason'].updateValueAndValidity()
    }
    this.decisionReceivedClaimRequest.markAllAsTouched();
    this.validateAllFormFields(this.decisionReceivedClaimRequest);
    let secondApproval = this.decisionReceivedClaimRequest.value.secondApproval;
    if (this.decisionReceivedClaimRequest.valid) {
      let dmsRequestmodel: DmsRequestDTO[] = [];
      if (status == "pending") {
        await this.includependingLetterFiles(dmsRequestmodel);
      } else if (status == "reject") {
        await this.includeRejectionLetterFiles(dmsRequestmodel);
      } else if (status == "approved") {
        await this.includeCreditNoteFiles(dmsRequestmodel);
      }
      let minimumDocumentsPresent;
      if (status == "pending") {
        minimumDocumentsPresent = true;
      } else {
        if (dmsRequestmodel.length == 0) {
          minimumDocumentsPresent = false;
        } else {
          minimumDocumentsPresent = true;
        }
      }

      if (minimumDocumentsPresent) {
        if (dmsRequestmodel.length == 1) {
          let dmsPayloadModel: DmsPayload = { dmsRequestDTOList: dmsRequestmodel, status: "update" }
          const documentUploadResponse: any = await this.saveClaimDocuments(dmsPayloadModel).catch((error) => {
            console.log(error);
            this.loading = false;
          });
          if (documentUploadResponse.status == 200) {
            this.loading = false;
            console.log("successfully uploaded");

          }
        }
        const assignResponse: any = await this.reEvaluateClaimRequestToSecondLevel().catch((error) => {
          console.log(error);
        });
        if (assignResponse.status == 200) {
          Swal.fire({
            title: "Success",
            text: "Claim is now assigned to second level user",
            confirmButtonText: "OK",
          }).then(async (result) => {
            if (result.isConfirmed) {
              this.router.navigate([
                '/dashboard/asp-management']);
            }
          });
        }
      } else {
        this._snackBar.open("Document is required!", 'Close', {
          duration: 2000,
        });
      }
    }
  }

  async submitToFinance() {
    let dmsRequestmodel: DmsRequestDTO[] = [];
    await this.includeCreditNoteFiles(dmsRequestmodel);
    this.loading = true;
    if (dmsRequestmodel.length != 0) {
      let dmsPayloadModel: DmsPayload = { dmsRequestDTOList: dmsRequestmodel, status: "update" }
      const documentUploadResponse: any = await this.saveClaimDocuments(dmsPayloadModel).catch((error) => {
        console.log(error);
        this.loading = false;
      });
      if (documentUploadResponse.status == 200) {
        this.loading = false;
        console.log("successfully uploaded");
        this._snackBar.open("Document upload completed!", 'Close', {
          duration: 2000,
        });

      }
      const assignResponse: any = await this.assignClaimRequestToFinance().catch((error) => {
        console.log(error);
      });
      if (assignResponse.status == 200) {
        Swal.fire({
          title: "Success",
          text: "Claim is now assigned to finance department",
          confirmButtonText: "OK",
        }).then(async (result) => {
          if (result.isConfirmed) {
            this.router.navigate([
              '/dashboard/asp-management']);
          }
        });
      }
    } else {
      this._snackBar.open("Credit note is required", 'Close', {
        duration: 2000,
      });
    }
  }

  async submitToHO() {
    this.actionCallcenterReview.markAllAsTouched();
    this.validateAllFormFields(this.actionCallcenterReview);
    if (this.actionCallcenterReview.valid) {
      const assignResponse: any = await this.assignClaimRequestToHO().catch((error) => {
        console.log(error);
      });
      if (assignResponse.status == 200) {
        Swal.fire({
          title: "Success",
          text: "Claim is now assigned to Head Office User",
          confirmButtonText: "OK",
        }).then(async (result) => {
          if (result.isConfirmed) {
            this.router.navigate([
              '/dashboard/asp-management']);
          }
        });
      }
    }

  }

  async PendingToAdvisor() {
    this.decisionReceivedClaimRequest.controls['pendingReason'].addValidators([Validators.required])
    this.decisionReceivedClaimRequest.controls['pendingReason'].updateValueAndValidity()
    this.decisionReceivedClaimRequest.markAllAsTouched();
    this.validateAllFormFields(this.decisionReceivedClaimRequest);
    if (this.decisionReceivedClaimRequest.valid) {
      let dmsRequestmodel: DmsRequestDTO[] = [];
      await this.includependingLetterFiles(dmsRequestmodel);
      this.loading = true;
      if (dmsRequestmodel.length != 0) {
        let dmsPayloadModel: DmsPayload = { dmsRequestDTOList: dmsRequestmodel, status: "update" }
        const documentUploadResponse: any = await this.saveClaimDocuments(dmsPayloadModel).catch((error) => {
          console.log(error);
          this.loading = false;
        });
        if (documentUploadResponse.status == 200) {
          this.loading = false;
          console.log("successfully uploaded");
          this._snackBar.open("Document upload completed!", 'Close', {
            duration: 2000,
          });

        }

      }
      const assignResponse: any = await this.pendingClaimRequestToAdvisor().catch((error) => {
        console.log(error);
      });
      if (assignResponse.status == 200) {
        Swal.fire({
          title: "Success",
          text: "Claim is now assigned to advisor",
          confirmButtonText: "OK",
        }).then(async (result) => {
          if (result.isConfirmed) {
            this.router.navigate([
              '/dashboard/asp-management']);
          }
        });
      }

    }
  }

  async InitialToCallCenter() {
    this.actionFirstLevelReview.markAllAsTouched();
    this.validateAllFormFields(this.actionFirstLevelReview);
    if (this.actionFirstLevelReview.valid) {
      let dmsRequestmodel: DmsRequestDTO[] = [];
      await this.includeSynopsisFiles(dmsRequestmodel);

      if (dmsRequestmodel.length != 0) {
        await this.includeOtherFiles(dmsRequestmodel);
        this.loading = true;
        const updateDetailsResponse: any = await this.updateClaimReviewDetails().catch((error) => {
          console.log(error);
          this.loading = false;
        });
        if (updateDetailsResponse.status == 200) {
          let dmsPayloadModel: DmsPayload = { dmsRequestDTOList: dmsRequestmodel, status: "update" }
          const documentUploadResponse: any = await this.saveClaimDocuments(dmsPayloadModel).catch((error) => {
            console.log(error);
            this.loading = false;
          });
          if (documentUploadResponse.status == 200) {
            this.loading = false;
            console.log("successfully uploaded");
            this._snackBar.open("Document upload completed!", 'Close', {
              duration: 2000,
            });

          }

          const assignResponse: any = await this.initialClaimRequestToCallCenter().catch((error) => {
            console.log(error);
          });
          if (assignResponse.status == 200) {
            Swal.fire({
              title: "Success",
              text: "Claim is now assigned to call center user",
              confirmButtonText: "OK",
            }).then(async (result) => {
              if (result.isConfirmed) {
                this.router.navigate([
                  '/dashboard/asp-management']);
              }
            });

          }
        } else if (updateDetailsResponse.status == 400) {
          this._snackBar.open(updateDetailsResponse.message, 'Close', {
            duration: 2000,
          });
        } else {
          this._snackBar.open("Failed to update review data!", 'Close', {
            duration: 2000,
          });
        }
      } else {
        this._snackBar.open("Synopsis document is required!", 'Close', {
          duration: 2000,
        });
      }
    }
  }

  async InitialToCallCenterAfterCallCenterDecision() {
    this.decisionReceivedClaimRequest.controls['secondApproval'].addValidators([Validators.required])
    this.decisionReceivedClaimRequest.controls['secondApproval'].updateValueAndValidity()
    this.decisionReceivedClaimRequest.markAllAsTouched();
    this.validateAllFormFields(this.decisionReceivedClaimRequest);
    if (this.decisionReceivedClaimRequest.valid) {
      const assignResponse: any = await this.initialClaimRequestToCallCenterAfterCallCenter().catch((error) => {
        console.log(error);
      });
      if (assignResponse.status == 200) {
        Swal.fire({
          title: "Success",
          text: "Claim is now assigned to call center user",
          confirmButtonText: "OK",
        }).then(async (result) => {
          if (result.isConfirmed) {
            this.router.navigate([
              '/dashboard/asp-management']);
          }
        });

      }
    }
  }

  async ApproveToCallCenter() {
    this.decisionReceivedClaimRequest.controls['secondApproval'].addValidators([Validators.required])
    this.decisionReceivedClaimRequest.controls['secondApproval'].updateValueAndValidity()
    this.decisionReceivedClaimRequest.markAllAsTouched();
    this.validateAllFormFields(this.decisionReceivedClaimRequest);
    if (this.decisionReceivedClaimRequest.valid) {
      let dmsRequestmodel: DmsRequestDTO[] = [];
      await this.includeCreditNoteFiles(dmsRequestmodel);
      this.loading = true;
      if (dmsRequestmodel.length != 0) {
        let dmsPayloadModel: DmsPayload = { dmsRequestDTOList: dmsRequestmodel, status: "update" }
        const documentUploadResponse: any = await this.saveClaimDocuments(dmsPayloadModel).catch((error) => {
          console.log(error);
          this.loading = false;
        });
        if (documentUploadResponse.status == 200) {
          this.loading = false;
          console.log("successfully uploaded");
          this._snackBar.open("Document upload completed!", 'Close', {
            duration: 2000,
          });
          const assignResponse: any = await this.approveClaimRequestToCallCenter().catch((error) => {
            console.log(error);
          });
          if (assignResponse.status == 200) {
            Swal.fire({
              title: "Success",
              text: "Claim is now assigned to call center user",
              confirmButtonText: "OK",
            }).then(async (result) => {
              if (result.isConfirmed) {
                this.router.navigate([
                  '/dashboard/asp-management']);
              }
            });
          }

        }


      } else {
        this._snackBar.open("Credit note is required", 'Close', {
          duration: 2000,
        });
      }


    }
  }

  async PendingToCallCenter() {
    this.decisionReceivedClaimRequest.controls['secondApproval'].addValidators([Validators.required])
    this.decisionReceivedClaimRequest.controls['pendingReason'].addValidators([Validators.required])
    this.decisionReceivedClaimRequest.controls['secondApproval'].updateValueAndValidity()
    this.decisionReceivedClaimRequest.markAllAsTouched();
    this.validateAllFormFields(this.decisionReceivedClaimRequest);
    if (this.decisionReceivedClaimRequest.valid) {
      let dmsRequestmodel: DmsRequestDTO[] = [];
      await this.includependingLetterFiles(dmsRequestmodel);
      this.loading = true;
      if (dmsRequestmodel.length != 0) {
        let dmsPayloadModel: DmsPayload = { dmsRequestDTOList: dmsRequestmodel, status: "update" }
        const documentUploadResponse: any = await this.saveClaimDocuments(dmsPayloadModel).catch((error) => {
          console.log(error);
          this.loading = false;
        });
        if (documentUploadResponse.status == 200) {
          this.loading = false;
          console.log("successfully uploaded");
          this._snackBar.open("Document upload completed!", 'Close', {
            duration: 2000,
          });

        }

      }
      const assignResponse: any = await this.pendingClaimRequestToCallCenter().catch((error) => {
        console.log(error);
      });
      if (assignResponse.status == 200) {
        Swal.fire({
          title: "Success",
          text: "Claim is now assigned to call center user",
          confirmButtonText: "OK",
        }).then(async (result) => {
          if (result.isConfirmed) {
            this.router.navigate([
              '/dashboard/asp-management']);
          }
        });
      }

    }
  }

  async rejectToCallCenter() {
    this.decisionReceivedClaimRequest.controls['secondApproval'].addValidators([Validators.required])
    this.decisionReceivedClaimRequest.controls['secondApproval'].updateValueAndValidity()
    this.decisionReceivedClaimRequest.controls['rejectReason'].addValidators([Validators.required])
    this.decisionReceivedClaimRequest.controls['rejectReason'].updateValueAndValidity()
    this.decisionReceivedClaimRequest.markAllAsTouched();
    this.validateAllFormFields(this.decisionReceivedClaimRequest);
    if (this.decisionReceivedClaimRequest.valid) {
      let dmsRequestmodel: DmsRequestDTO[] = [];
      await this.includeRejectionLetterFiles(dmsRequestmodel);
      this.loading = true;
      if (dmsRequestmodel.length != 0) {
        let dmsPayloadModel: DmsPayload = { dmsRequestDTOList: dmsRequestmodel, status: "update" }
        const documentUploadResponse: any = await this.saveClaimDocuments(dmsPayloadModel).catch((error) => {
          console.log(error);
          this.loading = false;
        });
        if (documentUploadResponse.status == 200) {
          this.loading = false;
          console.log("successfully uploaded");
          this._snackBar.open("Document upload completed!", 'Close', {
            duration: 2000,
          });

        }
        const assignResponse: any = await this.rejectClaimRequestToCallCenter().catch((error) => {
          console.log(error);
        });
        if (assignResponse.status == 200) {
          Swal.fire({
            title: "Success",
            text: "Claim is now assigned to call center user",
            confirmButtonText: "OK",
          }).then(async (result) => {
            if (result.isConfirmed) {
              this.router.navigate([
                '/dashboard/asp-management']);
            }
          });
        }

      } else {
        this._snackBar.open("Reject letter is required!", 'Close', {
          duration: 2000,
        });
      }

    }
  }

  async rejectToAdvisor() {

    this.decisionReceivedClaimRequest.controls['rejectReason'].addValidators([Validators.required])
    this.decisionReceivedClaimRequest.controls['rejectReason'].updateValueAndValidity()
    this.decisionReceivedClaimRequest.markAllAsTouched();
    this.validateAllFormFields(this.decisionReceivedClaimRequest);
    if (this.decisionReceivedClaimRequest.valid) {
      let dmsRequestmodel: DmsRequestDTO[] = [];
      await this.includeRejectionLetterFiles(dmsRequestmodel);
      this.loading = true;
      if (dmsRequestmodel.length != 0) {
        let dmsPayloadModel: DmsPayload = { dmsRequestDTOList: dmsRequestmodel, status: "update" }
        const documentUploadResponse: any = await this.saveClaimDocuments(dmsPayloadModel).catch((error) => {
          console.log(error);
          this.loading = false;
        });
        if (documentUploadResponse.status == 200) {
          this.loading = false;
          console.log("successfully uploaded");
          this._snackBar.open("Document upload completed!", 'Close', {
            duration: 2000,
          });

        }
        const assignResponse: any = await this.rejectClaimRequestToAdvisor().catch((error) => {
          console.log(error);
        });
        if (assignResponse.status == 200) {
          Swal.fire({
            title: "Success",
            text: "Claim is now assigned to advisor",
            confirmButtonText: "OK",
          }).then(async (result) => {
            if (result.isConfirmed) {
              this.router.navigate([
                '/dashboard/asp-management']);
            }
          });
        }

      } else {
        this._snackBar.open("Reject letter is required!", 'Close', {
          duration: 2000,
        });
      }
    }


  }

  async includeOtherFiles(dmsRequestmodel: DmsRequestDTO[]) {
    let dmsFileModel: DmsFiles[] = [];
    if (this.otherFiles != null) {
      for (let j = 0; j < this.otherFiles.files.length; j++) {
        if (!(typeof this.otherFiles.files[j] != "object" && this.otherFiles.files[j].includes("data:"))) {
          const base64 = await this.encryptDecryptService.fileToDataURL(this.otherFiles.files[j]);
          this.otherFiles.files[j] = base64;
        }
        let fileName = this.otherFiles.fileNameArray[j].split(".");
        if (fileName[1] == undefined) {
          fileName[1] = "pdf";
        }
        dmsFileModel.push({ extension: fileName[1], name: fileName[0], file: this.otherFiles.files[j] });

      }
      dmsRequestmodel.push({ type: 'claimReviewDocuments', policyNo: this.claimRequestData.policyNumber.replace('/', ''), contractNo: this.claimRequestData.claimRequestNumber + '-other', files: dmsFileModel })
    }
  }

  async includeSynopsisFiles(dmsRequestmodel: DmsRequestDTO[]) {
    let dmsFileModel: DmsFiles[] = [];
    if (this.synopsisFiles != null) {
      for (let j = 0; j < this.synopsisFiles.files.length; j++) {
        if (!(typeof this.synopsisFiles.files[j] != "object" && this.synopsisFiles.files[j].includes("data:"))) {
          const base64 = await this.encryptDecryptService.fileToDataURL(this.synopsisFiles.files[j]);
          this.synopsisFiles.files[j] = base64;
        }
        let fileName = this.synopsisFiles.fileNameArray[j].split(".");
        if (fileName[1] == undefined) {
          fileName[1] = "pdf";
        }
        dmsFileModel.push({ extension: fileName[1], name: fileName[0], file: this.synopsisFiles.files[j] });

      }
      dmsRequestmodel.push({ type: 'synonpsisDocuments', policyNo: this.claimRequestData.policyNumber.replace('/', ''), contractNo: this.claimRequestData.claimRequestNumber + '-synopsis', files: dmsFileModel })

    } else {
      this._snackBar.open("Synopsis document is required!", 'Close', {
        duration: 2000,
      });
    }

  }

  async includeCreditNoteFiles(dmsRequestmodel: DmsRequestDTO[]) {
    let dmsFileModel: DmsFiles[] = [];
    if (this.creditNoteFiles != null) {
      for (let j = 0; j < this.creditNoteFiles.files.length; j++) {
        if (!(typeof this.creditNoteFiles.files[j] != "object" && this.creditNoteFiles.files[j].includes("data:"))) {
          const base64 = await this.encryptDecryptService.fileToDataURL(this.creditNoteFiles.files[j]);
          this.creditNoteFiles.files[j] = base64;
        }
        let fileName = this.creditNoteFiles.fileNameArray[j].split(".");
        if (fileName[1] == undefined) {
          fileName[1] = "pdf";
        }
        dmsFileModel.push({ extension: fileName[1], name: fileName[0], file: this.creditNoteFiles.files[j] });

      }
      dmsRequestmodel.push({ type: 'creditNote', policyNo: this.claimRequestData.policyNumber.replace('/', ''), contractNo: this.claimRequestData.claimRequestNumber + '-creditNote', files: dmsFileModel })

    } else {
      this._snackBar.open("Credit note is required", 'Close', {
        duration: 2000,
      });
    }

  }

  async includependingLetterFiles(dmsRequestmodel: DmsRequestDTO[]) {
    let dmsFileModel: DmsFiles[] = [];
    if (this.pendingLetterFiles != null) {
      for (let j = 0; j < this.pendingLetterFiles.files.length; j++) {
        if (!(typeof this.pendingLetterFiles.files[j] != "object" && this.pendingLetterFiles.files[j].includes("data:"))) {
          const base64 = await this.encryptDecryptService.fileToDataURL(this.pendingLetterFiles.files[j]);
          this.pendingLetterFiles.files[j] = base64;
        }
        let fileName = this.pendingLetterFiles.fileNameArray[j].split(".");
        if (fileName[1] == undefined) {
          fileName[1] = "pdf";
        }
        dmsFileModel.push({ extension: fileName[1], name: fileName[0], file: this.pendingLetterFiles.files[j] });

      }
      dmsRequestmodel.push({ type: 'pendingLetter', policyNo: this.claimRequestData.policyNumber.replace('/', ''), contractNo: this.claimRequestData.claimRequestNumber + '-pendingLetter', files: dmsFileModel })

    }

  }

  async includeRejectionLetterFiles(dmsRequestmodel: DmsRequestDTO[]) {
    let dmsFileModel: DmsFiles[] = [];
    if (this.rejectionLetterFiles != null) {
      for (let j = 0; j < this.rejectionLetterFiles.files.length; j++) {
        if (!(typeof this.rejectionLetterFiles.files[j] != "object" && this.rejectionLetterFiles.files[j].includes("data:"))) {
          const base64 = await this.encryptDecryptService.fileToDataURL(this.rejectionLetterFiles.files[j]);
          this.rejectionLetterFiles.files[j] = base64;
        }
        let fileName = this.rejectionLetterFiles.fileNameArray[j].split(".");
        if (fileName[1] == undefined) {
          fileName[1] = "pdf";
        }
        dmsFileModel.push({ extension: fileName[1], name: fileName[0], file: this.rejectionLetterFiles.files[j] });

      }
      dmsRequestmodel.push({ type: 'rejectionLetter', policyNo: this.claimRequestData.policyNumber.replace('/', ''), contractNo: this.claimRequestData.claimRequestNumber + '-rejectionLetter', files: dmsFileModel })

    } else {
      this._snackBar.open("Rejection letter is required!", 'Close', {
        duration: 2000,
      });
    }

  }

  async saveClaimDocuments(payload: any) {
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .saveClaimDocuments(this.token, payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async loadSavedCreditnoteFilesFromClaimRequest(requestId: number) {
    console.log("loading loadSavedCreditnoteFilesFromClaimRequest")
    this.loading = true;
    let dmsPayloadModel: DmsFilesRetrieve = { policyNo: this.claimRequestData.policyNumber.replace('/', ''), contractNo: this.claimRequestData.claimRequestNumber + '-creditNote' };
    const documentretreiveResponse: any = await this.getClaimDocuments(dmsPayloadModel).catch((error) => {
      console.log(error);
    });
    if (documentretreiveResponse.status == 200) {

      this.creditNoteEditable = false;
      this.loading = false;
      let documentListFromDMS = documentretreiveResponse.payload[0];
      for (let j = 0; j < documentListFromDMS.files.length; j++) {
        this.selectedFiles.push(documentListFromDMS.files[j].file);
        this.files.push(documentListFromDMS.files[j].name);
      }
      this.creditNoteFiles = { fileNameArray: this.files, files: this.selectedFiles }
      this.files = [];
      this.selectedFiles = [];
    } else {
      this.loading = false;
    }
    this.loading = false;

  }

  async loadSavedOtherFilesFromClaimRequest(requestId: number) {
    this.loading = true;
    let dmsPayloadModel: DmsFilesRetrieve = { policyNo: this.claimRequestData.policyNumber.replace('/', ''), contractNo: this.claimRequestData.claimRequestNumber + '-other' };
    const documentretreiveResponse: any = await this.getClaimDocuments(dmsPayloadModel).catch((error) => {
      console.log(error);
    });
    if (documentretreiveResponse.status == 200) {

      this.otherDocumentEditable = false;
      this.loading = false;
      let documentListFromDMS = documentretreiveResponse.payload[0];
      for (let j = 0; j < documentListFromDMS.files.length; j++) {
        this.selectedFiles.push(documentListFromDMS.files[j].file);
        this.files.push(documentListFromDMS.files[j].name);
      }
      this.otherFiles = { fileNameArray: this.files, files: this.selectedFiles }
      this.files = [];
      this.selectedFiles = [];
    } else {
      this.loading = false;
    }
    this.loading = false;

  }

  async loadSavedSynopsisFilesFromClaimRequest(requestId: number) {
    this.loading = true;
    let dmsPayloadModel: DmsFilesRetrieve = { policyNo: this.claimRequestData.policyNumber.replace('/', ''), contractNo: this.claimRequestData.claimRequestNumber + '-synopsis' };
    const documentretreiveResponse: any = await this.getClaimDocuments(dmsPayloadModel).catch((error) => {
      console.log(error);
    });
    if (documentretreiveResponse.status == 200) {

      this.synopsisDocumentEditable = false;
      this.loading = false;
      let documentListFromDMS = documentretreiveResponse.payload[0];
      for (let j = 0; j < documentListFromDMS.files.length; j++) {
        this.selectedFiles.push(documentListFromDMS.files[j].file);
        this.files.push(documentListFromDMS.files[j].name);
      }
      this.synopsisFiles = { fileNameArray: this.files, files: this.selectedFiles }
      this.files = [];
      this.selectedFiles = [];
    } else if (documentretreiveResponse.status == 404) {
      this.synopsisDocumentEditable = true;
    } else {
      this.loading = false;
    }
    this.loading = false;

  }

  async loadSavedpendingLetterFilesFromClaimRequest(requestId: number) {
    this.loading = true;
    let dmsPayloadModel: DmsFilesRetrieve = { policyNo: this.claimRequestData.policyNumber.replace('/', ''), contractNo: this.claimRequestData.claimRequestNumber + '-pendingLetter' };
    const documentretreiveResponse: any = await this.getClaimDocuments(dmsPayloadModel).catch((error) => {
      console.log(error);
    });
    if (documentretreiveResponse.status == 200) {
      this.pendingLetterEditable = false;
      this.loading = false;
      let documentListFromDMS = documentretreiveResponse.payload[0];
      for (let j = 0; j < documentListFromDMS.files.length; j++) {
        this.selectedFiles.push(documentListFromDMS.files[j].file);
        this.files.push(documentListFromDMS.files[j].name);
      }
      this.pendingLetterFiles = { fileNameArray: this.files, files: this.selectedFiles }
      this.files = [];
      this.selectedFiles = [];
    } else {
      this.loading = false;
    }
    this.loading = false;

  }

  async loadSavedRejectionLetterFilesFromClaimRequest(requestId: number) {
    this.loading = true;
    let dmsPayloadModel: DmsFilesRetrieve = { policyNo: this.claimRequestData.policyNumber.replace('/', ''), contractNo: this.claimRequestData.claimRequestNumber + '-rejectionLetter' };
    const documentretreiveResponse: any = await this.getClaimDocuments(dmsPayloadModel).catch((error) => {
      console.log(error);
    });
    if (documentretreiveResponse.status == 200) {

      this.rejectionLetterEditable = false;
      this.loading = false;
      let documentListFromDMS = documentretreiveResponse.payload[0];
      for (let j = 0; j < documentListFromDMS.files.length; j++) {
        this.selectedFiles.push(documentListFromDMS.files[j].file);
        this.files.push(documentListFromDMS.files[j].name);
      }
      this.rejectionLetterFiles = { fileNameArray: this.files, files: this.selectedFiles }
      this.files = [];
      this.selectedFiles = [];
    } else {
      this.loading = false;
    }
    this.loading = false;

  }

  async assignClaimRequestToSecondLevel() {
    const request = {
      token: this.token,
      data: {
        claimRequestId: this.claimRequestId,
        userId: this.actionFirstLevelReview.value.secondApproval,
        remark: this.actionFirstLevelReview.value.decisionRemark,
        action: 3
      }
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .assignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async assignClaimRequestToSecondLevelAfterCallcenter() {
    const request = {
      token: this.token,
      data: {
        claimRequestId: this.claimRequestId,
        userId: this.decisionReceivedClaimRequest.value.secondApproval,
        remark: this.decisionReceivedClaimRequest.value.decisionRemark,
        action: 3
      }
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .assignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async addRemarkForClaimRequest(remark: any) {
    const request = {
      token: this.token,
      data: {
        claimRequestId: this.claimRequestId,
        decisionSummaryTitle: "Documents changed",
        remark: remark
      }
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .addClaimRemark(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async assignClaimRequestToSecondLevelAfterFirstLevel() {
    const request = {
      token: this.token,
      data: {
        claimRequestId: this.claimRequestId,
        userId: this.decisionReceivedClaimRequest.value.secondApproval,
        remark: this.decisionReceivedClaimRequest.value.decisionRemark,
        action: 3
      }
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .assignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async reEvaluateClaimRequestToSecondLevel() {
    let claimRemark;
    if (this.pendingReceived) {
      if (this.hasOtherComments) {
        claimRemark = "Pending reason - " + this.decisionReceivedClaimRequest.value.otherReason + "\n Additional Remarks - " + this.decisionReceivedClaimRequest.value.decisionRemark;
      } else {
        claimRemark = "Pending reason - " + this.decisionReceivedClaimRequest.value.pendingReason + "\n Additional Remarks - " + this.decisionReceivedClaimRequest.value.decisionRemark;
      }
    } else if (this.rejectReceived) {
      if (this.hasOtherComments) {
        claimRemark = "Reject reason - " + this.decisionReceivedClaimRequest.value.otherReason + "\n Additional Remarks - " + this.decisionReceivedClaimRequest.value.decisionRemark;
      } else {
        claimRemark = "Reject reason - " + this.decisionReceivedClaimRequest.value.rejectReason + "\n Additional Remarks - " + this.decisionReceivedClaimRequest.value.decisionRemark;
      }
    } else if (this.approvalReceived) {
      claimRemark = this.decisionReceivedClaimRequest.value.decisionRemark
    }
    const request = {
      token: this.token,
      data: {
        claimRequestId: this.claimRequestId,
        userId: this.decisionReceivedClaimRequest.value.secondApproval,
        remark: claimRemark,
        action: 3
      }
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .assignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async returnClaimRequestToAdvisor() {
    const request = {
      token: this.token,
      data: {
        claimRequestId: this.claimRequestId,
        remark: this.returnRequestForm.value.decisionRemark,
        action: 4
      }
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .assignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async assignClaimRequestToFinance() {
    const request = {
      token: this.token,
      data: {
        claimRequestId: this.claimRequestId,
        action: 6
      }
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .assignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async assignClaimRequestToHO() {
    let action;
    if (this.internalStatus == "Pending-Call Center Assign") {
      action = 8;
    } else if (this.internalStatus == "Rejected - Call Center  Assign") {
      action = 10;
    } else if (this.internalStatus == "Approved - Call Center Assign") {
      action = 12;
    } else if (this.internalStatus == "Intimate - Call Center Assign") {
      action = 16;
    }
    const request = {
      token: this.token,
      data: {
        claimRequestId: this.claimRequestId,
        action: action,
        remark: this.actionCallcenterReview.value.decisionRemark
      }
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .assignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async pendingClaimRequestToAdvisor() {
    let remark;
    if (this.hasOtherComments) {
      remark = "Pending reason - " + this.decisionReceivedClaimRequest.value.otherReason + "\n Additional Remarks - " + this.decisionReceivedClaimRequest.value.decisionRemark;
    } else {
      remark = "Pending reason - " + this.decisionReceivedClaimRequest.value.pendingReason + "\n Additional Remarks - " + this.decisionReceivedClaimRequest.value.decisionRemark;
    }
    const request = {
      token: this.token,
      data: {
        claimRequestId: this.claimRequestId,
        action: 1,
        remark: remark
      }
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .assignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async initialClaimRequestToCallCenter() {
    const request = {
      token: this.token,
      data: {
        claimRequestId: this.claimRequestId,
        action: 15,

        userId: this.actionFirstLevelReview.value.secondApproval,
        remark: this.actionFirstLevelReview.value.decisionRemark
      }
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .assignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async initialClaimRequestToCallCenterAfterCallCenter() {
    const request = {
      token: this.token,
      data: {
        claimRequestId: this.claimRequestId,
        action: 15,

        userId: this.decisionReceivedClaimRequest.value.secondApproval,
        remark: this.decisionReceivedClaimRequest.value.decisionRemark
      }
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .assignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async pendingClaimRequestToCallCenter() {
    let remark;
    if (this.hasOtherComments) {
      remark = "Pending reason - " + this.decisionReceivedClaimRequest.value.otherReason + "\n Additional Remarks - " + this.decisionReceivedClaimRequest.value.decisionRemark;
    } else {
      remark = "Pending reason - " + this.decisionReceivedClaimRequest.value.pendingReason + "\n Additional Remarks - " + this.decisionReceivedClaimRequest.value.decisionRemark;
    }
    const request = {
      token: this.token,
      data: {
        claimRequestId: this.claimRequestId,
        action: 7,

        userId: this.decisionReceivedClaimRequest.value.secondApproval,
        remark: remark
      }
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .assignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async approveClaimRequestToCallCenter() {
    const request = {
      token: this.token,
      data: {
        claimRequestId: this.claimRequestId,
        action: 11,
        userId: this.decisionReceivedClaimRequest.value.secondApproval,
        remark: this.decisionReceivedClaimRequest.value.decisionRemark
      }
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .assignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async rejectClaimRequestToAdvisor() {
    let remark;
    if (this.hasOtherComments) {
      remark = "Reject reason - " + this.decisionReceivedClaimRequest.value.otherReason + "\n Additional Remarks - " + this.decisionReceivedClaimRequest.value.decisionRemark;
    } else {
      remark = "Reject reason - " + this.decisionReceivedClaimRequest.value.rejectReason + "\n Additional Remarks - " + this.decisionReceivedClaimRequest.value.decisionRemark;
    }
    const request = {
      token: this.token,
      data: {
        claimRequestId: this.claimRequestId,
        action: 2,
        remark: remark
      }
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .assignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async rejectClaimRequestToCallCenter() {
    let remark;
    if (this.hasOtherComments) {
      remark = "Reject reason - " + this.decisionReceivedClaimRequest.value.otherReason + "\n Additional Remarks - " + this.decisionReceivedClaimRequest.value.decisionRemark;
    } else {
      remark = "Reject reason - " + this.decisionReceivedClaimRequest.value.rejectReason + "\n Additional Remarks - " + this.decisionReceivedClaimRequest.value.decisionRemark;
    }
    const request = {
      token: this.token,
      data: {
        claimRequestId: this.claimRequestId,
        action: 9,

        userId: this.decisionReceivedClaimRequest.value.secondApproval,
        remark: remark
      }
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .assignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getClaimDocuments(payload: any) {
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimDocuments(this.token, payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async assignClaimRequest() {
    const request = {
      token: this.token,
      data: {
      }

    }
    if (this.claimRequestUserAction == 1) {
      //approve
      request.data = {
        claimRequestId: this.claimRequestId,
        userId: this.actionClaimRequest.value.secondApproval,
        action: 6,
        remark: this.actionClaimRequest.value.actionRemark
      }
    } else if (this.claimRequestUserAction == 2) {
      //pending
      request.data = {
        claimRequestId: this.claimRequestId,
        action: 1,
        remark: this.actionClaimRequest.value.actionRemark
      }
    } else if (this.claimRequestUserAction == 3) {
      //reject
      request.data = {
        claimRequestId: this.claimRequestId,
        action: 2,
        remark: this.actionClaimRequest.value.actionRemark
      }
    } else if (this.claimRequestUserAction == 4) {
      //assign
      request.data = {
        claimRequestId: this.claimRequestId,
        userId: this.actionClaimRequest.value.secondApproval,
        action: 3,
        remark: this.actionClaimRequest.value.actionRemark
      }
    }

    return new Promise((resolve, reject) => {
      this.aspServiceService
        .assignClaimRequest(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async updateBankBranchDetails() {
    const request = {
      token: this.token,
      data: {
        claimRequestId: this.claimRequestId,
        remark: this.claimRequestForm.value.aditionalRemark,
        accountHolderName: this.claimRequestForm.value.accountHolderName,
        accountNumber: this.claimRequestForm.value.accountNumber,
        bankCode: this.claimRequestForm.value.bankName,
        bankBranchCode: this.claimRequestForm.value.branchName
      }

    }


    return new Promise((resolve, reject) => {
      this.aspServiceService
        .updateBankBranchDetails(request)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async updateClaimReviewDetails() {
    const paylaod = {
      claimRequestId: this.claimRequestId,
      claimNumber: this.actionFirstLevelReview.value.claimNumber,
      sumAssured: this.actionFirstLevelReview.value.sumAssured,
      paymentMode: this.actionFirstLevelReview.value.paymentMode,
      decisionSummary: this.actionFirstLevelReview.value.decisionSummary
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .updateClaimReviewDetails(this.token, paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getAssignedLevels() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId,
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getAssignedLevels(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getAssigneeUserListHO() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId,
      departmentId: 1
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getAssigneeUserList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getAssigneeUserListCallCenter() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId,
      departmentId: 3
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getAssigneeUserList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getCurrentAssignDetails() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId,
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getCurrentAssignDetails(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getTopHierarchyUserList() {
    const paylaod = {
      token: this.token,
      claimRequestId: this.claimRequestId,
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getTopHierarchyUserList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  public get policyNumberToRequest(): boolean {
    if (this.claimRequestForm.value.policyNumber == null ||
      this.claimRequestForm.value.policyNumber == "" ||
      this.claimRequestForm.value.policyNumber == undefined) {
      return false;

    } else {
      return true;
    }

  }


  public get policyNumber(): string {
    return this.claimRequestForm.value.policyNumber;
  }



}
