import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateCalimRequestComponent } from './update-calim-request.component';

describe('UpdateCalimRequestComponent', () => {
  let component: UpdateCalimRequestComponent;
  let fixture: ComponentFixture<UpdateCalimRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateCalimRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateCalimRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
