import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asp-management',
  templateUrl: './asp-management.component.html',
  styleUrls: ['./asp-management.component.scss']
})
export class AspManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
}