import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { AspManagementRoutingModule } from './asp-management-routing.module';
import { AspManagementComponent } from './asp-management.component';
import { ClaimRequestComponent } from './claim-request/claim-request.component';

import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatStepperModule} from '@angular/material/stepper';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { MatNativeDateModule } from '@angular/material/core';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTableModule } from '@angular/material/table';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSelectModule } from '@angular/material/select';
import { NgHttpLoaderModule } from "ng-http-loader";
import {MatMenuModule} from '@angular/material/menu';
import {MatChipsModule} from '@angular/material/chips';
import { ViewClaimRequestComponent } from './claim-request/view-claim-request/view-claim-request.component';
import { UploadClaimFormComponent } from './claim-request/upload-claim-form/upload-claim-form.component';

import { DocumentViewerDialogComponent } from './claim-request/upload-documents/document-viewer-dialog/document-viewer-dialog.component';
import {MatDialogModule} from '@angular/material/dialog';
import { CreateClaimRequestComponent } from './claim-request/create-claim-request/create-claim-request.component';
import { UploadDocumentsComponent } from './claim-request/upload-documents/upload-documents.component';
import { SignatureContainerComponent } from './claim-request/signature-container/signature-container.component';
import { SignatureBoxComponent } from './claim-request/signature-container/signature-box/signature-box.component';
import { MyClaimRequestComponent } from './claim-request/manage-claim-request/my-claim-request/my-claim-request.component';
import { MyAssignedClaimRequestComponent } from './claim-request/manage-claim-request/my-assigned-claim-request/my-assigned-claim-request.component';
import { MyOwnBranchClaimRequestComponent } from './claim-request/manage-claim-request/my-own-branch-claim-request/my-own-branch-claim-request.component';
import { AllCalimRequestComponent } from './claim-request/manage-claim-request/all-calim-request/all-calim-request.component';
import { UpdateCalimRequestComponent } from './claim-request/update-calim-request/update-calim-request.component';
import { MatRadioModule } from '@angular/material/radio';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { PendingClaimRequestComponent } from './claim-request/manage-claim-request/pending-claim-request/pending-claim-request.component';
import { AssignClaimRequestComponent } from './claim-request/manage-claim-request/assign-claim-request/assign-claim-request.component';
import { ApprovalRemakHistoryComponent } from './claim-request/approval-remak-history/approval-remak-history.component';
import { ActionClaimRequestComponent } from './claim-request/action-claim-request/action-claim-request.component';
import { IntimationClaimRequestComponent } from './claim-request/manage-claim-request/intimation-claim-request/intimation-claim-request.component';
import { SettlementClaimRequestComponent } from './claim-request/manage-claim-request/settlement-claim-request/settlement-claim-request.component';
import { AppealsClaimRequestComponent } from './claim-request/manage-claim-request/appeals-claim-request/appeals-claim-request.component';
import { RejectionClaimRequestComponent } from './claim-request/manage-claim-request/rejection-claim-request/rejection-claim-request.component';
import { FinanceAllClaimRequestComponent } from './claim-request/manage-claim-request/finance-all-claim-request/finance-all-claim-request.component';
import { PaidClaimHistoryComponent } from './claim-request/action-claim-request/paid-claim-history/paid-claim-history.component';
import { ResizeColumnDirective } from './resize-column.directive';
import { ApprovedClaimRequestComponent } from './claim-request/manage-claim-request/approved-claim-request/approved-claim-request.component';
import { TableModule } from 'primeng/table'; 
import { TagModule } from 'primeng/tag'; 
import { CardModule } from 'primeng/card';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { TimelineModule } from 'primeng/timeline';
import { ChartModule } from 'primeng/chart';
import { MultiSelectModule } from 'primeng/multiselect';
import { DropdownModule } from 'primeng/dropdown';
import { AspReportComponent } from './asp-report/asp-report.component';
import { CalendarModule } from 'primeng/calendar';

@NgModule({
  declarations: [
    AspManagementComponent,
    ClaimRequestComponent,
    ViewClaimRequestComponent,
    UploadClaimFormComponent,
    DocumentViewerDialogComponent,
    CreateClaimRequestComponent,
    UploadDocumentsComponent,
    SignatureContainerComponent,
    SignatureBoxComponent,
    MyClaimRequestComponent,
    MyAssignedClaimRequestComponent,
    MyOwnBranchClaimRequestComponent,
    AllCalimRequestComponent,
    UpdateCalimRequestComponent,
    PendingClaimRequestComponent,
    AssignClaimRequestComponent,
    ApprovalRemakHistoryComponent,
    ActionClaimRequestComponent,
    IntimationClaimRequestComponent,
    SettlementClaimRequestComponent,
    AppealsClaimRequestComponent,
    RejectionClaimRequestComponent,
    FinanceAllClaimRequestComponent,
    PaidClaimHistoryComponent,
    ResizeColumnDirective,
    ApprovedClaimRequestComponent,
    AspReportComponent,
  ],
  imports: [
    CommonModule,
    MatChipsModule,
    AspManagementRoutingModule,
    CommonModule,
    MatCardModule,
    MatIconModule,
    MatTabsModule,
    MatButtonModule,
    MatDividerModule,
    MatRadioModule,
    MatDatepickerModule,
    MatFormFieldModule,
    PdfViewerModule,
    ReactiveFormsModule.withConfig({
      callSetDisabledState: 'whenDisabledForLegacyCode',
    }),
    FormsModule,
    MatStepperModule,
    MatAutocompleteModule,
    MatMomentDateModule,
    MatNativeDateModule,
    MatInputModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatCheckboxModule,
    MatExpansionModule,
    MatTableModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSelectModule,
    MatMenuModule,
    MatDialogModule,
    CardModule,
    ButtonModule,
    InputTextModule,
    TimelineModule,
    NgHttpLoaderModule,
    TableModule,
    TagModule,
    ChartModule,
    DropdownModule,
    MultiSelectModule,
    CalendarModule
  ], providers: [DatePipe]
})
export class AspManagementModule { }
