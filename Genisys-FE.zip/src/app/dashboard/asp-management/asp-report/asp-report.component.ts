import { DatePipe } from '@angular/common';
import { Component, ViewChild } from '@angular/core';
import { MatRadioChange } from '@angular/material/radio';
import { AspModuleService } from '@app/shared/services/asp-module/asp-module.service';
import { Table } from 'primeng/table';

export interface Claims {
  id: number;
  requestNumber: string;
  claimNumber: string;
  policyNumber: string;
  username: string;
  branch: string
  zone: string;
  claimType: string;
  requestReceiveDate: string;
  lastDecision: string;
  status: string;
  assignedLevel: string,
  daysFromCreation: string;
  daysFromAssignment: string;
  daysToClear: string;
  daysToComplete: string;
  jobAssignId: string;
}

@Component({
  selector: 'app-asp-report',
  templateUrl: './asp-report.component.html',
  styleUrls: ['./asp-report.component.scss']
})
export class AspReportComponent {
  @ViewChild('dt') dt: Table | undefined;

  selectedClaimType = -1;
  selectedStatus = -1;
  selectedUser = -1;
  wiseSelection = 1;
  fromDate = new Date();
  toDate = new Date();
  displayedColumns: string[] = ['id', 'name', 'date', 'status'];
  dataSource: Claims[];
  cols: any[];
  token: any;
  claimTypes: any;
  statuses: any;
  users: any;
  fileName = "Claim Wise Report";
  globalSearchValue: string = '';

  constructor(private aspServiceService: AspModuleService, private datePipe: DatePipe) {

    this.dataSource = [];
    this.cols = [
      {
        field: 'requestNumber',
        header: 'Claim Request Number'
      },
      {
        field: 'policyNumber',
        header: 'Policy Number'
      },
      {
        field: 'claimNumber',
        header: 'Claim Number'
      },
      {
        field: 'jobAssignId',
        header: 'Job Id'
      },
      {
        field: 'username',
        header: 'Assigned User'
      },
      {
        field: 'branch',
        header: 'Branch Name'
      },
      {
        field: 'zone',
        header: 'Zone'
      },
      {
        field: 'claimType',
        header: 'Claim Type'
      },
      {
        field: 'requestReceiveDate',
        header: 'Request Received Date'
      },
      {
        field: 'lastDecision',
        header: 'Updated Date'
      },
      {
        field: 'status',
        header: 'Status'
      },
      {
        field: 'assignedLevel',
        header: 'Assigned Level'
      },
      {
        field: 'daysFromCreation',
        header: 'Days From Creation'
      },
      {
        field: 'daysFromAssignment',
        header: 'Days From Assignment'
      },
      {
        field: 'daysToClear',
        header: 'Days To Clear'
      },
      {
        field: 'daysToComplete',
        header: 'Days To Complete'
      },
    ];

  }

  async ngOnInit(): Promise<void> {
    const claimListResponse: any = await this.getClaimList().catch((error) => {
      console.log(error);
    });
    if (claimListResponse.status == 200) {
      this.claimTypes = claimListResponse.payload;
    }

    const statusListResponse: any = await this.getStatusList().catch((error) => {
      console.log(error);
    });
    if (statusListResponse.status == 200) {
      this.statuses = statusListResponse.payload;
    }

    const assignedusersResponse: any = await this.getAssignableUsers(true).catch((error) => {
      console.log(error);
    });
    if (assignedusersResponse.status == 200) {
      this.users = assignedusersResponse.payload;
    }

    // this.fromDate.setHours(0, 0, 0, 0);
    // this.toDate.setHours(23, 59, 0, 0);
    // let reportModel: any = {
    //   "startDate": this.datePipe.transform(this.fromDate, 'yyyy-MM-dd HH:mm:ss.SSSSSS'),
    //   "endDate": this.datePipe.transform(this.toDate, 'yyyy-MM-dd HH:mm:ss.SSSSSS'),
    //   "claimListId": this.selectedClaimType,
    //   "requestStatusId": this.selectedStatus,
    //   "userId": this.selectedUser,
    // }
    // if (this.wiseSelection == 1) {
    //   reportModel.claimWise = true;
    // } else {
    //   reportModel.jobWise = true;
    // }
    // let payload = {
    //   token: this.token,
    //   data: reportModel
    // }
    // const reportResponse: any = await this.getReportData(payload).catch((error) => {
    //   console.log(error);
    // });
    // if (reportResponse.status == 200) {
    //   this.dataSource = reportResponse.payload;
    // }
    this.onSearch();
  }

  async onSearch() {

    this.fromDate.setHours(0, 0, 0, 0);
    this.toDate.setHours(23, 59, 0, 0);
    let reportModel: any = {
      "startDate": this.datePipe.transform(this.fromDate, 'yyyy-MM-dd HH:mm:ss.SSSSSS'),
      "endDate": this.datePipe.transform(this.toDate, 'yyyy-MM-dd HH:mm:ss.SSSSSS'),
      "claimListId": this.selectedClaimType,
      "requestStatusId": this.selectedStatus,
      "userId": this.selectedUser,
    }
    if (this.wiseSelection == 1) {
      reportModel.claimWise = true;
    } else {
      reportModel.jobWise = true;
    }
    let payload = {
      token: this.token,
      data: reportModel
    }
    const reportResponse: any = await this.getReportData(payload).catch((error) => {
      console.log(error);
    });
    if (reportResponse.status == 200) {
      this.dataSource = reportResponse.payload;
      this.dataSource = this.dataSource.map(item => {
        const requestDateFormatted = this.formatDate(item.requestReceiveDate);
        const lastDecisionFormatted = this.formatDate(item.lastDecision);
      
        return {
          ...item,
          requestReceiveDateFormatted: requestDateFormatted,
          requestReceiveDate: requestDateFormatted !== '-' ? `"${requestDateFormatted}"` : requestDateFormatted,
      
          lastDecisionFormatted: lastDecisionFormatted,
          lastDecision: lastDecisionFormatted !== '-' ? `"${lastDecisionFormatted}"` : lastDecisionFormatted,

          jobAssignIdFormatted:item.jobAssignId,
          jobAssignId:`"${item.jobAssignId}"`,
        };
      });
      console.log(this.dataSource)
    }
  }

  get maxDate(): Date {
    return new Date();
  }

  // formatDate(value: any): string {
  //   if (!value) return value; 

  //   const date = new Date(value);
  //   if (isNaN(date.getTime())) {
  //     return value; 
  //   }

  //   return new Intl.DateTimeFormat('en-GB', {
  //     year: 'numeric', month: '2-digit', day: '2-digit',
  //     hour: '2-digit', minute: '2-digit', second: '2-digit',
  //     hour12: false
  //   }).format(date).replace(',', ''); // format similar to 'yyyy-MM-dd HH:mm:ss'
  // }

  formatDate(value: string): string {
    if (!value) return value;

    // Match dd/MM/yyyy HH:mm:ss
    const match = value.match(/^(\d{2})\/(\d{2})\/(\d{4}) (\d{2}):(\d{2}):(\d{2})$/);
    if (!match) return value;

    const [, day, month, year, hour, minute, second] = match;

    return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
  }

  clear(table: Table) {
    table.clear();
    this.globalSearchValue = '';
  }

  onWiseSelectionChange(event: MatRadioChange) {
    if (event.value === 1) {
      this.fileName = "Claim Wise Report";
    } else if (event.value === 2) {
      this.fileName = "Job Wise Report";
    }
  }

  convertToCapitalized(value: string): string {
    if (!value) return '';
    value = value.toLowerCase();
    return value.charAt(0).toUpperCase() + value.slice(1);
  }

  async getClaimList() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getClaimList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getStatusList() {
    const paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getStatusList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  async getAssignableUsers(isBulk: boolean) {
    let paylaod = {
      token: this.token
    }
    return new Promise((resolve, reject) => {
      this.aspServiceService
        .getAssigneeUserList(paylaod)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getReportData(payload: any) {

    return new Promise((resolve, reject) => {

      this.aspServiceService.getReportData(payload)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
