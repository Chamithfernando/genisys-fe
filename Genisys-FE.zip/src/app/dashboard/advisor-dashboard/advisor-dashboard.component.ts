import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepicker } from '@angular/material/datepicker';
import { AuthService } from '@app/shared/services/auth/auth.service';
import { AllowanceService } from '@app/shared/services/finance/allowance.service';
import { PolicyListService } from '@app/shared/services/policy-listing-report/policy-listing-report.service';
import * as _moment from 'moment';

import { default as _rollupMoment, Moment } from 'moment';

const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/YYYY',
  },
  display: {
    dateInput: 'MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
@Component({
  selector: 'app-advisor-dashboard',
  templateUrl: './advisor-dashboard.component.html',
  styleUrls: ['./advisor-dashboard.component.scss'],
  providers: [

    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },

    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})
export class AdvisorDashboardComponent implements OnInit {
  date = new UntypedFormControl(moment());
  advisor = new UntypedFormControl();
  currentDate = new Date();
  panelOpenState = false;
  isAdvisorAllowanceAvailable = false;
  advisors: any;
  modifyDate: any;
  dateSelected: any;
  listingForm: UntypedFormGroup;
  reportDownloding = true;
  policyLoad = false;
  categoryStatus = false;
  zoneStatus = false;
  regionStatus = false;
  branchStatus = false;
  advisorStatus = false;
  policyStatus = true;
  submitStatus = true;

  zoneId: number;
  regionId: number;
  branchId: number;
  advisorId: number;
  policyStatusValue: string = '';

  branchCode: string = '';
  advisorCode: string = '';

  selectedZone = 'Not selected';
  selectedRegion = 'Not selected';
  selectedBranch = 'Not selected';
  selectedAgent = 'Not selected';

  selectedCriteriaStatus = false;
  tableProgress = false;



  categoryArray: any = [];
  zoneArray: any = [];
  regionArray: any = [];
  branchArray: any = [];
  advisorArray: any = [];
  statusArray: any = [];
  token: any;
  selected: any;
  setMonthAndYear(normalizedMonthAndYear: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.date.value!;
    ctrlValue.month(normalizedMonthAndYear.month());
    ctrlValue.year(normalizedMonthAndYear.year());
    this.date.setValue(ctrlValue);

    datepicker.close();
    this.modifyDate = moment(this.date.value);
    this.dateSelected = this.modifyDate.format('MM-YYYY');
    this.search(this.dateSelected);
  }
  constructor(
    private allowanceService: AllowanceService,
    private policyListngReportForm: UntypedFormBuilder,
    private policyListService: PolicyListService,
    private authService: AuthService
  ) { }

  ngOnInit(): void {
    this.selected = 0;
    this.token = this.authService.getCurrentUserDetails().access_token;
    this.dateSelected = (new Date().getMonth() + 1).toString() + '-' + new Date().getFullYear().toString();
    this.listingForm = this.policyListngReportForm.group({
      category: new UntypedFormControl(''),
      region: new UntypedFormControl(0),
      advisor: new UntypedFormControl(''),
      zone: new UntypedFormControl(''),
      branch: new UntypedFormControl('', [Validators.required]),
      pstatus: new UntypedFormControl('')
    });
    this.setData();
  }
  setData() {
    this.token = this.authService.getCurrentUserDetails().access_token;
    this.policyListService.onInitForDashboard(this.token).subscribe(response => {
      this.categoryArray = response.categoryResponse.categoryList;
      this.zoneArray = response.zoneResponse?.zoneDTOList ? [] : response.zoneResponse?.zoneDTOList;
      this.regionArray = response.regionResponse.regionDTOList;
      this.branchArray = response.branchResponse.branchDTOList;
      this.advisorArray = response.advisorResponse.validAdvisorDTOS;
      this.categoryStatus = !response.categoryResponse.enable;
      this.zoneStatus = !response.zoneResponse.enable;
      this.regionStatus = !response.regionResponse.enable;
      this.branchStatus = !response.branchResponse.enable;
      this.advisorStatus = !response.advisorResponse.enable;

      this.patchValues(response);
    });

    this.policyListService.getPolicyStatus(this.token).subscribe(response => {
      this.statusArray = response.payload;
      this.listingForm.patchValue({
        pstatus: response.payload[0].id
      })
    });
  }

  search(dateWithMonthYear) {

    const date = dateWithMonthYear.split('-');
    const data = {
      month: Number(date[0]),
      year: Number(date[1]),
      branchCode: this.advisorCode ? '' : this.branchCode,
      agentCode: this.advisorCode
    }
    this.allowanceService.allowanceDashboard(data).subscribe((response) => {
      this.isAdvisorAllowanceAvailable = false;
      this.advisors = response.payload;

      if (this.advisors?.length > 0) {
        this.isAdvisorAllowanceAvailable = true;
      }

    })
  }
  private clearExcelExportData() {
    this.selectedZone = 'Not selected';
    this.selectedRegion = 'Not selected';
    this.selectedBranch = 'Not selected';
    this.selectedAgent = 'Not selected';

  }
  onZoneChange(event) {

    this.zoneId = this.listingForm.value.zone;
    this.policyListService.getRegionListByZone(this.zoneId, this.token).subscribe(response => {
      this.regionArray = response.payload;
      this.regionStatus = false;

      this.clearExcelExportData();
    })
  }
  patchValues(param: any) {
    this.listingForm.patchValue({
      category: param?.categoryResponse.categoryList[0].id,
      zone: param?.zoneResponse.zoneDTOList[0]?.zoneId,
      region: 0,
      branch: param?.branchResponse.branchDTOList[0]?.branchCode,
      advisor: param?.advisorResponse.validAdvisorDTOS[0]?.id
    })
  }
  onRegionChange(event) {

    this.regionId = this.listingForm.value.region;
    this.policyListService.getBranchesByRegion(this.regionId, this.token).subscribe(response => {
      this.branchArray = response.payload;
      this.branchStatus = false;

      this.advisorArray = [];
      this.clearExcelExportData();
    })

  }
  onAgentChange(event) {
    this.advisorCode = event.value;
    this.onSearch()
  }
  onCategoryChange(event) {
    if (event.value == 1) {

      this.policyListService.getAllZones(this.token).subscribe(response => {
        this.zoneArray = response.payload;
        this.regionArray = [];
        this.branchArray = [];

        this.zoneStatus = false;
        this.regionStatus = true;
        this.branchStatus = true;

      })
    } else if (event.value == 2) {

      this.policyListService.getAllRegions(this.token).subscribe(response => {
        this.regionArray = response.payload;
        this.zoneArray = [];
        this.branchArray = [];

        this.regionStatus = false;
        this.zoneStatus = true;
        this.branchStatus = true;

      })
    } else {

      this.policyListService.getAllBranches(this.token).subscribe(response => {
        this.branchArray = response.payload;
        this.zoneArray = [];
        this.regionArray = [];

        this.branchStatus = false;
        this.zoneStatus = true;
        this.regionStatus = true;

      })
      this.onSearch();
    }
    this.clearExcelExportData();
  }

  onClear() {
    this.listingForm.reset();
    this.advisor.reset();
    this.isAdvisorAllowanceAvailable = false;
    this.dateSelected = new UntypedFormControl(moment());
    this.date = new UntypedFormControl(moment());
    this.branchCode = '';
    this.advisorCode = '';
  }
  onBranchChange($event) {

    this.branchId = this.listingForm.value.branch;
    this.branchCode = $event.value;


    this.policyListService.getAdvisorsListByBranch(this.branchId, this.token).subscribe(response => {
      this.advisorCode = '';
      this.advisorArray = response.validAdvisorDTOS;

      this.advisorStatus = false;
      this.clearExcelExportData();
      this.onSearch();
    });

  }
  onSearch() {
    this.search(this.dateSelected);
  }

}
