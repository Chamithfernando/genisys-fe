import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { AzppService } from '@app/shared/services/azpp/azpp.service';
import { AuthService } from '@app/shared/services/auth/auth.service';
import { validateKeyPress, validatePasteSpecialCharacters } from '../../validation/validation.component';
import { showErrorMessage, showSucessMessage } from '../../validation/validation.component';

export interface CoverLimits {
  value: number;
  viewValue: string;
}

@Component({
  selector: 'app-add-bank',
  templateUrl: './add-bank.component.html',
  styleUrls: ['./add-bank.component.scss']
})
export class AddBankComponent implements OnInit {
  bank: UntypedFormGroup;
  categories: any;
  category: any;

  coverLimits: CoverLimits[] = [
    { value: 100000, viewValue:  '100,000' },
    { value: 1000000, viewValue: '1,000,000' },
    { value: 2000000, viewValue: '2,000,000' },
    { value: 3000000, viewValue: '3,000,000' },
    { value: 4000000, viewValue: '4,000,000' },
    { value: 5000000, viewValue: '5,000,000' },
    { value: 6000000, viewValue: '6,000,000' },
    { value: 7000000, viewValue: '7,000,000' },
    { value: 8000000, viewValue: '8,000,000' },
    { value: 9000000, viewValue: '9,000,000' },
    { value: 10000000, viewValue: '10,000,000' },
  ];

  constructor(public dialogRef: MatDialogRef<AddBankComponent>,
    private formBuilder: UntypedFormBuilder,
    private azppService: AzppService,
    private authService: AuthService) {
    dialogRef.disableClose = true;

    this.bank = this.formBuilder.group({
      bankName: new UntypedFormControl('', [Validators.required, Validators.maxLength(50),]),
      shortName: new UntypedFormControl('', [Validators.required, Validators.maxLength(5),]),
      category: new UntypedFormControl('', Validators.required),
      coverLimit: new UntypedFormControl(''),
    });

  }

  ngOnInit(): void {
    this.getListofCategory();
  }



  //Bank Name validate
  onKeyPress(event: KeyboardEvent) {
    validateKeyPress(event);
  }

  validatePasteSpecialCharacters(event: ClipboardEvent) {
    validatePasteSpecialCharacters(event);
  }

  validate() {
    if (!this.bank.value.bankName || !this.bank.value.bankName.toString().trim()) {
      showErrorMessage('Bank name is required');
      return false;
    }
    else if (!this.bank.value.shortName || !this.bank.value.shortName.toString().trim()) {
      showErrorMessage('Short name is required');
      return false;
    }
    else if (!this.bank.value.category) {
      showErrorMessage('Category is required');
      return false;
    }
    return true;
  }


  //Get Category List
  async getListofCategory() {
    const categoryList: any = await this.getCategory().catch((error) => {
      console.log(error);
    });

    if (categoryList.status == 200) {
      this.categories = categoryList.payload;

    }
  }

  async getCategory() {
    return new Promise((resolve, reject) => {
      this.azppService
        .getCategoryList(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


  //Add bank
  async saveBankRecords() {
    if (this.validate()) {

      const data = {
        name: this.bank.value.bankName,
        shortName: this.bank.value.shortName,
        freeCoverLimit: this.bank.value.coverLimit,
        prefix: this.bank.value.category
      };
      const saveBankResponse: any = await this.saveRecord(data).catch(
        (err) => {
          console.log(err);
        }
      );

      if (saveBankResponse.status === 201) {
        showSucessMessage(saveBankResponse.message);
        this.dialogRef.close(true);

        console.log('saveBankResponse 201', saveBankResponse)
      } else {
        console.log('saveBankResponse', saveBankResponse)
        showErrorMessage(saveBankResponse.message);
      }
    }
  }


  saveRecord(data: any) {
    return new Promise((resolve, reject) => {
      this.azppService
        .addBank(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


}
