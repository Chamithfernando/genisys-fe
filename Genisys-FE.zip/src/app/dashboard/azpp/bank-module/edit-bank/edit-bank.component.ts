import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { CoverLimits } from '../add-bank/add-bank.component';
import { validateKeyPress, validatePasteSpecialCharacters } from '../../validation/validation.component';
import { showErrorMessage, showSucessMessage } from '../../validation/validation.component';
import { AzppService } from '@app/shared/services/azpp/azpp.service';
import { AuthService } from '@app/shared/services/auth/auth.service';

@Component({
  selector: 'app-edit-bank',
  templateUrl: './edit-bank.component.html',
  styleUrls: ['./edit-bank.component.scss']
})
export class EditBankComponent implements OnInit {
  bank: UntypedFormGroup;
  categories: any;
  category: any;

  coverLimits: CoverLimits[] = [
    { value: 100000, viewValue:  '100,000' },
    { value: 1000000, viewValue: '1,000,000' },
    { value: 2000000, viewValue: '2,000,000' },
    { value: 3000000, viewValue: '3,000,000' },
    { value: 4000000, viewValue: '4,000,000' },
    { value: 5000000, viewValue: '5,000,000' },
    { value: 6000000, viewValue: '6,000,000' },
    { value: 7000000, viewValue: '7,000,000' },
    { value: 8000000, viewValue: '8,000,000' },
    { value: 9000000, viewValue: '9,000,000' },
    { value: 10000000, viewValue: '10,000,000' },
  ];

  constructor(public dialogRef: MatDialogRef<EditBankComponent>,
    private formBuilder: UntypedFormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private azppService: AzppService,
    private authService: AuthService,) {

    this.bank = this.formBuilder.group({
      bankName: new UntypedFormControl('', [Validators.required, Validators.maxLength(50)]),
      shortName: new UntypedFormControl('', [Validators.required, Validators.maxLength(5)]),
      coverLimit: new UntypedFormControl(''),
    });
  }

  ngOnInit(): void {
    this.setValues(this.data)
  }

  setValues(data: any) {
    this.bank.patchValue({
      bankName: data.name,
      shortName: data.shortName,
      coverLimit: data.freeCoverLimit
    });
  }

  //Bank Name validate
  onKeyPress(event: KeyboardEvent) {
    validateKeyPress(event);
  }

  validatePasteSpecialCharacters(event: ClipboardEvent) {
    validatePasteSpecialCharacters(event);
  }

  validate() {
    if (!this.bank.value.bankName || !this.bank.value.bankName.toString().trim()) {
      showErrorMessage('Bank name is required');
      return false;
    }
    else if (!this.bank.value.shortName || !this.bank.value.shortName.toString().trim()) {
      showErrorMessage('Short name is required');
      return false;
    } 

    return true;
  }

  //Edit user
  async editBankRecord() {
    if (this.validate()) {

      const data = {
        id: this.data.id,
        name: this.bank.value.bankName,
        shortName: this.bank.value.shortName,
        freeCoverLimit: this.bank.value.coverLimit,
      };

      const saveResponse: any = await this.saveRecord(data).catch(
        (err) => {
          console.log(err);
        }
      );

      if (saveResponse.status === 200) {
        showSucessMessage(saveResponse.message);
        this.dialogRef.close(true);

      } else {
        showErrorMessage(saveResponse.message);
      }
    }
  }

  saveRecord(data: any) {
    return new Promise((resolve, reject) => {
      this.azppService
        .editBank(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


}
