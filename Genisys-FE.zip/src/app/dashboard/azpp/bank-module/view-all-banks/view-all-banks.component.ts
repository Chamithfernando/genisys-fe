import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { AddBankComponent } from '../add-bank/add-bank.component';
import { EditBankComponent } from '../edit-bank/edit-bank.component';
import { DeleteBankComponent } from '../delete-bank/delete-bank.component';
import { AzppService } from '@app/shared/services/azpp/azpp.service';
import { AuthService } from '@app/shared/services/auth/auth.service';
import { ActivatedRoute } from '@angular/router';
import * as XLSX from 'xlsx';
import { validatePasteSpecialCharacters, validateKeyPress } from '../../validation/validation.component';


@Component({
  selector: 'app-view-all-banks',
  templateUrl: './view-all-banks.component.html',
  styleUrls: ['./view-all-banks.component.scss']
})
export class ViewAllBanksComponent implements OnInit {
  displayedColumns: string[] = ['no','id', 'name', 'shortName', 'branchName', 'edit', 'delete'];
  dataSource = new MatTableDataSource
  bankRecordListObj: any;
  bankRecordList: any;
  branchId: any;


  customData: string | undefined; 

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dialogRef: MatDialogRef<any>;

  constructor(public dialog: MatDialog,
    private azppService: AzppService,
    private authService: AuthService) { }

  
  ngOnInit(): void {
    this.getAllBankRecords();

  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();
    if (filterValue.length <= 50) {
      this.dataSource.filter = filterValue;
    } else {
      Swal.fire({
        icon: 'error',
        title: 'Filter value cannot exceed 50 characters',
        timer: 4000,
        showConfirmButton: true,
        customClass: {
          confirmButton: 'btn-ok',
        }
      }).then(() => {
        (event.target as HTMLInputElement).value = '';
        this.dataSource.filter = '';
      });
    }
    this.dataSource.filterPredicate = (data: any, filter: string) => {
      const dataStr = data.name.toLowerCase() + data.shortName.toLowerCase();
      const branchNameMatch = data.branches.some(branch => branch.branchName.toLowerCase().includes(filter));

     
      return dataStr.includes(filter) || branchNameMatch;
    };
  }

  
  onKeyPress(event: KeyboardEvent) {
    validateKeyPress(event);
  }

  validatePasteSpecialCharacters(event: ClipboardEvent) {
    validatePasteSpecialCharacters(event);
  }

  addUser() {
    this.dialogRef = this.dialog.open(AddBankComponent, {
      width: '600px',
      disableClose: true,
    });

    this.dialogRef.afterClosed().subscribe((response) => {
      if (response) {
        this.getAllBankRecords();
      }
    });
  }

  editUser(e: any, element: any) {
    this.dialogRef = this.dialog.open(EditBankComponent, {
      width: '600px',
      disableClose: true,
      data: element,
    });

    this.dialogRef.afterClosed().subscribe((response) => {
      if (response) {
        this.getAllBankRecords();
      }
    });

  }

  deleteUser(e: any, element: any): void {
    this.dialogRef = this.dialog.open(DeleteBankComponent, {
      width: '400px',
      disableClose: true,
      data: element,
    });

    this.dialogRef.afterClosed().subscribe((response) => {
      if (response) {
        this.getAllBankRecords();
      }
    });
  }

  // Get All Bank Records
  async getAllBankRecords() {
    this.bankRecordListObj = await this.getBankList().catch((error) => {
      console.log(error);
    });

    if (this.bankRecordListObj.status == 200) {
      this.bankRecordList = this.bankRecordListObj.payload;

      this.bankRecordList = this.bankRecordList.map((item, index) => {
        return { ...item, sequenceNumber: index + 1 };
      });

    }
    this.dataSource = new MatTableDataSource(this.bankRecordList);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;

  }

  async getBankList() {
    return new Promise((resolve, reject) => {
      this.azppService
        .getBankRecordList(
          this.authService.getCurrentUserDetails().access_token
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  exportToExcel(): void {
    const dataToExport = this.bankRecordList.map((item) => {
      return {
        Bank_Name: item.name,
        Short_Name: item.shortName,
        Branch_Name: item.branches.map((branch) => branch.branchName).join(', '),
      };
    });
  
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(dataToExport);
  
    const columnWidths = dataToExport.map((row) =>
      Object.values(row).map((val) => val.toString().length)
    );
  
    const maxColumnWidths = columnWidths.reduce((prev, curr) =>
      curr.map((val, i) => Math.max(val, prev[i]))
    );
  
    ws['!cols'] = maxColumnWidths.map((width) => ({ wch: width }));
  
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'BankRecords');
    XLSX.writeFile(wb, 'bank_records.xlsx');
  }
  
}
