import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { showErrorMessage, showSucessMessage } from '../../validation/validation.component';
import { AzppService } from '@app/shared/services/azpp/azpp.service';
import { AuthService } from '@app/shared/services/auth/auth.service';

@Component({
  selector: 'app-delete-bank',
  templateUrl: './delete-bank.component.html',
  styleUrls: ['./delete-bank.component.scss']
})
export class DeleteBankComponent implements OnInit {
  delete: UntypedFormGroup;
  bankName: string;

  constructor(public dialogRef: MatDialogRef<DeleteBankComponent>,
    private formBuilder: UntypedFormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private azppService: AzppService,
    private authService: AuthService) {
    dialogRef.disableClose = true;

    this.delete = this.formBuilder.group({
      bankName: new UntypedFormControl(''),
    });

  }

  ngOnInit(): void {
    this.bankName = this.data.name;
  }

  // setValue(data: any) {
  //   this.delete.patchValue({
  //     bankName: data,
  //   });
  // }

   //Edit user
   async deleteBankRecord() {

      const data = {
        id: this.data.id,
        status: false,
      };

      console.log('data', data)
      const saveResponse: any = await this.saveRecord(data).catch(
        (err) => {
          console.log(err);
        }
      );

      console.log('saveResponse', saveResponse)
      if (saveResponse.status === 200) {
        showSucessMessage(saveResponse.message);
        this.dialogRef.close(true);

      } else {
        showErrorMessage(saveResponse.message);
      }
  }

  saveRecord(data: any) {
    return new Promise((resolve, reject) => {
      this.azppService
        .deleteBank(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


}
