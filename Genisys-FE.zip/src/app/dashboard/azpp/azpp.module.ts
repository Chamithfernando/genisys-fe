import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AzppRoutingModule } from './azpp-routing.module';
import { CalculateCoverSingleUserComponent } from './calculate-covers/calculate-cover-single-user/calculate-cover-single-user.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input'
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule } from '@angular/material/dialog';
import { MatChipsModule } from '@angular/material/chips';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSelectModule } from '@angular/material/select';
import { MatNativeDateModule } from '@angular/material/core';
import { FileUploadComponent } from './file-upload/file-upload/file-upload.component';
import { SingleQuoteComponent } from './calculate-covers/single-quote/single-quote.component';
import { DoubleQuotesComponent } from './calculate-covers/double-quotes/double-quotes.component';
import { PrmiumViewComponent } from './calculate-covers/prmium-view/prmium-view.component';
import { CalculateCoverMoreUsersComponent } from './calculate-covers/calculate-cover-more-users/calculate-cover-more-users.component';
import { FilterQuotationComponent } from './filter-quotation/filter-quotation/filter-quotation.component';
import { CoverLetterComponent } from './filter-quotation/cover-letter/cover-letter.component';
import { ViewCoverLettersComponent } from './filter-quotation/view-cover-letters/view-cover-letters.component';
import { CoverLetterUsersComponent } from './filter-quotation/cover-letter-users/cover-letter-users.component';
import { InternalUsersComponent } from './user-module/internal-users/internal-users.component';
import { PartnerUserListComponent } from './user-module/partner-users/partner-user-list/partner-user-list.component';
import { AddUserComponent } from './user-module/partner-users/add-user/add-user.component';
import { EditUserComponent } from './user-module/partner-users/edit-user/edit-user.component';
import { DeleteUserComponent } from './user-module/partner-users/delete-user/delete-user.component';
import { ViewAllBanksComponent } from './bank-module/view-all-banks/view-all-banks.component';
import { AddBankComponent } from './bank-module/add-bank/add-bank.component';
import { EditBankComponent } from './bank-module/edit-bank/edit-bank.component';
import { DeleteBankComponent } from './bank-module/delete-bank/delete-bank.component';
import { AddBranchComponent } from './branch-module/add-branch/add-branch.component';
import { DeleteBranchComponent } from './branch-module/delete-branch/delete-branch.component';
import { EditBranchComponent } from './branch-module/edit-branch/edit-branch.component';
import { ViewAllBranchComponent } from './branch-module/view-all-branch/view-all-branch.component';
import { ViewSingleBranchComponent } from './branch-module/view-single-branch/view-single-branch.component';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { AdminDashboardComponent } from './dashboard/admin-dashboard/admin-dashboard.component';
import { UwbancaDashboardComponent } from './dashboard/uwbanca-dashboard/uwbanca-dashboard.component';
import { ValidationComponent } from './validation/validation.component';
import { ThousandSeparatorPipe } from './Thousand-Separator/thousand-separator.pipe';
import { DatePipe } from '@angular/common';
import { NicToBirthdayPipe } from './NictoBirthday/nic-to-birthday.pipe';
import { NumberFormatDirective } from './number-format/number-format.directive';
import {ClipboardModule} from '@angular/cdk/clipboard';
import { MatTableExporterModule } from 'mat-table-exporter';
import { QuotationReportComponent } from './reports/quotation-report/quotation-report.component'



@NgModule({
  declarations: [
    CalculateCoverSingleUserComponent,
    FileUploadComponent,
    SingleQuoteComponent,
    DoubleQuotesComponent,
    PrmiumViewComponent,
    CalculateCoverMoreUsersComponent,
    FilterQuotationComponent,
    CoverLetterComponent,
    ViewCoverLettersComponent,
    CoverLetterUsersComponent,
    InternalUsersComponent,
    PartnerUserListComponent,
    AddUserComponent,
    EditUserComponent,
    DeleteUserComponent,
    ViewAllBanksComponent,
    AddBankComponent,
    EditBankComponent,
    DeleteBankComponent,
    AddBranchComponent,
    DeleteBranchComponent,
    EditBranchComponent,
    ViewAllBranchComponent,
    ViewSingleBranchComponent,
    AdminDashboardComponent,
    UwbancaDashboardComponent,
    ValidationComponent,
    ThousandSeparatorPipe,
    NicToBirthdayPipe,
    NumberFormatDirective,
    QuotationReportComponent,
   
      
    
  ],
  imports: [
    CommonModule,
    AzppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatChipsModule,
    MatCheckboxModule,
    MatSelectModule,
    MatNativeDateModule,
    MatAutocompleteModule,
    ClipboardModule,
    MatTableExporterModule


    ],
    providers: [
        DatePipe,
        NicToBirthdayPipe
    ],
    exports: [
        NumberFormatDirective
    ]
})
export class AzppModule { }
