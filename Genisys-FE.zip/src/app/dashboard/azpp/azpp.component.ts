import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-azpp',
  templateUrl: './azpp.component.html',
  styleUrls: ['./azpp.component.scss']
})
export class AzppComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
