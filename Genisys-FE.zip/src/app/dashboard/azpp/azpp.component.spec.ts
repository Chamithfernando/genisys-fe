import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AzppComponent } from './azpp.component';

describe('AzppComponent', () => {
  let component: AzppComponent;
  let fixture: ComponentFixture<AzppComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
    declarations: [AzppComponent],
    teardown: { destroyAfterEach: false }
})
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AzppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
