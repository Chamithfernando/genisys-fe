import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AzppComponent } from './azpp.component';
import { ViewAllBanksComponent } from './bank-module/view-all-banks/view-all-banks.component';
import { ViewAllBranchComponent } from './branch-module/view-all-branch/view-all-branch.component';
import { ViewSingleBranchComponent } from './branch-module/view-single-branch/view-single-branch.component';
import { CalculateCoverMoreUsersComponent } from './calculate-covers/calculate-cover-more-users/calculate-cover-more-users.component';
import { CalculateCoverSingleUserComponent } from './calculate-covers/calculate-cover-single-user/calculate-cover-single-user.component';
import { FileUploadComponent } from './file-upload/file-upload/file-upload.component';
import { FilterQuotationComponent } from './filter-quotation/filter-quotation/filter-quotation.component';
import { InternalUsersComponent } from './user-module/internal-users/internal-users.component';
import { PartnerUserListComponent } from './user-module/partner-users/partner-user-list/partner-user-list.component';
import { AdminDashboardComponent } from './dashboard/admin-dashboard/admin-dashboard.component';
import { UwbancaDashboardComponent } from './dashboard/uwbanca-dashboard/uwbanca-dashboard.component';
import {QuotationReportComponent} from "@app/dashboard/azpp/reports/quotation-report/quotation-report.component";


const routes: Routes = [

  {
    path: '',
    component: AzppComponent,

    children: [
      {
        path: 'admin-dashboard',
        component: AdminDashboardComponent
      },
      {
        path: 'uwbanca-dashboard',
        component: UwbancaDashboardComponent
      },
      {
        path: 'cover-single-user',
        component: CalculateCoverSingleUserComponent,

      },
      {
        path: 'cover-more-users',
        component: CalculateCoverMoreUsersComponent
      },

      {
        path: 'file-upload',
        component: FileUploadComponent
      },
      {
        path: 'partner-user',
        component: PartnerUserListComponent
      },
      {
        path: 'internal-user',
        component: InternalUsersComponent
      },
      {
        path: 'bank-module',
        component: ViewAllBanksComponent
      },
      {
        path: 'branch-module',
        component: ViewAllBranchComponent
      },
      {
        path: 'view-single-branch/:bankname/:id',
        component: ViewSingleBranchComponent,
      },
      {
        path: 'filter-quotation',
        component: FilterQuotationComponent
      },
      {
        path: 'quotation-report',
        component: QuotationReportComponent
      },
    ]
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AzppRoutingModule { }
