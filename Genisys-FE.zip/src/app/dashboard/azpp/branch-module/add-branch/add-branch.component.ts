import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
// import Swal from 'sweetalert2';
import { AzppService } from '@app/shared/services/azpp/azpp.service';
import { AuthService } from '@app/shared/services/auth/auth.service';
import { validateKeyPress, validatePasteSpecialCharacters } from '../../validation/validation.component';
import { showErrorMessage, showSucessMessage } from '../../validation/validation.component';

export interface BankRecord {
  id: number;
  name: string;
}

@Component({
  selector: 'app-add-branch',
  templateUrl: './add-branch.component.html',
  styleUrls: ['./add-branch.component.scss']
})
export class AddBranchComponent implements OnInit {
  branch: UntypedFormGroup;
  bankRecordListObj: any;
  bankRecordList: BankRecord[] = [];
  bankName: string;

  constructor(public dialogRef: MatDialogRef<AddBranchComponent>,
    private formBuilder: UntypedFormBuilder,
    private azppService: AzppService,
    private authService: AuthService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    dialogRef.disableClose = true;

    this.branch = this.formBuilder.group({
      instituteId: new UntypedFormControl('', Validators.required),
      bankName: new UntypedFormControl(''),
      branchName: new UntypedFormControl('', [Validators.required, Validators.maxLength(25)]),
      address: new UntypedFormControl('', [Validators.required, Validators.maxLength(100), this.customValidator()]),
      phoneNo: new UntypedFormControl('', [Validators.required, Validators.maxLength(10), this.validateCustomerNumber, Validators.minLength(10)]),

    });

  }

  ngOnInit(): void {
    this.getAllBankRecords();

    //this.setValues(this.data)
    console.log('this.data', this.data)

    if (this.data && this.data.branchName) {
      this.bankName = this.data.branchName;
    } else {

      this.bankName = '';
    }

  }

  setValues(data: any) {
    console.log('branch data', data)
    this.branch.patchValue({
      instituteId: data,

    });
  }

  //Branch Name validate
  onKeyPress(event: KeyboardEvent) {
    validateKeyPress(event);
  }

  validatePasteSpecialCharacters(event: ClipboardEvent) {
    validatePasteSpecialCharacters(event);
  }

  //Address Name validate
  customValidator() {
    return (control: UntypedFormControl) => {
      const pattern = /^[a-zA-Z0-9\/,\r\n\s]*$/;
      return pattern.test(control.value) ? null : { invalidCharacters: true };
    };
  }

  onKeyPressAddress(event: KeyboardEvent) {
    const allowedCharacters = /[a-zA-Z0-9\/,\r\n\s]/;
    if (!allowedCharacters.test(event.key)) {
      event.preventDefault();
    }
  }

  validatePasteAddress(event: ClipboardEvent) {
    const clipboardData = event.clipboardData?.getData('text/plain');
    if (clipboardData) {
      const pattern = /^[a-zA-Z0-9\/,\r\n\s]*$/;
      if (!pattern.test(clipboardData)) {
        event.preventDefault();
      }
    }
  }

  // Mobile Number Validate
  onKeyDownNumber(event: KeyboardEvent) {
    const input = event.target as HTMLInputElement;
    const currentValue = input.value;
    const keyCode = event.keyCode || event.which;
    const selectionStart = input.selectionStart;
    const selectionEnd = input.selectionEnd;

    if (selectionStart === 0 && selectionEnd === currentValue.length && keyCode >= 48 && keyCode <= 57) {
      input.setSelectionRange(1, 1);
    }
    if (event.key === '.') {
      event.preventDefault();
    }
  }

  keyPressNumber(event: KeyboardEvent) {
    const allowedKeys = /^[0-9.]*$/;
    if (!event.key.match(allowedKeys)) {
      event.preventDefault();
    }
  }

  onPasteNumber(event: ClipboardEvent) {
    const clipboardData = event.clipboardData || window['clipboardData'];
    const pastedText = clipboardData.getData('text');
    const isValid = /^\d+$/.test(pastedText);
    if (!isValid) {
      event.preventDefault();
    }
  }

  validateCustomerNumber(control: UntypedFormControl) {
    const input = control.value;
    if (input && input.charAt(0) !== '0') {
      return { invalidFirstNumber: true };
    }
    return null;
  }

  getErrorText() {
    if (this.branch.controls.phoneNo.hasError('required')) {
      return 'Phone Number is required';
    }
    if (this.branch.controls.phoneNo.hasError('invalidFirstNumber')) {
      return 'First number must be 0';
    }
    if (this.branch.controls.phoneNo.hasError('minlength')) {
      return 'Phone Number must be 10 numbers';
    }
    if (this.branch.controls.phoneNo.hasError('invalidName')) {
      return 'Please enter a valid Phone Number.';
    }


    return '';
  }

  setInstituteIdIfMatch(selectedName: string) {
    const matchedRecord = this.bankRecordList.find(
      record => record.name === selectedName
    );
    if (matchedRecord) {
      this.branch.patchValue({
        instituteId: matchedRecord.id
      });
    }
  }

  // Get All Bank Records
  async getAllBankRecords() {
    this.bankRecordListObj = await this.getBankList().catch((error) => {
      console.log(error);
    });

    if (this.bankRecordListObj.status == 200) {
      this.bankRecordList = this.bankRecordListObj.payload;

    }
  }

  async getBankList() {
    return new Promise((resolve, reject) => {
      this.azppService
        .getBankRecordList(
          this.authService.getCurrentUserDetails().access_token
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


  validate() {

    const input = this.branch.controls.phoneNo;
    const phoneNo = this.branch.value.phoneNo;

    if (!this.data || !this.data.bankId) {
      if (!this.branch.value.instituteId) {
        showErrorMessage('Bank name is required');
        return false;
      }
    }

    if (!this.branch.value.branchName || !this.branch.value.branchName.toString().trim()) {
      showErrorMessage('Branch name is required');
      return false;
    }
    if (!this.branch.value.address || !this.branch.value.address.toString().trim()) {
      showErrorMessage('Address is required');
      return false;
    }
    if (!this.branch.value.phoneNo || !this.branch.value.phoneNo.toString().trim()) {
      showErrorMessage('Phone Number is required');
      return false;
    }

    if (input && typeof input.value === 'string' && input.value.charAt(0) !== '0') {
      showErrorMessage('Please enter a valid Phone Number');
      return false;
    }
    if (!phoneNo || !/^\d{10}$/.test(phoneNo)) {
      showErrorMessage('Phone Number must be 10 digits long');
      return false;
    }

    return true;
  }


  //Add branch
  async saveBranchRecords() {
    if (this.validate()) {

      const data = {
        instituteId: this.data && this.data.bankId ? this.data.bankId : (this.branch && this.branch.value ? this.branch.value.instituteId : null),
        branchName: this.branch.value.branchName,
        address: this.branch.value.address,
        phoneNo: this.branch.value.phoneNo
      };
      const saveBankResponse: any = await this.saveRecord(data).catch(
        (err) => {
          console.log(err);
        }
      );

      console.log('saveBankResponse', saveBankResponse)
      if (saveBankResponse.status === 201) {
        showSucessMessage(saveBankResponse.message);
        this.dialogRef.close(true);
      } else {
        if (saveBankResponse.payload && saveBankResponse.payload.length > 0) {
          for (const error of saveBankResponse.payload) {
            showErrorMessage(`${error.error}`);
          }
        } else {
          showErrorMessage(saveBankResponse.message);
        }
      }
    }
  }


  saveRecord(data: any) {
    return new Promise((resolve, reject) => {
      this.azppService
        .addBranch(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
