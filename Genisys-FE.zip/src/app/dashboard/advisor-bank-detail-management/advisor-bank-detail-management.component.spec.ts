import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvisorBankDetailManagementComponent } from './advisor-bank-detail-management.component';

describe('AdvisorBankDetailManagementComponent', () => {
  let component: AdvisorBankDetailManagementComponent;
  let fixture: ComponentFixture<AdvisorBankDetailManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvisorBankDetailManagementComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdvisorBankDetailManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
