import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvisorBankDetailHistoryComponent } from './advisor-bank-detail-history.component';

describe('AdvisorBankDetailHistoryComponent', () => {
  let component: AdvisorBankDetailHistoryComponent;
  let fixture: ComponentFixture<AdvisorBankDetailHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvisorBankDetailHistoryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdvisorBankDetailHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
