import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ApiReportService } from '@app/shared/services/api-report/api-report.service';
import { AuthService } from '@app/shared/services/auth/auth.service';
import { PopupService } from '@app/shared/services/popup/popup.service';
import { data } from 'jquery';

export interface agentBankData {
  agentCode: string;
  bankNameWithCode: string;
  branchNameWithCode: string
  id: number
}

@Component({
  selector: 'app-advisor-bank-detail-history',
  templateUrl: './advisor-bank-detail-history.component.html',
  styleUrls: ['./advisor-bank-detail-history.component.scss']
})
export class AdvisorBankDetailHistoryComponent implements OnInit {

  // dialogRef: MatDialogRef<any>;
  dataSource = new MatTableDataSource([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('busTbSort') busTbSort = new MatSort();

  
  bankHistoryData: any[] = [];  // Store fetched bank history data

  displayedColumns = ['agentCode', 'accountNumber', 'bank', 'branch', 'uploadedDate', 'modifyUser', 'remark'];


  limit: number = 10;
  offset: number = 0;
  count: any;
  length = 100;
  pageSize = 10;
  pageSizeOptions: number[] = [10, 50, 100, 200];
  pageEvent: PageEvent;
  token: any;
  getAllAgentBankDetail: any;
  agentCode: string;



  constructor(
    @Inject(MAT_DIALOG_DATA) public paylod,
    public dialog: MatDialog,
    private popupservice: PopupService,
    private _snackBar: MatSnackBar,
    private apiReport: ApiReportService,
    private authService: AuthService,
    public dialogRef: MatDialogRef<AdvisorBankDetailHistoryComponent>  

  ) {

    this.token = this.authService.getCurrentUserDetails().access_token;
    console.log(this.token);

    const bankDetails: any = this.paylod.detaili;
    console.log(bankDetails);       //get parent table data set 
    console.log(bankDetails.agentCode);

    this.agentCode = bankDetails.agentCode;
    console.log(this.agentCode);
    this.getAllBankHistory();

  }
  ngOnInit(): void {

  }

  closeDialogBoxWindow() {
    this.dialogRef.close(true);
  }

  async getAllBankHistory() {
    let agentCode;

    console.log(agentCode);

    const data = { token: this.token, agentCode: this.agentCode };
    console.log(data);

    const bankHistoryDataResponce: any = await this.getBankHistory(data).catch((error) => {
      console.error("Error fetching branch list:", error);
      return null;
    });
    console.log("Branch List Data:", bankHistoryDataResponce);   //Get ankHistoryData from BE
    
    if (bankHistoryDataResponce && bankHistoryDataResponce.payload) {   
      this.dataSource.data = bankHistoryDataResponce.payload; 
      this.dataSource.paginator = this.paginator;
     
     
    } else {
      console.log("No bank history data found.");
    }

  }


  getBankHistory(data: any) {
    return new Promise((resolve, reject) => {
      this.apiReport.getBankHistory(data).subscribe(data => {
        resolve(data);
      }, error => {
        reject(error);
      })
    })
  }


  onPageChange(event: any) {
    this.pageSize = event.pageSize;
    this.paginator.pageIndex = event.pageIndex;
  
  }
}

