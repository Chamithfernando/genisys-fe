import { AfterViewInit, Component, Inject, OnInit } from '@angular/core';
import { FormControl, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ApiReportService } from '@app/shared/services/api-report/api-report.service';
import { AuthService } from '@app/shared/services/auth/auth.service';
import { ProductManagementService } from '@app/shared/services/product-management/product-management.service';
import { data } from 'jquery';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import Swal from 'sweetalert2';
import { combineLatest } from 'rxjs';
import { log } from 'console';



// filteredOptionsBank
export interface bankData {
  id: number;
  name: string;
  code: string;
  status: boolean;
  branchList: any
}

export interface branchData {
  id: number;
  name: string;
  address: string;
  status: boolean;
  code: number
}


@Component({
  selector: 'app-advisor-change-bank-detail',
  templateUrl: './advisor-change-bank-detail.component.html',
  styleUrls: ['./advisor-change-bank-detail.component.scss']
})
export class AdvisorChangeBankDetailComponent implements OnInit {


  bankData: any;
  bankDetailManagementForm: UntypedFormGroup;
  token: any
  bankId: number;
  viewValidationMessage: boolean = false;
  modifyUser: any;

  bankDataList: bankData[] = [];
  branchDataList: branchData[] = [];

  filteredOptionsBank: Observable<String[]>;
  filteredOptionsBranch: Observable<string[]>;

  bankNames: string[] = this.bankDataList.map(bank => bank.name);
  branchName: string[] = this.branchDataList.map(branch => branch.name)

  constructor(
    @Inject(MAT_DIALOG_DATA) public paylod,
    private bankDetailManagementFormBuilder: UntypedFormBuilder,
    private authService: AuthService,
    private _snackBar: MatSnackBar,
    private apiReport: ApiReportService,
    private productService: ProductManagementService,
    public dialogRef: MatDialogRef<AdvisorChangeBankDetailComponent>,
  ) {
    this.token = this.authService.getCurrentUserDetails().access_token;
    const tableBankdata: any = this.paylod.detaili;
    switch (this.paylod.action) {
      case 'edit':
        this.bankData = tableBankdata;
        this.updateBankDetailsForm(tableBankdata);
        this.initialBankDetailsValidation(tableBankdata);
        this.getAllBankNameListAgent(tableBankdata);
        
       
       
        break;
    }
  }
  

  // Only for 2 banks Branch remove
  initialBankDetailsValidation(data:any){
    // setTimeout(() => {
      this.getAllBranchNameListAgent(data.bankNameWithCode);
    // }, 500);
  }

  ngOnInit(): void {

    // Filtered bank 
    this.filteredOptionsBank = this.bankDetailManagementForm.get("bankNameWithCode").valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value || '')),
    );

    // Filtered branch 
    this.filteredOptionsBranch = this.bankDetailManagementForm.get("branchNameWithCode").valueChanges.pipe(
      startWith(''),
      map(value => this._filterBranch(value || '')),
    );

    this.bankDetailManagementForm.get("bankNameWithCode").valueChanges.subscribe(value => {
        this.bankDetailManagementForm.get("accountNumber").reset();
        this.bankDetailManagementForm.get("branchNameWithCode").reset();
    });

  }

  
  

  onBranchChange(event: any): void {
    if (event.isUserInput) {  
      this.bankDetailManagementForm.get("accountNumber").reset(); 
    }
  }
  
  onBranchInputChange(): void {
    this.bankDetailManagementForm.get("accountNumber").reset();
  }
  
  

  async setBranchList(record: any,bankDataList: any) {
    const bank = record.bankNameWithCode;
    let bankCode;
    if (typeof bank === "string" && bank.includes(" - ")) {
      bankCode = bank.split(" - ").pop()?.trim();
    } else {
      this.bankDetailManagementForm.get('bankNameWithCode').reset();
      this.bankDetailManagementForm.get('branchNameWithCode').reset();
      this.bankDetailManagementForm.get('accountNumber').reset();
      console.error("Invalid bank format or type:", bank);
      return;
    }

    const selectedBank: bankData[] = bankDataList.filter(bank => bank.code === bankCode);
    if (selectedBank.length === 0) {
      console.error("No matching bank found for code:", bankCode);
      return;
    }
    const data = { token: this.token, id: selectedBank[0].id };
    const branchList: any = await this.getBranchNameList(data).catch((error) => {
      return null;
    });

    if (!branchList || !Array.isArray(branchList.payload) || branchList.payload.length === 0) {
      console.warn("No branches found for the selected bank.");
      this.branchDataList = [];
      this.filteredOptionsBranch = null;

      this.bankDetailManagementForm.get('branchNameWithCode').disable();
      this.bankDetailManagementForm.get('branchNameWithCode').reset();
      return;
    }

    this.branchDataList = branchList.payload;

    // Update the filteredOptionsBranch observable for dropdown
    this.filteredOptionsBranch = this.bankDetailManagementForm
      .get("branchNameWithCode")
      .valueChanges.pipe(
        startWith(''),
        map(value => this._filterBranch(value || ''))
      );


      this.validateAvilableBankAndBranch(record.bankNameWithCode, record.branchNameWithCode,bankDataList, branchList.payload); 
  }

  // Fitered bank and get code
  private _filter(value: string): string[] {

    const filterValue = value.toLowerCase()
    const filteredBanks = this.bankDataList
      .filter(bank =>
        (bank.name && bank.name.toLowerCase().includes(filterValue)) ||
        (bank.code && bank.code.toLowerCase().includes(filterValue))
      );


    return filteredBanks
      .map(bank => `${bank.name} - ${bank.code}`);  //Combine Bank & code
  }

  // Fitered branch and 
  private _filterBranch(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.branchDataList
      .filter(branch => branch.name.toLowerCase().includes(filterValue))
      .map(branch => `${branch.name} - ${branch.code}`);
  }


  updateBankDetailsForm(data: any) {

    this.bankDetailManagementForm = this.bankDetailManagementFormBuilder.group({
      id: data.id,
      agentCode: new UntypedFormControl(data.agentCode, Validators.required),
      remark: new UntypedFormControl(data.remark, [Validators.maxLength(150)]),
      accountNumber: new UntypedFormControl(data.accountNumber, [
        Validators.required,
        Validators.pattern("^[0-9]*$") // Only numbers allowed
      ]),
      bankNameWithCode: new UntypedFormControl(data.bankNameWithCode, Validators.required),
      branchNameWithCode: new UntypedFormControl(
        { value: data.branchNameWithCode, disabled: false }, // Initially enabled
        Validators.required
      ),
      
    });


    this.bankDetailManagementForm.get('accountNumber')?.valueChanges.subscribe(value => {
      if (value && !/^[0-9]*$/.test(value)) {
        this.bankDetailManagementForm.get('accountNumber')?.setValue(value.replace(/[^0-9]/g, ''), { emitEvent: false });
      }
    });
  }



  validateAccountNumber(event: KeyboardEvent) {
    const charCode = event.key;
    const regex = /^[0-9-]$/;
    if (!regex.test(charCode)) {
      event.preventDefault(); //Prevent invalid character input
    }
  }



  closeDialogBoxWindow() {
    this.dialogRef.close(true);   //close the dialog box
  }

  resetData() {
    this.viewValidationMessage = false;
    this.bankDetailManagementForm.reset();
  }

  timeoutAlert() {
    setTimeout(() => {
      this.viewValidationMessage = false
    }, 2000);
  }


  // get bank name list from BE to view in the dropdown  
  async getAllBankNameListAgent(bankData: any) {
    const data = { token: this.token };

    const bankNameListObj: any = await this.getBankNameList(data).catch((error) => {
      console.error("Error fetching bank list:", error);
    });

    if (bankNameListObj && bankNameListObj.status === 202 && bankNameListObj.payload) {
      this.bankDataList = bankNameListObj.payload;

      this.filteredOptionsBank = this.bankDetailManagementForm
        .get("bankNameWithCode")
        .valueChanges.pipe(
          startWith(''),
          map(value => this._filter(value || ''))
        );

        this.setBranchList(bankData,this.bankDataList);

    } else {
      console.warn("No bank data received");
    }

  }

  // DataBinding1
  async getBankNameList(data: any) {
    return new Promise((resolve, reject) => {
      this.apiReport.getBankName(data).subscribe(data => {
        resolve(data);
      }, error => {
        reject(error);
      })
    })
  }


async getAllBranchNameListAgent(bank: any) {

  
  let bankCode;

  if (typeof bank === "string" && bank.includes(" - ")) {
    bankCode = bank.split(" - ").pop()?.trim();
  } else {
    this.bankDetailManagementForm.get('bankNameWithCode').reset();
    this.bankDetailManagementForm.get('branchNameWithCode').reset();
    this.bankDetailManagementForm.get('accountNumber').reset();
    console.error("Invalid bank format or type:", bank);
    return;
  }

  const selectedBank: bankData[] = this.bankDataList.filter(bank => bank.code === bankCode);
  if (selectedBank.length === 0) {
    console.error("No matching bank found for code:", bankCode);
    return;
  }

  const data = { token: this.token, id: selectedBank[0].id };

  const branchList: any = await this.getBranchNameList(data).catch((error) => {
    console.error("Error fetching branch list:", error);
    return null;
  });

  if (!branchList || !Array.isArray(branchList.payload) || branchList.payload.length === 0) {
    console.warn("No branches found for the selected bank.");
    this.branchDataList = [];
    this.filteredOptionsBranch = null;

    // Disable the Branch Name with Code field if no branches exist
    this.bankDetailManagementForm.get('branchNameWithCode').disable();
    this.bankDetailManagementForm.get('branchNameWithCode').reset();
    return;
  }


  this.branchDataList = branchList.payload;


  
  // Enable the Branch Name with Code field if branches exist
  this.bankDetailManagementForm.get('branchNameWithCode').enable();

  this.filteredOptionsBranch = this.bankDetailManagementForm
    .get("branchNameWithCode")
    .valueChanges.pipe(
      startWith(''),
      map(value => this._filterBranch(value || ''))
    );
}


  // DataBinding2
  getBranchNameList(data: any) {
    return new Promise((resolve, reject) => {
      this.apiReport.getBranchName(data).subscribe(data => {
        resolve(data);
      }, error => {
        reject(error);
      })
    })
  }

  

  validateCheck(): boolean {
    const bankNameWithCode = this.bankDetailManagementForm.value.bankNameWithCode;
    const branchNameWithCode = this.bankDetailManagementForm.value.branchNameWithCode;
  
    let isValidBank = false;
    let isValidBranch = false;
  
    // Validate bank using filteredOptionsBank
    if (
      this.filteredOptionsBank &&
      this.filteredOptionsBank instanceof Observable
    ) {
      this.filteredOptionsBank.subscribe((bankList) => {

        
        if (bankList.some((bank) => bank === bankNameWithCode)) {
          isValidBank = true;
        }
      });
    }
  
  
  
    // Validate branch using filteredOptionsBranch
    if (
      this.filteredOptionsBranch &&
      this.filteredOptionsBranch instanceof Observable
    ) {
      this.filteredOptionsBranch.subscribe((branchList) => {
        if (branchList.some((branch) => branch === branchNameWithCode)) {
          isValidBranch = true;
        }
      });
    }
  

    if (!isValidBank || !isValidBranch) {
      let errorMessage = !isValidBank
        ? 'Invalid Bank Name or Code'
        : 'Invalid Branch Name or Code / No Branch Selected !';
      this._snackBar.open(errorMessage, 'Close', {
        duration: 3000,
        panelClass: ['mat-snackbar-error'],
      });

      if (this.filteredOptionsBranch == null && !isValidBranch) {
        return true;
      }
      return false;

    }
  
    return true;
  }


  validateAvilableBankAndBranch(bankName: string, branchName: string,bankList:any,branchList: any): void {
      let isValidBank = false;
      let isValidBranch = false;
          isValidBank = bankList.some((bank) => `${bank.name} - ${bank.code}` === bankName); 
          isValidBranch = branchList.some((branch) => `${branch.name} - ${branch.code}` === branchName);
      if (!isValidBranch || !isValidBank) {
        this.bankDetailManagementForm.get('bankNameWithCode').reset();
        this.bankDetailManagementForm.get('branchNameWithCode').reset();
      }
  }

  //ADD NEW
async updateNewBankDetails() {
  // Reset the validation message before each update attempt
  this.viewValidationMessage = false;
  
  
  // Validate the form before proceeding
  if (this.bankDetailManagementForm.invalid) {
    // Show the validation message only after clicking the update button
    this.viewValidationMessage = true;
    return;
  }

  if (!this.validateCheck()) {
    return;
  }
  
    // Proceed to submit the data if validation passes
    const data = {
      id: this.bankDetailManagementForm.value.id,
      agentCode: this.bankDetailManagementForm.value.agentCode,
      accountNumber: this.bankDetailManagementForm.value.accountNumber,
      bankNameWithCode: this.bankDetailManagementForm.value.bankNameWithCode,
      branchNameWithCode: this.bankDetailManagementForm.value.branchNameWithCode,
      remark: this.bankDetailManagementForm.value.remark,
    };
  
   

    Swal.fire({
      title: "Are you sure?",
      text: "Do you want to update?",
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, Update!"
    }).then(async (result) => {
      if (result.isConfirmed) {
        const updateBankListResponce: any = await this.updateBankDetail(data, this.token).catch((error) => {
          console.error("Error fetching bank list:", error);
        });

        

        if (updateBankListResponce.status) {
          Swal.fire({
            title: "Updated!",
            text: "Your data has been Updated.",
            icon: "success"
          });

          this.dialogRef.close(true);
        } else {
          Swal.fire({
            title: "Warning!",
            text: updateBankListResponce.messages,
            icon: "warning"
          });
        }
      }
    });
  
}

 //ADD NEW

  async updateBankDetail(data: any, token: any) {
    return new Promise((resolve, reject) => {
      this.apiReport.updateBankDetail(data, token).subscribe(data => {
        resolve(data);
      }, error => {
        reject(error);
      })
    })
  }
}


