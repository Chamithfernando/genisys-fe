import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvisorChangeBankDetailComponent } from './advisor-change-bank-detail.component';

describe('AdvisorChangeBankDetailComponent', () => {
  let component: AdvisorChangeBankDetailComponent;
  let fixture: ComponentFixture<AdvisorChangeBankDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvisorChangeBankDetailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdvisorChangeBankDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
