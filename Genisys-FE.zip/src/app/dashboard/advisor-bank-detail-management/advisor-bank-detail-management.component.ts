import { Component, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ApiReportService } from '@app/shared/services/api-report/api-report.service';
import { AuthService } from '@app/shared/services/auth/auth.service';
import { PopupService } from '@app/shared/services/popup/popup.service';
import * as fileSaver from 'file-saver';
import { AppointedDoctorManagementComponent } from '../techinical/appointed-doctors/appointed-doctor-management/appointed-doctor-management.component';
import { AdvisorChangeBankDetailComponent } from './advisor-change-bank-detail/advisor-change-bank-detail.component';
import { AdvisorBankDetailHistoryComponent } from './advisor-bank-detail-history/advisor-bank-detail-history.component';

export interface agentBankData {
  agentCode: string;
  bankNameWithCode: string;
  branchNameWithCode: string
  id: number
}

@Component({
  selector: 'app-advisor-bank-detail-management',
  templateUrl: './advisor-bank-detail-management.component.html',
  styleUrls: ['./advisor-bank-detail-management.component.scss']
})
export class AdvisorBankDetailManagementComponent {

  token: any;
  dataSource = new MatTableDataSource([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('busTbSort') busTbSort = new MatSort();

   dialogRef: MatDialogRef<any>;

  displayedColumns = ['agentCode','accountNumber','bank', 'branch','uploadedDate', 'modifyUser','remark','action'];
  limit: number = 10;
  offset: number = 0;
  count: any;
  length = 100;
  pageSize = 10;
  pageSizeOptions: number[] = [10, 50, 100, 200];
  pageEvent: PageEvent;
 
  searchAgentCode: string = '';

  constructor(public dialog: MatDialog,
    private popupservice: PopupService,
    private _snackBar: MatSnackBar,
    private apiReport: ApiReportService,
    private auth: AuthService) {

      this.token = this.auth.getCurrentUserDetails().access_token;
      this.getAllAgentBankDetail();
    }


  async getAllAgentBankDetail() {
    const request = {
      token: this.token,
      limit: this.limit,
      offset: this.offset,
    }
    const agentBankDataResponse: any = await  this.getAgentBankDetail(request).catch((error) => {
      console.log(error);
    });

    
    if (agentBankDataResponse.status == true) {
      this.dataSource = new MatTableDataSource<agentBankData>(agentBankDataResponse.payload.object);
      this.count = agentBankDataResponse.payload.count;
      this.length = this.count;
    }
  }

  data($event) {
    this.length = this.count;
    this.limit = $event.pageSize;
    this.offset = $event.pageIndex;
    this.getAllAgentBankDetail();
    return $event;
  }

  async searchAgentData(){
    const payload = {
      token: this.token,
      agentCode: this.searchAgentCode
    }
    const searchAgentBankDataResponse: any = await  this.searchAgentBankDetail(payload).catch((error) => {
      console.log(error);
    });
    
    if (searchAgentBankDataResponse.status == true) {
      this.dataSource = new MatTableDataSource<agentBankData>(searchAgentBankDataResponse.payload.object);
      this.count = searchAgentBankDataResponse.payload.count;
      this.length = this.count;
    }


  }

  

  async downlaodAgentData(){
    const agentBankDataResponse: any = await  this.getAgentBankDetailDownlaod().catch((error) => {
      console.log(error);
    })
    this.saveFile(agentBankDataResponse);
  }

  saveFile(data: any) {
    const blob = new Blob([data], { type: 'application/vnd.ms-excel' });
    fileSaver.saveAs(blob, 'agent-bank-detail-report.xlsx');
  }

  async getAgentBankDetail(data: any) {
    return new Promise((resolve, reject) => {
      this.apiReport.getAllAdvisorBankDetailList(data).subscribe(data => {
        resolve(data);
      }, error => {
        reject(error);
      })
    })
  }

  async getAgentBankDetailDownlaod() {
    return new Promise((resolve, reject) => {
      this.apiReport.agentBankDetailDownlaod(this.token).subscribe(data => {
        resolve(data);
      }, error => {
        reject(error);
      })
    })
  }

  async searchAgentBankDetail(data: any) {
    return new Promise((resolve, reject) => {
      this.apiReport.searchAdvisorBankDetail(data).subscribe(data => {
        resolve(data);
      }, error => {
        reject(error);
      })
    })
  }


  // Editbtn -Edit bank Details popup 
  editBankDetail(element){
      this.dialogRef = this.dialog.open(AdvisorChangeBankDetailComponent, {   //open the edit popup component 
          width: '600px',
          disableClose: true,
          data:{
            detaili: element,
            action: 'edit'
          }
          
        });
      
        this.dialogRef.afterClosed().subscribe((response) => {
          if (response) {
            this.getAllAgentBankDetail(); // Refresh table data after dialog closes
          }
        });
      }

      viewBankkHistory(element){
        this.dialogRef = this.dialog.open(AdvisorBankDetailHistoryComponent, {   //open the bankHistory popup component 
          width: '1500px',
          disableClose: true,
          data:{
            detaili: element,
            action: 'edit'
          }
          
        });
      
        this.dialogRef.afterClosed().subscribe((response) => {

          if (response) {
            // this.getAllAgentBankDetail(); // Refresh table data after dialog closes
            
          }
        });
      }
      
  }
  