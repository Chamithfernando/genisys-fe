import {Component} from '@angular/core';
import Swal from 'sweetalert2';
import {MatTableDataSource} from '@angular/material/table';
import {DecimalPipe} from '@angular/common';

export interface Selector {
  value: string;
  viewValue: string;
}

export interface PolicyType {
  value: boolean;
  viewValue: string;
}

@Component({
  selector: 'app-common-utilities',
  template: `
    <p>
      common-utilities works!
    </p>
  `,
  providers: [DecimalPipe]
})
export class CommonUtilitiesComponent {
}

export const SELECTOR_OPTIONS: Selector[] = [
  {value: 'true', viewValue: 'Yes'},
  {value: 'false', viewValue: 'No'},
];

export const IMS_REMARK_OPTIONS: Selector[] = [
  {value: 'yes', viewValue: 'Yes'},
  {value: 'no', viewValue: 'No'},
];

export const TYPE_OF_POLICY: PolicyType[] = [
  {value: true, viewValue: 'Received Request'},
  {value: false, viewValue: 'Sent Request'},
];

export const TYPE_OF_BRANCH: PolicyType[] = [
  {value: true, viewValue: 'Received Request'},
  {value: false, viewValue: 'Sent Request'},
];

export const NOT_APPROVE_REASON: Selector[] = [
  {value: 'Wrong Designation entered', viewValue: 'Wrong Designation entered'},
  {value: 'Designation Not approved', viewValue: 'Designation Not approved'},
  {value: 'Other Details Not entered', viewValue: 'Other Details Not entered'},
  {value: 'Performance Not enough', viewValue: 'Performance Not enough'},
];

export const CODE_TRANSFER_NOT_APPROVE_REASON: Selector[] = [
  {value: 'Invalid & Wrong details entered', viewValue: 'Invalid & Wrong details entered'},
  {value: 'Not Mention in personal File or Email', viewValue: 'Not Mention in personal File or Email'},
];

export const TERMINATION_REASON: Selector[] = [
  {value: '3 Month Non Performance', viewValue: '3 Month Non Performance'},
  {value: '6 Month Non Performance', viewValue: '6 Month Non Performance'},
  {value: 'Informed by Zonal Manager', viewValue: 'Informed by Zonal Manager'},
  {value: 'Instructions given By Top Management ', viewValue: 'Instructions given By Top Management '},
  {value: 'Joined Competitor ', viewValue: 'Joined Competitor '},
];

export const POLICY_TRANSFER_NOT_APPROVE_REASON: Selector[] = [
  {value: 'Wrong Details Entered  ', viewValue: 'Wrong Details Entered'},
  {value: 'Wrong Policy number', viewValue: 'Wrong Policy number'},
];

export const BRANCH_TRANSFER_NOT_APPROVE_REASON: Selector[] = [
  {value: 'Invalid & Wrong details entered', viewValue: 'Invalid & Wrong details entered'},
];

export const INCOME_SERVICE_REASON: Selector[] = [
  {value: 'Invalid & Wrong details entered', viewValue: 'Invalid & Wrong details entered'},
];
export const COMMON_TITLES: Selector[] = [
  {value: 'Mr', viewValue: 'Mr'},
  {value: 'Mrs', viewValue: 'Mrs'},
  {value: 'Miss', viewValue: 'Miss'},
];

export const LETTER_TYPES: Selector[] = [
  {value: 'INCOME_LETTER', viewValue: 'Income Statement'},
  {value: 'SERVICE_ACTIVE_CODE_LETTER', viewValue: 'Service (Active)'},
  {value: 'SERVICE_TERMINATED_CODE_LETTER', viewValue: 'Service (Terminated)'},
];


export function showErrorMessage(message: string) {
  Swal.fire({
    icon: 'error',
    width: '400px',
    title: message,
    customClass: {
      confirmButton: 'btn-ok',
    }
  });
}

export function showSucessMessage(message: string) {
  Swal.fire({
    icon: 'success',
    title: message,
    customClass: {
      confirmButton: 'btn-ok',
    }
  });
}

export function showWarningMessage(message: string) {
  Swal.fire({
    icon: 'warning',
    title: message,
    customClass: {
      confirmButton: 'btn-ok',
    }
  });
}


export function applyFilter(dataSource: MatTableDataSource<any>, event: Event) {
  const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();
  if (filterValue.length <= 100) {
    dataSource.filter = filterValue;
  } else {
    Swal.fire({
      icon: 'error',
      title: 'Filter value cannot exceed 100 characters',
      timer: 4000,
      showConfirmButton: true,
      customClass: {
        confirmButton: 'btn-ok',
      }
    }).then(() => {
      (event.target as HTMLInputElement).value = '';
      dataSource.filter = '';
    });
  }
}

export function formatNumber(value: number, decimalPipe: DecimalPipe): string {
  return decimalPipe.transform(value, '1.2-2');
}
