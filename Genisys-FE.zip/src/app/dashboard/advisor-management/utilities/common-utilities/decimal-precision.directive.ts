import {Directive, ElementRef, HostListener} from '@angular/core';

@Directive({
  selector: '[appDecimalPrecision]'
})
export class DecimalPrecisionDirective {
  constructor(private el: ElementRef) {
  }

  // Listen for 'input' event to format the input value
  @HostListener('input', ['$event'])
  onInput(event: Event) {
    const input = this.el.nativeElement as HTMLInputElement;
    let value = input.value;
    value = value.replace(/[^\d.]/g, '');
    const parts = value.split('.');


    if (parts.length > 1) {
      parts[1] = parts[1].slice(0, 2);
      value = parts[0] + '.' + parts[1];
    }


    if (value.includes('.')) {
      const [beforeDecimal, afterDecimal] = value.split('.');
      const formattedInteger = beforeDecimal.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
      value = formattedInteger + '.' + afterDecimal;
    } else {

      value = value.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    }


    input.value = value;
  }


  @HostListener('keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    const input = this.el.nativeElement as HTMLInputElement;
    const value = input.value;


    if (event.key === '.' && value.includes('.')) {
      event.preventDefault();
      return;
    }


    if (value.includes('.') && value.split('.')[1].length >= 2) {

      if (event.key !== 'Backspace' && !this.isNumeric(event.key)) {
        event.preventDefault();
      }
    }
  }

  private isNumeric(key: string): boolean {
    return /\d/.test(key);
  }
}
