import {Component} from '@angular/core';

@Component({
  selector: 'app-validation',
  template: `
    <p>
      validation works!
    </p>
  `,
})
export class ValidationComponent {
}

// Validate Enter Special characters
export function validateEnterSpecialCharacters(event: Event): void {
  const inputElement = event.target as HTMLInputElement;
  const inputValue = inputElement.value;

  const pattern = /^[a-zA-Z0-9\s/,]*$/;

  if (!pattern.test(inputValue)) {

    const sanitizedValue = inputValue.replace(/[^a-zA-Z0-9\s/,]/g, '');
    inputElement.value = sanitizedValue;
  }
}

// Address Validate
export function addressValidate(event: Event): void {
  const inputElement = event.target as HTMLInputElement;
  const inputValue = inputElement.value;

  const pattern = /^[a-zA-Z0-9\s/,]*$/;

  if (!pattern.test(inputValue)) {

    const sanitizedValue = inputValue.replace(/[^a-zA-Z0-9\s/,]/g, '');
    inputElement.value = sanitizedValue;
  }
}

// Validate Only Letters
export function allowLettersOnly(event: Event): void {
  const inputElement = event.target as HTMLInputElement;
  const inputValue = inputElement.value;

  const pattern = /^[a-zA-Z\s]*$/;

  if (!pattern.test(inputValue)) {

    const sanitizedValue = inputValue.replace(/[^a-zA-Z\s]/g, '');
    inputElement.value = sanitizedValue;
  }
}


