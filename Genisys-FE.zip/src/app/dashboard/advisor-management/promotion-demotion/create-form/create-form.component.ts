import {Component, OnInit, ViewChild, ElementRef} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {
  SELECTOR_OPTIONS,
  Selector,
  showErrorMessage, showWarningMessage, showSucessMessage
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {allowLettersOnly} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {formatDate} from '@angular/common';
import {Router} from '@angular/router';

@Component({
  selector: 'app-create-form',
  templateUrl: './create-form.component.html',
  styleUrls: ['./create-form.component.scss']
})
export class CreateFormComponent implements OnInit {

  createForm: FormGroup;
  selector: Selector[];
  currentDesignation: string;
  proposedDesignation: string;
  currentDate: Date = new Date();
  moment = require('moment');
  token: any;
  branchArray: any = [];
  fileToUpload: File;
  businessPlanFileUrl: string;
  businessPlanFileType: string;
  selectedFileName: string;
  designationArray: any = [];
  agentsArray: any = [];
  branchId: string;
  selectedAgent: any;
  proposedDesignationDetails: any;
  proposedDesignationName: string;
  dateOfAppointment: string;
  isDisabled = false;

  @ViewChild('fileInput') fileInput: ElementRef<HTMLInputElement>;

  constructor(private formBuilder: FormBuilder,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              private router: Router) {

    this.createForm = this.formBuilder.group({
      designationType: new FormControl('', [Validators.required]),
      agentCode: new FormControl( '', [Validators.required]),
      branch: new FormControl('', [Validators.required]),
      agentName: new FormControl('', [Validators.required]),
      currentDesignationId: new FormControl(''),
      currentDesignation: new FormControl('', [Validators.required]),
      dateAppointment: new FormControl('', [Validators.required]),
      proposedDesignation: new FormControl('', [Validators.required, this.validateDesignation.bind(this)]),
      effectiveDate: new FormControl('', [Validators.required]),
      reportingManagerName: new FormControl('', [Validators.required]),
      managerCode: new FormControl('', [Validators.required]),
      fromEvaluationDate: new FormControl(''),
      toEvaluationDate: new FormControl(''),
      businessAchievement: new FormControl(''),
      businessPlan: new FormControl('', [Validators.required]),
      complianceIssues: new FormControl('', [Validators.required]),
      complianceIssueReason: new FormControl('')
    });

    this.selector = SELECTOR_OPTIONS;
  }

  async ngOnInit(): Promise<void> {
    try {
      await Promise.all([this.allBranches(), this.allDesignations()]);
    } catch (error) {
      console.error(error);
    }

    this.branchId = localStorage.getItem('branchId');

    if (this.branchId) {
      this.createForm.get('branch').setValue(this.branchId);
      this.allAgentsbyBranch();
    }
  }

  validate() {
    const appointmentDate = this.moment(this.createForm.value.dateAppointment, 'DD/MM/YYYY');
    const effectiveDate = this.moment(this.createForm.value.effectiveDate);

    const fromDate = this.moment(this.createForm.value.fromEvaluationDate);
    const toDate = this.moment(this.createForm.value.toEvaluationDate);


    const validationRules = [
      {field: 'designationType', message: 'Re Designation Type is Required'},
      {field: 'agentCode', message: 'Agent Code is Required'},
      {field: 'branch', message: 'Branch is Required'},
      {field: 'agentName', message: 'Agent Name is Required'},
      {field: 'currentDesignation', message: 'Current Designation is Required'},
      {field: 'dateAppointment', message: 'Date of Appointment is Required'},
      {field: 'proposedDesignation', message: 'Proposed Designation is Required'},
      {field: 'effectiveDate', message: 'Effective Date is Required'},
      {field: 'reportingManagerName', message: 'Reporting Manger is Required'},
      {field: 'managerCode', message: 'Manger Code is Required'},
      {field: 'businessPlan', message: 'Business Plan is Required'},
      {field: 'complianceIssues', message: 'Compliance Issue is Required'},
    ];

    for (const rule of validationRules) {
      if (!this.createForm.value[rule.field]) {
        showErrorMessage(rule.message);
        return false;
      }
    }

    if (appointmentDate.isAfter(effectiveDate)) {
      showWarningMessage('Invalid Effective Date');
      this.createForm.get('effectiveDate').reset();
      return false;
    }

    if (this.createForm.value.currentDesignation === this.proposedDesignationDetails.name) {
      showErrorMessage('Cannot select the same Current Designation as Proposed Designation');
      return false;
    }

    if (fromDate.isAfter(toDate)) {
      showWarningMessage('Invalid Period of Evaluation');
      return false;
    }

    if (this.createForm.value.businessPlan === 'true' && !this.fileToUpload) {
      showErrorMessage('Please Upload Business Plan Document');
      return false;
    }

    if (this.createForm.value.complianceIssues === 'true' && !this.createForm.value.complianceIssueReason) {
      showErrorMessage('Compliance Issue Reason is Required');
      return false;
    }

    return true;
  }

  validateDesignation(control: FormControl): { [key: string]: boolean } | null {
    if (!this.createForm) {
      return null;
    }
    const currentDesignation = this.createForm.get('currentDesignation')?.value;
    const proposedDesignationId = control.value;

    this.proposedDesignationDetails = this.designationArray.find(designation => designation.id === proposedDesignationId);
    if (!this.proposedDesignationDetails) {
      return {invalidDesignation: true};
    }

    if (currentDesignation === this.proposedDesignationDetails.name) {
      return {sameDesignation: true};
    }

    this.proposedDesignationName = this.proposedDesignationDetails.name;

    return null;
  }

  allowLettersOnly(event: KeyboardEvent) {
    allowLettersOnly(event);
  }

  clear() {
    const controlsToClear = [
      'designationType',
      'agentCode',
      'agentName',
      'currentDesignationId',
      'currentDesignation',
      'dateAppointment',
      'proposedDesignation',
      'effectiveDate',
      'reportingManagerName',
      'managerCode',
      'fromEvaluationDate',
      'toEvaluationDate',
      'businessPlan',
      'businessAchievement',
      'complianceIssues',
      'complianceIssueReason'
    ];

    controlsToClear.forEach(controlName => {
      this.createForm.get(controlName).setValue('');
      this.createForm.get(controlName).clearValidators();
      this.createForm.get(controlName).updateValueAndValidity();
    });

    this.createForm.get('designationType').setValidators([Validators.required]);
    this.createForm.get('agentCode').setValidators([Validators.required]);
    this.createForm.get('agentName').setValidators([Validators.required]);
    this.createForm.get('currentDesignation').setValidators([Validators.required]);
    this.createForm.get('dateAppointment').setValidators([Validators.required]);
    this.createForm.get('proposedDesignation').setValidators([Validators.required, this.validateDesignation.bind(this)]);
    this.createForm.get('effectiveDate').setValidators([Validators.required]);
    this.createForm.get('reportingManagerName').setValidators([Validators.required]);
    this.createForm.get('managerCode').setValidators([Validators.required]);
    this.createForm.get('businessPlan').setValidators([Validators.required]);
    this.createForm.get('complianceIssues').setValidators([Validators.required]);

    this.createForm.updateValueAndValidity();

    this.fileToUpload = null;
    this.selectedFileName = '';
  }


  async allBranches() {
    const branchListByRegion: any = await this.getBranchList().catch((error) => {
      console.log(error);
    });

    if (branchListByRegion.status === 200) {
      this.branchArray = branchListByRegion.payload.sort((a, b) => a.branchName.localeCompare(b.branchName));
      this.isDisabled = true;
    }
  }

  async getBranchList() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAllBranches(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async allDesignations() {
    const designationList: any = await this.getAllDesignations().catch((error) => {
      console.log(error);
    });
    if (designationList.status === 200) {
      this.designationArray = designationList.data.sort((a, b) => a.name.localeCompare(b.name));
    }
  }

  async getAllDesignations() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getDesignationList(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async allAgentsbyBranch() {
    const agentsList: any = await this.getAgentsDetails().catch((error) => {
      console.log(error);
    });
    if (agentsList.status === 200) {
      this.agentsArray = agentsList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));
    }
  }

  async getAgentsDetails() {

    const branchCode = +this.branchId;

    return new Promise((resolve, reject) => {
      this.advisorService
        .getAgentsbyBranch(branchCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  onAgentSelected(agentCode: string) {
    this.selectedAgent = this.agentsArray.find(agent => agent.agentCode === agentCode);

    if (this.selectedAgent) {

      this.createForm.patchValue({
        currentDesignationId: this.selectedAgent.designationId,
        currentDesignation: this.selectedAgent.designation,
        managerCode: this.selectedAgent.reportingAgentCode,
        reportingManagerName: this.selectedAgent.reportingTo,
        agentName: this.selectedAgent.agentName,
        dateAppointment: formatDate(this.selectedAgent.appointmentDate, 'dd/MM/yyyy', 'en-US')
      });

      this.dateOfAppointment = formatDate(this.selectedAgent.appointmentDate, 'yyyy-MM-dd', 'en-US');
    }
  }

  fileUpload() {
    this.fileInput.nativeElement.click();
  }

  onFileSelected(event: any) {
    const file: File = event.target.files[0];

    const fileType = this.getFileType(file);
    if (fileType === 'jpeg' || fileType === 'pdf') {
      this.fileToUpload = file;
      this.convertToBase64(file);
      this.businessPlanFileType = fileType;
      this.selectedFileName = file.name;
    } else {
      showWarningMessage('Invalid file type. Please upload a .jpeg or pdf file.');
    }
  }

  convertToBase64(file: File) {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const base64String = reader.result as string;
      const base64WithoutPath = base64String.split(',')[1];
      this.businessPlanFileUrl = base64WithoutPath;
    };
    reader.onerror = (error) => {
      console.error('Error: ', error);
    };
  }

  // if (fileName.endsWith('.jpg') || fileName.endsWith('.jpeg'))
  getFileType(file: File): string {
    const fileName = file.name.toLowerCase();
    if (fileName.endsWith('.jpeg')) {
      return 'jpeg';
    } else if (fileName.endsWith('.pdf')) {
      return 'pdf';
    } else {
      return '';
    }
  }

  // Save Form
  async saveAdvisorForm() {

    if (this.validate()) {

      const data = {
        isPromotion: this.createForm.value.designationType,
        agentCode: this.createForm.value.agentCode,
        agentName: this.createForm.value.agentName,
        branchCode: this.createForm.value.branch,
        currentDesignationId: this.createForm.value.currentDesignationId,
        dateOfAppointment: formatDate(this.selectedAgent.appointmentDate, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
        proposedDesignationId: this.createForm.value.proposedDesignation,
        effectiveDate: formatDate(this.createForm.value.effectiveDate, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
        reportingManager: this.createForm.value.reportingManagerName,
        reportingManagerCode: this.createForm.value.managerCode,
        periodOfEvaluationFrom: formatDate(this.createForm.value.fromEvaluationDate ? this.createForm.value.fromEvaluationDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
        periodOfEvaluationTo: formatDate(this.createForm.value.toEvaluationDate ? this.createForm.value.toEvaluationDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
        businessAchievement: this.createForm.value.businessAchievement,
        hasBusinessPlan: this.createForm.value.businessPlan,
        businessPlanFileUrl: this.businessPlanFileUrl,
        businessPlanFileType: this.businessPlanFileType,
        hasComplianceIssues: this.createForm.value.complianceIssues,
        complianceIssueDescription: this.createForm.value.complianceIssueReason,

      };

      const saveResponse: any = await this.saveForm(data).catch(
        (err) => {
          console.log(err);
        }
      );

      if (saveResponse.status === 201) {
        showSucessMessage(saveResponse.message);
        this.router.navigate(['/dashboard/advisor-management/view-applications-table']);
        this.clear();
      } else {
        showErrorMessage(saveResponse.payload.message);
      }

    }
  }

  saveForm(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .submitAdvisorForm(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  // Draft Form
  async draftAdvisorForm() {

    const data = {
      isPromotion: this.createForm.value.designationType,
      agentCode: this.createForm.value.agentCode,
      agentName: this.createForm.value.agentName,
      branchCode: this.createForm.value.branch,
      currentDesignationId: this.createForm.value.currentDesignationId,
      dateOfAppointment: formatDate(this.createForm.value.appointmentDate ? this.createForm.value.appointmentDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
      proposedDesignationId: this.createForm.value.proposedDesignation,
      effectiveDate: formatDate(this.createForm.value.effectiveDate ? this.createForm.value.effectiveDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
      reportingManager: this.createForm.value.reportingManagerName,
      reportingManagerCode: this.createForm.value.managerCode,
      periodOfEvaluationFrom: formatDate(this.createForm.value.fromEvaluationDate ? this.createForm.value.fromEvaluationDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
      periodOfEvaluationTo: formatDate(this.createForm.value.toEvaluationDate ? this.createForm.value.toEvaluationDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
      businessAchievement: this.createForm.value.businessAchievement,
      hasBusinessPlan: this.createForm.value.businessPlan,
      businessPlanFileUrl: this.businessPlanFileUrl,
      businessPlanFileType: this.businessPlanFileType,
      hasComplianceIssues: this.createForm.value.complianceIssues,
      complianceIssueDescription: this.createForm.value.complianceIssueReason,

    };

    const draftResponse: any = await this.draftForm(data).catch(
      (err) => {
        console.log(err);
      }
    );

    if (draftResponse.status === 201) {
      showSucessMessage(draftResponse.message);
      this.router.navigate([
        '/dashboard/advisor-management/view-applications-table',
      ]);
      this.clear();
    } else {
      showErrorMessage(draftResponse.payload.message);
    }
  }

  draftForm(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .draftAdvisorForm(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


}
