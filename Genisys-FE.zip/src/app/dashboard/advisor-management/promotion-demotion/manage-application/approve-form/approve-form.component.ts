import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {
  SELECTOR_OPTIONS,
  Selector, showErrorMessage
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {
  allowLettersOnly
} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {
  AddApproveStatusComponent
} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/add-approve-status/add-approve-status.component';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {formatDate} from '@angular/common';
import {ActivatedRoute} from '@angular/router';
import {
  OpenDocumentComponent
} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/open-document/open-document.component';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-approve-form',
  templateUrl: './approve-form.component.html',
  styleUrls: ['./approve-form.component.scss']
})
export class ApproveFormComponent implements OnInit {

  approveForm: FormGroup;
  selector: Selector[];
  currentDesignation: string;
  proposedDesignation: string;
  currentDate: Date = new Date();
  moment = require('moment');
  dialogRef: MatDialogRef<any>;
  proposedDesignationName: string;
  selectedAgent: any;
  proposedDesignationDetails: any;
  selectedFileName: string;
  isDisabled = false;

  branchArray: Array<any> = [];
  agentsArray: Array<any> = [];
  designationArray: Array<any> = [];

  formId: number;
  formObj: any;
  branchId: string;

  constructor(private formBuilder: FormBuilder,
              private dialog: MatDialog,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              private route: ActivatedRoute,
              private sanitizer: DomSanitizer) {

    this.approveForm = this.formBuilder.group({
      designationType: new FormControl('', [Validators.required]),
      agentCode: new FormControl('', [Validators.required]),
      branch: new FormControl('', [Validators.required]),
      agentName: new FormControl('', [Validators.required]),
      currentDesignation: new FormControl('', [Validators.required]),
      dateAppointment: new FormControl('', [Validators.required]),
      proposedDesignation: new FormControl('', [Validators.required]),
      effectiveDate: new FormControl('', [Validators.required]),
      reportingManagerName: new FormControl('', [Validators.required]),
      mangerCode: new FormControl('', [Validators.required]),
      fromEvaluationDate: new FormControl(''),
      toEvaluationDate: new FormControl(''),
      businessAchievement: new FormControl(''),
      businessPlan: new FormControl('', [Validators.required]),
      complianceIssues: new FormControl('', [Validators.required]),
      complianceIssueReason: new FormControl('')
    });

    this.selector = SELECTOR_OPTIONS;
  }

  async ngOnInit(): Promise<void> {

    this.route.queryParams.subscribe(params => {
      this.formId = (params.formId);
    });

    try {
      await Promise.all([this.allBranches(), this.allDesignations()]);
    } catch (error) {
      console.error(error);
    }

  }

  allowLettersOnly(event: KeyboardEvent) {
    allowLettersOnly(event);
  }

  async allBranches() {
    const branchListByRegion: any = await this.getBranchList().catch((error) => {
      console.log(error);
    });
    if (branchListByRegion.status === 200) {
      this.branchArray = branchListByRegion.payload.sort((a, b) => a.branchName.localeCompare(b.branchName));
      this.isDisabled = true;
      this.getApproveDetails();

    }
  }

  async getBranchList() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAllBranches(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async allAgentsbyBranch() {
    const agentsList: any = await this.getAgentsDetails().catch((error) => {
      console.log(error);
    });
    if (agentsList.status === 200) {
      this.agentsArray = agentsList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));
      this.onAgentSelected(this.formObj.data.agentCode);
    }
  }

  async getAgentsDetails() {

    const branchCode = +this.branchId;

    return new Promise((resolve, reject) => {
      this.advisorService
        .getAgentsbyBranch(branchCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async allDesignations() {
    const designationList: any = await this.getAllDesignations().catch((error) => {
      console.log(error);
    });
    if (designationList.status === 200) {
      this.designationArray = designationList.data.sort((a, b) => a.name.localeCompare(b.name));
    }
  }

  async getAllDesignations() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getDesignationList(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getApproveDetails() {

    this.formObj = await this.getFormDetails().catch((error) => {
      console.log(error);
    });

    if (this.formObj.status === 200) {
      this.branchId = this.formObj.data.branchCode;
      this.allAgentsbyBranch();
      const selectedBranch = this.branchArray.find(branch => branch.branchCode === this.formObj.data.branchCode);

      let evaluationDateFrom = '';
      if (this.formObj.data.periodOfEvaluationFrom) {
        const trimmedPeriodOfEvaluationFrom = this.formObj.data.periodOfEvaluationFrom.substring(0, 10);
        if (trimmedPeriodOfEvaluationFrom !== '1970-01-01') {
          evaluationDateFrom = formatDate(trimmedPeriodOfEvaluationFrom, 'dd/MM/yyyy', 'en-US');
        }
      }
      let evaluationDateTo = '';
      if (this.formObj.data.periodOfEvaluationFrom) {
        const trimmedPeriodOfEvaluationTo = this.formObj.data.periodOfEvaluationTo.substring(0, 10);
        if (trimmedPeriodOfEvaluationTo !== '1970-01-01') {
          evaluationDateTo = formatDate(trimmedPeriodOfEvaluationTo, 'dd/MM/yyyy', 'en-US');
        }
      }
      this.approveForm.patchValue({
        designationType: this.formObj.data.isPromotion ? 'true' : 'false',
        branch: this.formObj.data.branchCode.toString(),
        agentCode: this.formObj.data.agentCode,
        proposedDesignation: this.formObj.data.proposedDesignationId,
        effectiveDate: formatDate( this.formObj.data.effectiveDate, 'dd/MM/yyyy', 'en-US'),
        fromEvaluationDate: evaluationDateFrom,
        toEvaluationDate: evaluationDateTo,
        reportingManagerName: this.formObj.data.reportingManager,
        businessAchievement: this.formObj.data.businessAchievement,
        businessPlan:  this.formObj.data.hasBusinessPlan ? 'true' : 'false',
        complianceIssues:  this.formObj.data.hasComplianceIssues  ? 'true' : 'false',
        complianceIssueReason : this.formObj.data.complianceIssueDescription
      });

      this.proposedDesignationDetails = this.designationArray.find(designation => designation.id === this.formObj.data.proposedDesignationId);
      this.proposedDesignationName = this.proposedDesignationDetails.name;

      let lastIndex = this.formObj.data.businessPlanFileUrl.lastIndexOf('/');
      let filename = this.formObj.data.businessPlanFileUrl.substring(lastIndex + 1);
      this.selectedFileName = filename;
    }
  }

  async getFormDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getPromotionDemotionFormDetails(this.formId, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  onAgentSelected(agentCode: string) {
    this.selectedAgent = this.agentsArray.find(agent => agent.agentCode === agentCode);

    if (this.selectedAgent) {
      this.approveForm.patchValue({
        currentDesignation: this.selectedAgent.designation,
        reportingManagerName: this.selectedAgent.reportingTo,
        dateAppointment: formatDate(this.selectedAgent.appointmentDate, 'dd/MM/yyyy', 'en-US')
      });
    }
  }

  convertPdfFile(b64Data, contentType) {
    contentType = contentType || '';
    let sliceSize = 512;

    var byteCharacters = atob(b64Data);
    var byteArrays = [];

    for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      var slice = byteCharacters.slice(offset, offset + sliceSize);

      var byteNumbers = new Array(slice.length);
      for (var i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }

      var byteArray = new Uint8Array(byteNumbers);

      byteArrays.push(byteArray);
    }

    var blob = new Blob(byteArrays, { type: contentType });
    return blob;
  }

  displayLetter() {

    this.advisorService.openDocument(this.formId).subscribe(
      (pdfData) => {
        console.log('pdfData.status', pdfData);
        if (pdfData.status === 200) {
          // const blob = this.convertPdfFile(pdfData.data.byteArray, 'application/pdf');
          let blob;
          let fileURL;
          if (pdfData.data.fileType === 'pdf') {
            blob = this.convertPdfFile(pdfData.data.byteArray, 'application/pdf');
            fileURL = URL.createObjectURL(blob);
          } else if (pdfData.data.fileType === 'jpeg') {
            blob = this.convertPdfFile(pdfData.data.byteArray, 'image/jpeg');
            fileURL = URL.createObjectURL(blob);
            fileURL = this.sanitizer.bypassSecurityTrustResourceUrl(fileURL);
          }

          this.openDocument(fileURL, pdfData.data.fileType);

        } else  {
          showErrorMessage(pdfData.message);
          this.dialogRef.close(true);
        }

      },
      (error) => {
        console.error('Error getting PDF data:', error);
      }
    );
  }

  openDocument(fileURL: string, docType: string): void {

    this.dialogRef = this.dialog.open(OpenDocumentComponent, {
      width: '1150px',
      data: { pdfSrc: fileURL,
        fileType: docType }
    });
  }

  openApproveStatus() {
    const elements = {
      id: this.formId,
      formTitle: 'designation'
    };

    this.dialogRef = this.dialog.open(AddApproveStatusComponent, {
      width: '600px',
      disableClose: true,
      data: elements,
    });
  }

}
