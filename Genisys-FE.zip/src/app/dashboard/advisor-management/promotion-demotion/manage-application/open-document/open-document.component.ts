import {Component, Inject, OnInit, ViewChild, ElementRef, AfterViewInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {SafeUrl, DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-open-document',
  templateUrl: './open-document.component.html',
  styleUrls: ['./open-document.component.scss']
})
export class OpenDocumentComponent implements OnInit {
  pdfSrc: any;
  isActivePdf = false;
  isActiveJpg = false;

  @ViewChild('pdfIframe', { static: true }) pdfIframe: ElementRef;
  constructor(public dialogRef: MatDialogRef<OpenDocumentComponent>,
              private advisorService: AdvisorManagementService,
              private sanitizer: DomSanitizer,
              @Inject(MAT_DIALOG_DATA) public data: any) {

    this.pdfSrc = data.pdfSrc;
    switch (data.fileType) {
      case 'pdf':
        this.isActivePdf = true;

        break;
      case 'jpeg':
        this.isActiveJpg = true;
        break;

      default:
        break;
    }

  }

  ngOnInit(): void {
  }

}
