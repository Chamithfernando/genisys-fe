import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {AuthService} from '@app/shared/services/auth/auth.service';

@Component({
  selector: 'app-view-table',
  templateUrl: './view-table.component.html',
  styleUrls: ['./view-table.component.scss']
})
export class ViewTableComponent implements OnInit {

  token: any;
  userDetails: any;
  hideFeatures = false;
  hideSFAFeatures = false;


  constructor(private router: Router,
              private authService: AuthService) {
  }

  ngOnInit(): void {
    this.getLoginUser();
  }

  addNewForm() {
    this.router.navigate([
      '/dashboard/advisor-management/create-form',
    ]);
  }


  async getLoginUser() {
    this.userDetails = await this.getUserDetails().catch((error) => {
      console.log(error);
    });

    if (this.userDetails.status === 'OK') {
      const roleName = this.userDetails.data.roleDto.roleName;
      if (['Zonal Manager', 'SFA'].includes(roleName)) {
        this.hideFeatures = true;
      }

      if (['SFA'].includes(roleName)) {
        this.hideSFAFeatures = true;
      }

    }
  }

  async getUserDetails() {
    return new Promise((resolve, reject) => {

      this.authService
        .getPermission()
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


}
