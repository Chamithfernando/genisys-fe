import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NotApprovedTableComponent } from './not-approved-table.component';

describe('NotApprovedTableComponent', () => {
  let component: NotApprovedTableComponent;
  let fixture: ComponentFixture<NotApprovedTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NotApprovedTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NotApprovedTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
