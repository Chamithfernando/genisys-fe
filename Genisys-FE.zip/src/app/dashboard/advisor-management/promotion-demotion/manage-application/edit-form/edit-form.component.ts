import {Component, OnInit, ViewChild, ElementRef} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {
  SELECTOR_OPTIONS,
  Selector,
  showErrorMessage, showWarningMessage, showSucessMessage
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {allowLettersOnly} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {formatDate} from '@angular/common';
import {ActivatedRoute, Router} from '@angular/router';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {
  OpenDocumentComponent
} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/open-document/open-document.component';
import { DomSanitizer } from '@angular/platform-browser';


@Component({
  selector: 'app-edit-form',
  templateUrl: './edit-form.component.html',
  styleUrls: ['./edit-form.component.scss']
})
export class EditFormComponent implements OnInit {

  editForm: FormGroup;
  selector: Selector[];
  currentDesignation: string;
  proposedDesignation: string;
  currentDate: Date = new Date();
  moment = require('moment');
  token: any;
  branchArray: any = [];
  fileToUpload: File;
  businessPlanFileUrl: string;
  businessPlanFileType: string;
  selectedFileName: string;
  designationArray: any = [];
  agentsArray: any = [];
  branchId: string;
  selectedAgent: any;
  proposedDesignationDetails: any;
  proposedDesignationName: string;
  formStatus: string;
  businessFileUrl: string;
  fileType: string;
  isDisabled = true;

  formId: number;
  formObj: any;
  dateOfAppointment: string;
  dialogRef: MatDialogRef<any>;

  @ViewChild('fileInput') fileInput: ElementRef<HTMLInputElement>;

  constructor(private formBuilder: FormBuilder,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              private router: Router,
              private route: ActivatedRoute,
              private dialog: MatDialog,
              private sanitizer: DomSanitizer) {

    this.editForm = this.formBuilder.group({
      designationType: new FormControl('', [Validators.required]),
      agentCode: new FormControl('', [Validators.required]),
      branch: new FormControl('', [Validators.required]),
      agentName: new FormControl('', [Validators.required]),
      currentDesignationId: new FormControl(''),
      currentDesignation: new FormControl('', [Validators.required]),
      dateAppointment: new FormControl('', [Validators.required]),
      proposedDesignation: new FormControl('', [Validators.required, this.validateDesignation.bind(this)]),
      effectiveDate: new FormControl('', [Validators.required]),
      reportingManagerName: new FormControl('', [Validators.required]),
      managerCode: new FormControl('', [Validators.required]),
      fromEvaluationDate: new FormControl(''),
      toEvaluationDate: new FormControl(''),
      businessAchievement: new FormControl(''),
      businessPlan: new FormControl('', [Validators.required]),
      complianceIssues: new FormControl('', [Validators.required]),
      complianceIssueReason: new FormControl('')
    });

    this.selector = SELECTOR_OPTIONS;
  }

  async ngOnInit(): Promise<void> {
    this.route.queryParams.subscribe(params => {
      this.formId = (params.formId);
      this.formStatus = (params.formStatus);

    });

    try {
      await Promise.all([this.allBranches(), this.allDesignations()]);
    } catch (error) {
      console.error(error);
    }
  }

  // Form Validations
  validate() {
    const appointmentDate = this.moment(this.editForm.value.dateAppointment, 'DD/MM/YYYY');
    const effectiveDate = this.moment(this.editForm.value.effectiveDate);

    const fromDate = this.moment(this.editForm.value.fromEvaluationDate);
    const toDate = this.moment(this.editForm.value.toEvaluationDate);

    const validationRules = [
      {field: 'designationType', message: 'Re Designation Type is Required'},
      {field: 'agentCode', message: 'Agent Code is Required'},
      {field: 'branch', message: 'Branch is Required'},
      {field: 'agentName', message: 'Agent Name is Required'},
      {field: 'currentDesignation', message: 'Current Designation is Required'},
      {field: 'dateAppointment', message: 'Date of Appointment is Required'},
      {field: 'proposedDesignation', message: 'Proposed Designation is Required'},
      {field: 'effectiveDate', message: 'Effective Date is Required'},
      {field: 'reportingManagerName', message: 'Reporting Manger is Required'},
      {field: 'managerCode', message: 'Manger Code is Required'},
      {field: 'businessPlan', message: 'Business Plan is Required'},
      {field: 'complianceIssues', message: 'Compliance Issue is Required'},
    ];

    for (const rule of validationRules) {
      if (!this.editForm.value[rule.field]) {
        showErrorMessage(rule.message);
        return false;
      }
    }

    if (appointmentDate.isAfter(effectiveDate)) {
      showWarningMessage('Invalid Effective Date');
      this.editForm.get('effectiveDate').reset();
      return false;
    }

    if (this.editForm.value.currentDesignation === this.proposedDesignationDetails.name) {
      showErrorMessage('Cannot select the same Current Designation as Proposed Designation');
      return false;
    }

    if (fromDate.isAfter(toDate)) {
      showWarningMessage('Invalid Period of Evaluation');
      return false;
    }

    if (this.editForm.value.businessPlan === 'true' && !this.fileToUpload && !this.selectedFileName) {
      showErrorMessage('Please Upload Business Plan Document');
      return false;
    }

    if (this.editForm.value.complianceIssues === 'true' && !this.editForm.value.complianceIssueReason) {
      showErrorMessage('Compliance Issue Reason is Required');
      return false;
    }

    return true;
  }

  validateDesignation(control: FormControl): { [key: string]: boolean } | null {
    if (!this.editForm) {
      return null;
    }
    const currentDesignation = this.editForm.get('currentDesignation')?.value;
    const proposedDesignationId = control.value;

    this.proposedDesignationDetails = this.designationArray.find(designation => designation.id === proposedDesignationId);
    if (!this.proposedDesignationDetails) {
      return {invalidDesignation: true};
    }

    if (currentDesignation === this.proposedDesignationDetails.name) {
      return {sameDesignation: true};
    }

    this.proposedDesignationName = this.proposedDesignationDetails.name;

    return null;
  }

  allowLettersOnly(event: KeyboardEvent) {
    allowLettersOnly(event);
  }


  // Clear All Data
  clear() {
    const controlsToClear = [
      'designationType',
      'agentCode',
      'agentName',
      'currentDesignationId',
      'currentDesignation',
      'dateAppointment',
      'proposedDesignation',
      'effectiveDate',
      'reportingManagerName',
      'managerCode',
      'fromEvaluationDate',
      'toEvaluationDate',
      'businessPlan',
      'businessAchievement',
      'complianceIssues',
      'complianceIssueReason'
    ];

    controlsToClear.forEach(controlName => {
      this.editForm.get(controlName).setValue('');
      this.editForm.get(controlName).clearValidators();
      this.editForm.get(controlName).updateValueAndValidity();
    });

    this.editForm.get('designationType').setValidators([Validators.required]);
    this.editForm.get('agentCode').setValidators([Validators.required]);
    this.editForm.get('agentName').setValidators([Validators.required]);
    this.editForm.get('currentDesignation').setValidators([Validators.required]);
    this.editForm.get('dateAppointment').setValidators([Validators.required]);
    this.editForm.get('proposedDesignation').setValidators([Validators.required, this.validateDesignation.bind(this)]);
    this.editForm.get('effectiveDate').setValidators([Validators.required]);
    this.editForm.get('reportingManagerName').setValidators([Validators.required]);
    this.editForm.get('managerCode').setValidators([Validators.required]);
    this.editForm.get('businessPlan').setValidators([Validators.required]);
    this.editForm.get('complianceIssues').setValidators([Validators.required]);

    this.editForm.updateValueAndValidity();

    this.fileToUpload = null;
    this.selectedFileName = '';
  }


  // Get All Branches
  async allBranches() {
    const branchListByRegion: any = await this.getBranchList().catch((error) => {
      console.log(error);
    });
    if (branchListByRegion.status === 200) {
      this.branchArray = branchListByRegion.payload.sort((a, b) => a.branchName.localeCompare(b.branchName));
      this.isDisabled = true;
      this.getDraftDetails();
    }
  }

  async getBranchList() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAllBranches(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  // Get All Designations
  async allDesignations() {
    const designationList: any = await this.getAllDesignations().catch((error) => {
      console.log(error);
    });
    if (designationList.status === 200) {
      this.designationArray = designationList.data.sort((a, b) => a.name.localeCompare(b.name));
    }
  }

  async getAllDesignations() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getDesignationList(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  // Get Agents list by Branch Id
  async allAgentsbyBranch() {
    const agentsList: any = await this.getAgentsDetails().catch((error) => {
      console.log(error);
    });
    if (agentsList.status === 200) {
      this.agentsArray = agentsList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));
      this.onAgentSelected(this.formObj.data.agentCode);
    }
  }

  async getAgentsDetails() {

    const branchCode = +this.branchId;

    return new Promise((resolve, reject) => {
      this.advisorService
        .getAgentsbyBranch(branchCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  // Get Current Designation Details
  onAgentSelected(agentCode: string) {
    this.selectedAgent = this.agentsArray.find(agent => agent.agentCode === agentCode);

    if (this.selectedAgent) {

      this.editForm.patchValue({
        currentDesignationId: this.selectedAgent.designationId,
        currentDesignation: this.selectedAgent.designation,
        managerCode: this.selectedAgent.reportingAgentCode,
        reportingManagerName: this.selectedAgent.reportingTo,
        agentName: this.selectedAgent.agentName,
        dateAppointment: formatDate(this.selectedAgent.appointmentDate, 'dd/MM/yyyy', 'en-US')
      });

      this.dateOfAppointment = formatDate(this.selectedAgent.appointmentDate, 'yyyy-MM-dd', 'en-US');
    }
  }

  // File Upload
  fileUpload() {
    this.fileInput.nativeElement.click();
  }

  onFileSelected(event: any) {
    const file: File = event.target.files[0];

    const fileType = this.getFileType(file);
    if (fileType === 'jpeg' || fileType === 'pdf') {
      this.fileToUpload = file;
      this.convertToBase64(file);
      this.businessPlanFileType = fileType;
      this.selectedFileName = file.name;
    } else {
      showWarningMessage('Invalid file type. Please upload a .jpeg or pdf file.');
    }
  }

  convertToBase64(file: File) {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const base64String = reader.result as string;
      const base64WithoutPath = base64String.split(',')[1];
      this.businessPlanFileUrl = base64WithoutPath;
    };
    reader.onerror = (error) => {
      console.error('Error: ', error);
    };
  }

  // if (fileName.endsWith('.jpg') || fileName.endsWith('.jpeg'))
// Check Upload File Type
  getFileType(file: File): string {
    const fileName = file.name.toLowerCase();
    if (fileName.endsWith('.jpeg')) {
      return 'jpeg';
    } else if (fileName.endsWith('.pdf')) {
      return 'pdf';
    } else {
      return '';
    }
  }

  // Get Draft Details
  async getDraftDetails() {

    this.formObj = await this.getFormDetails().catch((error) => {
      console.log(error);
    });

    if (this.formObj.status === 200) {
      this.branchId = this.formObj.data.branchCode;
      this.allAgentsbyBranch();

      const selectedBranch = this.branchArray.find(branch => branch.branchCode === this.formObj.data.branchCode);

      let evaluationDateFrom = '';
      if (this.formObj.data.periodOfEvaluationFrom) {
        const trimmedPeriodOfEvaluationFrom = this.formObj.data.periodOfEvaluationFrom.substring(0, 10);
        if (trimmedPeriodOfEvaluationFrom !== '1970-01-01') {
          evaluationDateFrom = formatDate(trimmedPeriodOfEvaluationFrom, 'yyyy-MM-dd', 'en-US');
        }
      }
      let evaluationDateTo = '';
      if (this.formObj.data.periodOfEvaluationFrom) {
        const trimmedPeriodOfEvaluationTo = this.formObj.data.periodOfEvaluationTo.substring(0, 10);
        if (trimmedPeriodOfEvaluationTo !== '1970-01-01') {
          evaluationDateTo = formatDate(trimmedPeriodOfEvaluationTo, 'yyyy-MM-dd', 'en-US');
        }
      }
      const formattedEffectiveDate = formatDate(this.formObj.data.effectiveDate, 'yyyy-MM-dd', 'en-US');

      this.editForm.patchValue({
        designationType: this.formObj.data.isPromotion ? 'true' : 'false',
        branch: this.formObj.data.branchCode.toString(),
        agentCode: this.formObj.data.agentCode,
        proposedDesignation: this.formObj.data.proposedDesignationId,
        effectiveDate: formatDate(this.formObj.data.effectiveDate, 'yyyy-MM-dd', 'en-US'),
        fromEvaluationDate: evaluationDateFrom,
        toEvaluationDate: evaluationDateTo,
        reportingManagerName: this.formObj.data.reportingManager,
        businessAchievement: this.formObj.data.businessAchievement,
        businessPlan: this.formObj.data.hasBusinessPlan ? 'true' : 'false',
        complianceIssues: this.formObj.data.hasComplianceIssues ? 'true' : 'false',
        complianceIssueReason: this.formObj.data.complianceIssueDescription
      });

      this.proposedDesignationName = this.formObj.data.proposedDesignationName;
      this.businessFileUrl = this.formObj.data.businessPlanFileUrl === 'N/A' ? '' : this.formObj.data.businessPlanFileUrl;

      if (this.formObj.data.businessPlanFileUrl !== 'N/A') {
        let lastIndex = this.formObj.data.businessPlanFileUrl.lastIndexOf('/');
        let filename = this.formObj.data.businessPlanFileUrl.substring(lastIndex + 1);

        this.selectedFileName = filename;
      } else {
        this.selectedFileName = '';
      }

      this.fileType = this.formObj.data.businessPlanFileType;


    }
  }

  async getFormDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getPromotionDemotionFormDetails(this.formId, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  convertPdfFile(b64Data, contentType) {
    contentType = contentType || '';
    let sliceSize = 512;

    var byteCharacters = atob(b64Data);
    var byteArrays = [];

    for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      var slice = byteCharacters.slice(offset, offset + sliceSize);

      var byteNumbers = new Array(slice.length);
      for (var i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }

      var byteArray = new Uint8Array(byteNumbers);

      byteArrays.push(byteArray);
    }

    var blob = new Blob(byteArrays, { type: contentType });
    return blob;
  }

  displayLetter() {

    this.advisorService.openDocument(this.formId).subscribe(
      (pdfData) => {

        if (pdfData.status === 200) {
          // const blob = this.convertPdfFile(pdfData.data.byteArray, 'application/pdf');
          let blob;
          let fileURL;
          if (pdfData.data.fileType === 'pdf') {
            blob = this.convertPdfFile(pdfData.data.byteArray, 'application/pdf');
            fileURL = URL.createObjectURL(blob);
          } else if (pdfData.data.fileType === 'jpeg') {
            blob = this.convertPdfFile(pdfData.data.byteArray, 'image/jpeg');
            fileURL = URL.createObjectURL(blob);
            fileURL = this.sanitizer.bypassSecurityTrustResourceUrl(fileURL);
          }

          this.openDocument(fileURL, pdfData.data.fileType);

        } else  {
          showErrorMessage(pdfData.message);
          this.dialogRef.close(true);
        }

      },
      (error) => {
        console.error('Error getting PDF data:', error);
      }
    );
  }

  openDocument(fileURL: string, docType: string): void {

    this.dialogRef = this.dialog.open(OpenDocumentComponent, {
      width: '1150px',
      data: { pdfSrc: fileURL,
              fileType: docType }
    });
  }



  // Save Form
  async saveAdvisorForm() {
    if (this.validate()) {

      const data = {
        id: this.formId,
        isPromotion: this.editForm.value.designationType,
        agentCode: this.editForm.value.agentCode,
        agentName: this.editForm.value.agentName,
        branchCode: this.editForm.value.branch,
        currentDesignationId: this.editForm.value.currentDesignationId,
        dateOfAppointment: formatDate(this.selectedAgent.appointmentDate, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
        proposedDesignationId: this.editForm.value.proposedDesignation,
        effectiveDate: formatDate(this.editForm.value.effectiveDate, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
        reportingManager: this.editForm.value.reportingManagerName,
        reportingManagerCode: this.editForm.value.managerCode,
        periodOfEvaluationFrom: formatDate(this.editForm.value.fromEvaluationDate ? this.editForm.value.fromEvaluationDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
        periodOfEvaluationTo: formatDate(this.editForm.value.toEvaluationDate ? this.editForm.value.toEvaluationDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
        businessAchievement: this.editForm.value.businessAchievement,
        hasBusinessPlan: this.editForm.value.businessPlan,
        businessPlanFileUrl: this.businessPlanFileUrl,
        businessPlanFileType: this.businessPlanFileType ? this.businessPlanFileType : this.fileType,
        hasComplianceIssues: this.editForm.value.complianceIssues,
        complianceIssueDescription: this.editForm.value.complianceIssueReason,

      };

      const saveResponse: any = await this.saveForm(data).catch(
        (err) => {
          console.log(err);
        }
      );


      if (saveResponse.status === 201) {
        showSucessMessage(saveResponse.message);
        this.router.navigate(['/dashboard/advisor-management/view-applications-table']);
        this.clear();
      } else {
        showErrorMessage(saveResponse.payload.message);
      }

    }
  }

  saveForm(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .submitAdvisorForm(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  // Draft Form
  async draftAdvisorForm() {

    const data = {
      id: this.formId,
      isPromotion: this.editForm.value.designationType,
      agentCode: this.editForm.value.agentCode,
      agentName: this.editForm.value.agentName,
      branchCode: this.editForm.value.branch,
      currentDesignationId: this.editForm.value.currentDesignationId,
      dateOfAppointment: formatDate(this.editForm.value.appointmentDate ? this.editForm.value.appointmentDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
      proposedDesignationId: this.editForm.value.proposedDesignation,
      effectiveDate: formatDate(this.editForm.value.effectiveDate ? this.editForm.value.effectiveDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
      reportingManager: this.editForm.value.reportingManagerName,
      reportingManagerCode: this.editForm.value.managerCode,
      periodOfEvaluationFrom: formatDate(this.editForm.value.fromEvaluationDate ? this.editForm.value.fromEvaluationDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
      periodOfEvaluationTo: formatDate(this.editForm.value.toEvaluationDate ? this.editForm.value.toEvaluationDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
      businessAchievement: this.editForm.value.businessAchievement,
      hasBusinessPlan: this.editForm.value.businessPlan,
      businessPlanFileUrl: this.businessPlanFileUrl,
      // businessPlanFileType: this.businessPlanFileType,
      businessPlanFileType: this.businessPlanFileType ? this.businessPlanFileType : this.fileType,
      hasComplianceIssues: this.editForm.value.complianceIssues,
      complianceIssueDescription: this.editForm.value.complianceIssueReason,

    };

    const draftResponse: any = await this.draftForm(data).catch(
      (err) => {
        console.log(err);
      }
    );

    if (draftResponse.status === 201) {
      showSucessMessage(draftResponse.message);
      this.router.navigate([
        '/dashboard/advisor-management/view-applications-table',
      ]);
      this.clear();
    } else {
      showErrorMessage(draftResponse.payload.message);
    }
  }

  draftForm(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .draftAdvisorForm(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
