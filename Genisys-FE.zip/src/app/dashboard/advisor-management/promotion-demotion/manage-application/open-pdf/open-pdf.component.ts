import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef} from '@angular/material/dialog';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {showErrorMessage} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {SafeUrl} from '@angular/platform-browser';

@Component({
  selector: 'app-open-pdf',
  templateUrl: './open-pdf.component.html',
  styleUrls: ['./open-pdf.component.scss']
})
export class OpenPdfComponent implements OnInit {

  pdfSrc: SafeUrl;

  constructor(public dialogRef: MatDialogRef<OpenPdfComponent>,
              private advisorService: AdvisorManagementService,
              @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit(): void {
    this.displayLetter();
  }

  displayLetter(): void {
    const formId: number = this.data.id;

    if (this.data.title === 'designation') {
      this.advisorService.downloadDesignationChangeLetter(formId)
        .subscribe(
          (response: Blob) => {
            if (response.size > 100) {
              const docFilePdf = new File([response], 'Letter', {type: 'application/pdf'});
              const rowUrl = URL.createObjectURL(docFilePdf);
              this.pdfSrc = rowUrl;
            } else {
              showErrorMessage('Document Display Failed.');
            }
          },
          (error) => {
            console.error('Error fetching document:', error);
            showErrorMessage('Document Display Failed.');
          }
        );
    }
    else if (this.data.title === 'termination'){
      this.advisorService.downloadTerminationLetter(formId)
        .subscribe(
          (response: Blob) => {
            if (response.size > 100) {
              const docFilePdf = new File([response], 'Letter', {type: 'application/pdf'});
              const rowUrl = URL.createObjectURL(docFilePdf);
              this.pdfSrc = rowUrl;
            } else {
              showErrorMessage('Document Display Failed.');
            }
          },
          (error) => {
            console.error('Error fetching document:', error);
            showErrorMessage('Document Display Failed.');
          }
        );
    }else if (this.data.title === 'terminationUploadFile'){
      this.advisorService.openTerminationDocument(formId)
        .subscribe(
          (response: Blob) => {
            if (response.size > 100) {
              const docFilePdf = new File([response], 'Letter', {type: 'application/pdf'});
              const rowUrl = URL.createObjectURL(docFilePdf);
              this.pdfSrc = rowUrl;
            } else {
              showErrorMessage('Document Display Failed.');
            }
          },
          (error) => {
            console.error('Error fetching document:', error);
            showErrorMessage('Document Display Failed.');
          }
        );
    }else if (this.data.title === 'policyTransferUploadFile'){
      this.advisorService.openPolicyTransferDocument(formId)
        .subscribe(
          (response: Blob) => {
            if (response.size > 100) {
              const docFilePdf = new File([response], 'Letter', {type: 'application/pdf'});
              const rowUrl = URL.createObjectURL(docFilePdf);
              this.pdfSrc = rowUrl;
            } else {
              showErrorMessage('Document Display Failed.');
            }
          },
          (error) => {
            console.error('Error fetching document:', error);
            showErrorMessage('Document Display Failed.');
          }
        );
    } else if (this.data.title === 'incomeServiceUploadFile'){
      this.advisorService.openIncomeServiceDocument(formId)
        .subscribe(
          (response: Blob) => {
            if (response.size > 100) {
              const docFilePdf = new File([response], 'Letter', {type: 'application/pdf'});
              const rowUrl = URL.createObjectURL(docFilePdf);
              this.pdfSrc = rowUrl;
            } else {
              showErrorMessage('Document Display Failed.');
            }
          },
          (error) => {
            console.error('Error fetching document:', error);
            showErrorMessage('Document Display Failed.');
          }
        );
    }else if (this.data.title === 'incomeUploadFile'){
      this.advisorService.openIncomeDocument(formId)
        .subscribe(
          (response: Blob) => {
            if (response.size > 100) {
              const docFilePdf = new File([response], 'Letter', {type: 'application/pdf'});
              const rowUrl = URL.createObjectURL(docFilePdf);
              this.pdfSrc = rowUrl;
            } else {
              showErrorMessage('Document Display Failed.');
            }
          },
          (error) => {
            console.error('Error fetching document:', error);
            showErrorMessage('Document Display Failed.');
          }
        );
    }else if (this.data.title === 'serviceUploadFile'){
      this.advisorService.openServiceDocument(formId)
        .subscribe(
          (response: Blob) => {
            if (response.size > 100) {
              const docFilePdf = new File([response], 'Letter', {type: 'application/pdf'});
              const rowUrl = URL.createObjectURL(docFilePdf);
              this.pdfSrc = rowUrl;
            } else {
              showErrorMessage('Document Display Failed.');
            }
          },
          (error) => {
            console.error('Error fetching document:', error);
            showErrorMessage('Document Display Failed.');
          }
        );
    }
  }

}
