import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrentApprovalLevelsComponent } from './current-approval-levels.component';

describe('CurrentApprovalLevelsComponent', () => {
  let component: CurrentApprovalLevelsComponent;
  let fixture: ComponentFixture<CurrentApprovalLevelsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CurrentApprovalLevelsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrentApprovalLevelsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
