import {Component, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {Router} from '@angular/router';
import {applyFilter, showWarningMessage} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {validateEnterSpecialCharacters} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {
  RejectReasonComponent
} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/reject-reason/reject-reason.component';


@Component({
  selector: 'app-rejected-table',
  templateUrl: './rejected-table.component.html',
  styleUrls: ['./rejected-table.component.scss']
})
export class RejectedTableComponent implements OnInit {

  tableForm: FormGroup;
  token: any;
  dialogRef: MatDialogRef<any>;

  categoryArray: any = [];
  zoneArray: any = [];
  regionArray: any = [];
  branchArray: any = [];

  categoryStatus = false;
  zoneStatus = false;
  regionStatus = false;
  branchStatus = false;

  initialCategoryId: number;
  initialZoneId: number;
  initialRegionId: number;
  initialBranchId: number;
  newinitialCategoryId: number;

  zoneId: number;
  regionId: number;
  branchId: number;

  tableStatus: string;
  formListObj: any;
  formList: Array<any> = [];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  displayedColumns: string[] = ['sequenceNumber', 'id', 'agentName', 'nic', 'contactNo', 'rejectReason'];
  dataSource = new MatTableDataSource();

  constructor(private viewTable: FormBuilder,
              private dialog: MatDialog,
              private authService: AuthService,
              private advisorService: AdvisorManagementService,
              private router: Router) {

    this.tableForm = this.viewTable.group({
      category: new FormControl(''),
      region: new FormControl(''),
      zone: new FormControl(''),
      branch: new FormControl(''),
      search: new FormControl('')
    });
  }

  ngOnInit(): void {
    this.token = this.authService.getCurrentUserDetails().access_token;
    this.getUserData(this.token);

    this.getPromotionDemotionDetails();

    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  rejectApplication(e: any, element: number) {
    const rejectDetails = {
      id: element,
      title: 'reject'
    };

    this.dialogRef = this.dialog.open(RejectReasonComponent, {
      width: '600px',
      data: rejectDetails,
    });
  }

  applyFilter(event: Event) {
    applyFilter(this.dataSource, event);
  }

  validateEnterSpecialCharacters(event: Event) {
    validateEnterSpecialCharacters(event);
  }

  async onCategoryChange(event) {

    if (event.value === 2) {
      const zoneList: any = await this.getZoneList().catch((error) => {
        console.log(error);
      });
      if (zoneList.status === 200) {
        this.zoneArray = zoneList.payload.sort((a, b) => a.zoneName.localeCompare(b.zoneName));
        this.regionArray = [];
        this.branchArray = [];

        this.zoneStatus = false;
        this.regionStatus = true;
        this.branchStatus = true;

        this.tableForm.get('zone').setValue(0);
        this.tableForm.get('region').setValue(0);
        this.tableForm.get('branch').setValue(0);
        this.tableForm.get('tlfm').setValue(0);
        this.tableForm.get('advisor').setValue(0);
      }
    } else if (event.value === 3) {

      const regionList: any = await this.getRegionList().catch((error) => {
        console.log(error);
      });
      if (regionList.status === 200) {

        this.regionArray = regionList.payload.sort((a, b) => a.regionName.localeCompare(b.regionName));
        this.zoneArray = [];
        this.branchArray = [];

        this.regionStatus = false;
        this.zoneStatus = true;
        this.branchStatus = true;

        this.tableForm.get('zone').setValue(0);
        this.tableForm.get('region').setValue(0);
        this.tableForm.get('branch').setValue(0);

      }
    } else if (event.value === 1) {
      this.zoneStatus = true;
      this.regionStatus = true;
      this.branchStatus = true;

      this.tableForm.get('zone').setValue(0);
      this.tableForm.get('region').setValue(0);
      this.tableForm.get('branch').setValue(0);


    } else {
      const branchList: any = await this.getBranchList().catch((error) => {
        console.log(error);
      });
      if (branchList.status === 200) {

        this.branchArray = branchList.payload.sort((a, b) => a.branchName.localeCompare(b.branchName));
        this.zoneArray = [];
        this.regionArray = [];

        this.branchStatus = false;
        this.zoneStatus = true;
        this.regionStatus = true;

        this.tableForm.get('branch').setValue(0);
        this.tableForm.get('zone').setValue(0);
        this.tableForm.get('region').setValue(0);

      }
    }
  }

  async onRegionChange($event) {
    this.regionId = this.tableForm.value.region;

    if (this.regionId !== 0) {
      const branchListByRegion: any = await this.getBranchListByRegion(this.regionId).catch((error) => {
        console.log(error);
      });


      if (branchListByRegion.status === 200) {

        this.branchArray = branchListByRegion.payload.sort((a, b) => a.branchName.localeCompare(b.branchName));
        this.branchStatus = false;

        this.tableForm.get('branch').setValue(0);
      } else {
        showWarningMessage(branchListByRegion.message);
      }
    } else {
      this.branchStatus = true;

      this.tableForm.get('branch').setValue(0);
    }
  }

  async onZoneChange($event) {
    this.zoneId = this.tableForm.value.zone;

    if (this.zoneId !== 0) {
      const regionListByZoneList: any = await this.getRegionListByZone(this.zoneId).catch((error) => {
        console.log(error);
      });

      if (regionListByZoneList.status === 200) {

        this.regionArray = regionListByZoneList.payload.sort((a, b) => a.regionName.localeCompare(b.regionName));
        this.regionStatus = false;
        this.branchStatus = true;

        this.tableForm.get('region').setValue(0);
        this.tableForm.get('branch').setValue(0);

      } else {
        showWarningMessage(regionListByZoneList.message);
      }

      this.zoneStatus = false;
    } else {
      this.regionStatus = true;
      this.branchStatus = true;

      this.tableForm.get('region').setValue(0);
      this.tableForm.get('branch').setValue(0);
    }
  }


  async getUserData(token: string) {
    const loggedUserDataObj: any = await this.dashboardListing(token).catch((err) => {
      console.log(err);
    });


    if (loggedUserDataObj.status === 200) {

      this.categoryArray = loggedUserDataObj.categoryResponse.categoryList;
      this.zoneArray = loggedUserDataObj.zoneResponse.zoneDTOList;
      this.regionArray = loggedUserDataObj.regionResponse.regionDTOList;
      this.branchArray = loggedUserDataObj.branchResponse.branchDTOList;


      this.categoryStatus = !loggedUserDataObj.categoryResponse.enable;
      this.zoneStatus = !loggedUserDataObj.zoneResponse.enable;
      this.regionStatus = !loggedUserDataObj.regionResponse.enable;
      this.branchStatus = !loggedUserDataObj.branchResponse.enable;

      this.patchValues(loggedUserDataObj);

      this.setInitialValues(loggedUserDataObj);


    }
  }

  async dashboardListing(token: string) {
    return new Promise((resolve, reject) => {
      this.advisorService.onInitFunction(token).subscribe(data => {
        resolve(data);
      }, error => {
        reject(error);
      });
    });
  }

  topLevelCategoryOnChange() {
    this.zoneStatus = true;
    this.regionStatus = true;
    this.branchStatus = true;
    this.tableForm.get('category').setValue(1);
    this.tableForm.get('zone').setValue(0);
    this.tableForm.get('region').setValue(0);
    this.tableForm.get('branch').setValue(0);
  }

  async setInitialValues(userData: any): Promise<void> {

    const today = new Date();

    if (userData.categoryResponse.categoryList.length > 1 || userData.categoryResponse.categoryList.length === 0) {
      this.initialCategoryId = 0;
      this.topLevelCategoryOnChange();
    } else {
      this.initialCategoryId = userData.categoryResponse.categoryList[0].id;
    }
    if (userData.zoneResponse.zoneDTOList.length > 1 || userData.zoneResponse.zoneDTOList.length === 0) {
      this.initialZoneId = 0;
    } else {
      this.initialZoneId = userData.zoneResponse.zoneDTOList[0].zoneId;
    }
    if (userData.regionResponse.regionDTOList.length > 1 || userData.regionResponse.regionDTOList.length === 0) {
      this.initialRegionId = 0;
      this.tableForm.get('region').setValue(0);
      this.tableForm.get('branch').setValue(0);
    } else {
      this.initialRegionId = userData.regionResponse.regionDTOList[0].regionId;
      this.tableForm.get('branch').setValue(0);
    }
    if (userData.branchResponse.branchDTOList.length > 1 || userData.branchResponse.branchDTOList.length === 0) {
      this.initialBranchId = 0;
      this.tableForm.get('branch').setValue(0);


    } else {
      this.initialBranchId = userData.branchResponse.branchDTOList[0].branchCode;

      localStorage.setItem('branchId', this.initialBranchId.toString());
      this.tableForm.get('branch').setValue(this.initialBranchId);

    }

    if (userData.categoryResponse.categoryList[0].id === 4) {
      this.tableForm.get('branch').setValue(this.initialBranchId);
    } else {
      this.tableForm.get('branch').setValue(0);
    }

    if (this.initialCategoryId === 0) {
      this.newinitialCategoryId = 1;
    } else {
      this.newinitialCategoryId = this.initialCategoryId;
    }
  }


  get f() {
    return this.tableForm.controls;
  }


  patchValues(param: any) {
    if (Object.keys(param.categoryResponse.categoryList).length > 0) {
      if (this.categoryStatus) {
        this.tableForm.controls.category.setValue(
          param.categoryResponse.categoryList[0].id
        );
      }
    }

    if (Object.keys(param.zoneResponse.zoneDTOList).length > 0) {
      this.tableForm.controls.zone.setValue(
        param.zoneResponse.zoneDTOList[0].zoneId
      );
    }

    if (Object.keys(param.regionResponse.regionDTOList).length > 0) {
      if (!this.zoneStatus) {
        this.tableForm.controls.region.setValue(
          param.regionResponse.regionDTOList[0].regionId
        );
      } else if (this.regionStatus) {
        this.tableForm.controls.region.setValue(
          param.regionResponse.regionDTOList[0].regionId
        );
      }
    }

    if (Object.keys(param.branchResponse.branchDTOList).length > 0) {
      if (!this.regionStatus) {
        this.tableForm.controls.branch.setValue(
          param.branchResponse.branchDTOList[0].branchCode
        );
      } else if (this.branchStatus) {
        this.tableForm.controls.branch.setValue(
          param.branchResponse.branchDTOList[0].branchCode
        );
      }
    }
  }


  async getZoneList() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAllZones(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getBranchList() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAllBranches(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getRegionList() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAllRegions(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getRegionListByZone(zoneId: number) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getRegionListByZone(zoneId, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getBranchListByRegion(regionId: number) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getBranchesByRegion(regionId, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getPromotionDemotionDetails() {

    this.tableStatus = 'REJECTED';

    this.formListObj = await this.getTableDetails().catch((error) => {
      console.log(error);
    });

    if (this.formListObj.status === 200) {

      this.formList = this.formListObj.data.map((item, index) => {
        return {...item, sequenceNumber: index + 1};
      });
    }

    this.dataSource = new MatTableDataSource(this.formList);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  async getTableDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getPromotionDemotionDetailsByFilter(this.tableStatus, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
