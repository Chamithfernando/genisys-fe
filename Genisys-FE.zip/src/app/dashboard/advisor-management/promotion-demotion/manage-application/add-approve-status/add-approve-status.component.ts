import {Component, OnInit, Inject} from '@angular/core';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {validateEnterSpecialCharacters} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {
  showErrorMessage,
  showSucessMessage,
  NOT_APPROVE_REASON,
  TERMINATION_REASON,
  Selector,
  CODE_TRANSFER_NOT_APPROVE_REASON,
  POLICY_TRANSFER_NOT_APPROVE_REASON,
  BRANCH_TRANSFER_NOT_APPROVE_REASON,
  INCOME_SERVICE_REASON,
  formatNumber
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {Router} from '@angular/router';
import {DecimalPipe} from '@angular/common';

@Component({
  selector: 'app-add-approve-status',
  templateUrl: './add-approve-status.component.html',
  styleUrls: ['./add-approve-status.component.scss']
})
export class AddApproveStatusComponent implements OnInit {

  statusForm: FormGroup;
  rejectClicked = false;
  userDetails: any;
  roleName: string;
  formTitle: string;
  requestType: string;
  letterStatus: string;
  dueAmount: string;
  level: number;
  approvedClicked = false;
  notApprovedClicked = false;
  isOtherSelected = true;
  selector: Selector[];
  selectorCodeTransfer: Selector[];
  selectorTermination: Selector[];
  selectorPolicyTransfer: Selector[];
  selectorBranchTransfer: Selector[];
  selectorIncomeTransfer: Selector[];

  constructor(public dialogRef: MatDialogRef<AddApproveStatusComponent>,
              private formBuilder: FormBuilder,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              private router: Router,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private decimalPipe: DecimalPipe) {

    this.statusForm = this.formBuilder.group({
      rejectReason: new FormControl(''),
      dueAmount: new FormControl('')
    });

    this.selector = NOT_APPROVE_REASON;
    this.selectorCodeTransfer = CODE_TRANSFER_NOT_APPROVE_REASON;
    this.selectorTermination = TERMINATION_REASON;
    this.selectorPolicyTransfer = POLICY_TRANSFER_NOT_APPROVE_REASON;
    this.selectorBranchTransfer = BRANCH_TRANSFER_NOT_APPROVE_REASON;
    this.selectorIncomeTransfer = INCOME_SERVICE_REASON;
  }

  ngOnInit(): void {
    this.formTitle = this.data.formTitle;
    this.letterStatus = this.data.letterStatus;
    this.dueAmount = formatNumber(this.data.dueAmount, this.decimalPipe);
    this.requestType = this.data.typeOfRequest;

    this.getLoginUser();
  }

  validateEnterSpecialCharacters(event: Event) {
    validateEnterSpecialCharacters(event);
  }

  onApprovedClick() {
    this.approvedClicked = true;
  }

  onNotApprovedClick() {
    this.notApprovedClicked = true;
  }

  onRejectClick() {
    this.rejectClicked = true;
  }

  onCheckboxChange(){
    this.isOtherSelected = false;
    this.statusForm.get('rejectReason').setValue('');

  }

  cancel() {
    this.approvedClicked = false;
    this.rejectClicked = false;
    this.notApprovedClicked = false;
    this.isOtherSelected = true;
    this.statusForm.reset();
  }


  async getLoginUser() {
    this.userDetails = await this.getUserDetails().catch((error) => {
      console.log(error);
    });

    if (this.userDetails.status === 'OK') {
      this.roleName = this.userDetails.data.roleDto.roleName;
      if (['Branch Manager'].includes(this.roleName)) {

        if (this.data.formTitle === 'policyTransfer') {
          this.level = this.requestType === 'false' ? 1 : 4;

        } else if (this.data.formTitle === 'branchTransfer'){
          this.level = this.requestType === 'false' ? 1 : 3;

        } else {
          this.level = 1;
        }

      } else if (['Zonal Manager'].includes(this.roleName)) {

        if (this.data.formTitle === 'policyTransfer') {
          this.level = this.requestType === 'false' ? 2 : 5;

        } else if (this.data.formTitle === 'branchTransfer'){
          this.level = this.requestType === 'false' ? 2 : 4;

        } else {
          this.level = 2;
        }

      } else if (['SFA'].includes(this.roleName)) {

        if (this.data.formTitle === 'branchTransfer'){
          this.level = 5;

        } else {
          this.level = 3;
        }

      }
    }
  }

  validate(decision: string) {

    console.log('decision', decision);
    if (decision === 'APPROVED' && !this.statusForm.value.rejectReason.toString().trim()) {
      showErrorMessage('Approve Reason is Required');
      return false;
    }

    if (decision === 'REJECTED' && !this.statusForm.value.rejectReason.toString().trim()) {
      showErrorMessage('Reject Reason is Required');
      return false;
    }

    if (decision === 'NOT_APPROVED' && (!this.statusForm.value.rejectReason || !this.statusForm.value.rejectReason.toString().trim())) {
      showErrorMessage('Not Approved Reason is Required');
      return false;
    }
    return true;
  }

  async getUserDetails() {
    return new Promise((resolve, reject) => {

      this.authService
        .getPermission()
        .subscribe(
          (res: any) => {
            resolve(res);
          },
          (err: any) => {
            reject(err);
          }
        );
    });
  }

  async save(decisionStatus: string) {
    if (this.validate(decisionStatus)) {

      const dueAmount = this.statusForm.value.dueAmount;
      const cleanedDueAmount = (dueAmount != null) ? String(dueAmount).replace(/,/g, '') : '';
      const outstandingDue = isNaN(+cleanedDueAmount) ? '0' : parseFloat(cleanedDueAmount).toFixed(2);
      const finalOutstandingDue = parseFloat(outstandingDue);

      const data = {
        id: this.data.id,
        level: this.level,
        decision: decisionStatus,
        outstandingAmt: finalOutstandingDue,
        remarks: this.statusForm.value.rejectReason
      };

      console.log('data', data);

      if (this.data.formTitle === 'designation') {
        const saveResponse: any = await this.saveStatus(data).catch(
          (err) => {
            console.log(err);
          }
        );

        if (saveResponse.status === 201) {
          showSucessMessage(saveResponse.message);
          this.dialogRef.close(true);

          this.router.navigate([
            '/dashboard/advisor-management/view-applications-table',
          ]);
        } else {
          showErrorMessage(saveResponse.payload.message);
          this.statusForm.get('rejectReason').reset();
        }
      } else if (this.data.formTitle === 'transfer') {
        const saveResponse: any = await this.saveTransferStatus(data).catch(
          (err) => {
            console.log(err);
          }
        );

        if (saveResponse.status === 201) {
          showSucessMessage(saveResponse.message);
          this.dialogRef.close(true);

          this.router.navigate([
            '/dashboard/advisor-management/all-transfer-table',
          ]);
        } else {
          showErrorMessage(saveResponse.payload.message);
          this.statusForm.get('rejectReason').reset();
        }
      } else if (this.data.formTitle === 'termination') {
        const saveResponse: any = await this.saveTerminationStatus(data).catch(
          (err) => {
            console.log(err);
          }
        );

        if (saveResponse.status === 200) {
          showSucessMessage(saveResponse.message);
          this.dialogRef.close(true);

          this.router.navigate([
            '/dashboard/advisor-management/all-termination-table',
          ]);
        } else {
          showErrorMessage(saveResponse.payload.message);
          this.statusForm.get('rejectReason').reset();
        }
      } else if (this.data.formTitle === 'policyTransfer') {
        const saveResponse: any = await this.savePolicyTransferStatus(data).catch(
          (err) => {
            console.log(err);
          }
        );

        if (saveResponse.status === 201) {
          showSucessMessage(saveResponse.message);
          this.dialogRef.close(true);

          this.router.navigate([
            '/dashboard/advisor-management/all-policy-transfer-table',
          ]);
        } else {
          showErrorMessage(saveResponse.payload.message);
          this.statusForm.get('rejectReason').reset();
        }
      } else if (this.data.formTitle === 'branchTransfer') {
        const saveResponse: any = await this.saveBranchTransferStatus(data).catch(
          (err) => {
            console.log(err);
          }
        );

        if (saveResponse.status === 201) {
          showSucessMessage(saveResponse.message);
          this.dialogRef.close(true);

          this.router.navigate([
            '/dashboard/advisor-management/all-branch-transfer-table',
          ]);
        } else {
          showErrorMessage(saveResponse.payload.message);
          this.statusForm.get('rejectReason').reset();
        }
      }else if (this.data.formTitle === 'incomeServiceLetter') {
        const saveResponse: any = await this.saveIncomeServiceStatus(data).catch(
          (err) => {
            console.log(err);
          }
        );

        if (saveResponse.status === 201) {
          showSucessMessage(saveResponse.message);
          this.dialogRef.close(true);

          this.router.navigate([
            '/dashboard/advisor-management/all-income-service-table',
          ]);
        } else {
          showErrorMessage(saveResponse.payload.message);
          this.statusForm.get('rejectReason').reset();
        }
      }
    }
  }

  saveStatus(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .submitApproveStatus(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  saveTransferStatus(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .submitTransferApproveStatus(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


  saveTerminationStatus(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .submitTerminationApproveStatus(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  savePolicyTransferStatus(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .submitPolicyTransferApproveStatus(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  saveBranchTransferStatus(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .submitBranchTransferApproveStatus(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  saveIncomeServiceStatus(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .submitIncomeServiceApproveStatus(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
