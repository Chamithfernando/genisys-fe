import {Component, Inject, OnInit} from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {showErrorMessage, showSucessMessage} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';

@Component({
  selector: 'app-remove-record',
  templateUrl: './remove-record.component.html',
  styleUrls: ['./remove-record.component.scss']
})
export class RemoveRecordComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<RemoveRecordComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private advisorService: AdvisorManagementService) {
  }

  ngOnInit(): void {
  }

  async deleteDraft() {
    let deleteResponse: any;
    let deleteFunction: () => Promise<any>;

    if (this.data.formTitle === 'designation') {
      deleteFunction = this.designationFileDelete.bind(this);
    } else if (this.data.formTitle === 'transfer') {
      deleteFunction = this.transferFileDelete.bind(this);
    } else if (this.data.formTitle === 'termination') {
      deleteFunction = this.terminationFileDelete.bind(this);
    } else if (this.data.formTitle === 'policyTransfer') {
      deleteFunction = this.policyTransferFileDelete.bind(this);
    } else if (this.data.formTitle === 'branchTransfer') {
      deleteFunction = this.branchTransferFileDelete.bind(this);
    } else if (this.data.formTitle === 'income_service') {
      deleteFunction = this.incomeServiceFileDelete.bind(this);
    }

    if (deleteFunction) {
      deleteResponse = await deleteFunction().catch(err => {
        console.log(err);
      });

      if (deleteResponse && deleteResponse.status === 200) {
        showSucessMessage(deleteResponse.message);
      } else if (deleteResponse) {
        showErrorMessage(deleteResponse.message);
      }
    }

    this.dialogRef.close(true);
  }



  designationFileDelete() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .deleteRecord(this.data.id)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


  transferFileDelete() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .transferDeleteRecord(this.data.id)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  terminationFileDelete() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .terminationDeleteRecord(this.data.id)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  policyTransferFileDelete() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .policyTransferDeleteRecord(this.data.id)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  branchTransferFileDelete() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .branchTransferDeleteRecord(this.data.id)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  incomeServiceFileDelete() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .incomeServiceDeleteRecord(this.data.id)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  // async deleteDraft() {
  //
  //   if (this.data.formTitle === 'designation') {
  //     const deleteResponse: any = await this.designationFileDelete().catch(
  //       (err) => {
  //         console.log(err);
  //       }
  //     );
  //
  //     if (deleteResponse.status === 200) {
  //       showSucessMessage(deleteResponse.message);
  //       this.dialogRef.close(true);
  //     } else {
  //       showErrorMessage(deleteResponse.message);
  //       this.dialogRef.close(true);
  //     }
  //   } else if (this.data.formTitle === 'transfer') {
  //     const deleteResponse: any = await this.transferFileDelete().catch(
  //       (err) => {
  //         console.log(err);
  //       }
  //     );
  //
  //     if (deleteResponse.status === 200) {
  //       showSucessMessage(deleteResponse.message);
  //       this.dialogRef.close(true);
  //     } else {
  //       showErrorMessage(deleteResponse.message);
  //       this.dialogRef.close(true);
  //     }
  //   } else if (this.data.formTitle === 'termination') {
  //     const deleteResponse: any = await this.terminationFileDelete().catch(
  //       (err) => {
  //         console.log(err);
  //       }
  //     );
  //
  //     if (deleteResponse.status === 200) {
  //       showSucessMessage(deleteResponse.message);
  //       this.dialogRef.close(true);
  //     } else {
  //       showErrorMessage(deleteResponse.message);
  //       this.dialogRef.close(true);
  //     }
  //   } else if (this.data.formTitle === 'policyTransfer') {
  //     const deleteResponse: any = await this.policyTransferFileDelete().catch(
  //       (err) => {
  //         console.log(err);
  //       }
  //     );
  //
  //     if (deleteResponse.status === 200) {
  //       showSucessMessage(deleteResponse.message);
  //       this.dialogRef.close(true);
  //     } else {
  //       showErrorMessage(deleteResponse.message);
  //       this.dialogRef.close(true);
  //     }
  //   }else if (this.data.formTitle === 'branchTransfer') {
  //     const deleteResponse: any = await this.branchTransferFileDelete().catch(
  //       (err) => {
  //         console.log(err);
  //       }
  //     );
  //
  //     if (deleteResponse.status === 200) {
  //       showSucessMessage(deleteResponse.message);
  //       this.dialogRef.close(true);
  //     } else {
  //       showErrorMessage(deleteResponse.message);
  //       this.dialogRef.close(true);
  //     }
  //   }else if (this.data.formTitle === 'income_service') {
  //     const deleteResponse: any = await this.incomeServiceFileDelete().catch(
  //       (err) => {
  //         console.log(err);
  //       }
  //     );
  //
  //     if (deleteResponse.status === 200) {
  //       showSucessMessage(deleteResponse.message);
  //       this.dialogRef.close(true);
  //     } else {
  //       showErrorMessage(deleteResponse.message);
  //       this.dialogRef.close(true);
  //     }
  //   }
  //
  // }

}
