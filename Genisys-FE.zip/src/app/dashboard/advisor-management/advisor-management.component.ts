import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advisor-management',
  templateUrl: './advisor-management.component.html',
  styleUrls: ['./advisor-management.component.scss']
})
export class AdvisorManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
