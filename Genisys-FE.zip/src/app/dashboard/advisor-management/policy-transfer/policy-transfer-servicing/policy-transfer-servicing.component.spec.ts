import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyTransferServicingComponent } from './policy-transfer-servicing.component';

describe('PolicyTransferServicingComponent', () => {
  let component: PolicyTransferServicingComponent;
  let fixture: ComponentFixture<PolicyTransferServicingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PolicyTransferServicingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PolicyTransferServicingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
