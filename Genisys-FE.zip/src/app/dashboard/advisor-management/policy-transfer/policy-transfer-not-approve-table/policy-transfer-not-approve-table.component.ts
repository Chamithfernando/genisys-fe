import { Component, OnInit, ViewChild } from '@angular/core';
import {
  applyFilter,
  PolicyType,
  TYPE_OF_POLICY
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {validateEnterSpecialCharacters} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {ActivatedRoute, Router} from '@angular/router';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {
  PolicyTransferApprovalLevelsComponent
} from '@app/dashboard/advisor-management/policy-transfer/policy-transfer-approval-levels/policy-transfer-approval-levels.component';
import {
  PolicyTransferRejectReasonComponent
} from '@app/dashboard/advisor-management/policy-transfer/policy-transfer-reject-reason/policy-transfer-reject-reason.component';


@Component({
  selector: 'app-policy-transfer-not-approve-table',
  templateUrl: './policy-transfer-not-approve-table.component.html',
  styleUrls: ['./policy-transfer-not-approve-table.component.scss']
})
export class PolicyTransferNotApproveTableComponent implements OnInit {

  tableStatus: string;
  formListObj: any;
  userDetails: any;
  hideZmSfaFeatures = false;
  hideSFAFeatures = false;
  policyRequestType = false;

  policyType: PolicyType[];
  formList: Array<any> = [];
  dialogRef: MatDialogRef<any>;

  displayedColumns: string[] = ['sequenceNumber', 'id', 'agentName', 'branchName', 'newAgentName', 'newBranchName', 'policyNo', 'effectiveDate',
    'reason', 'action', 'approveLevels'];

  dataSource = new MatTableDataSource();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private router: Router,
              private route: ActivatedRoute,
              private authService: AuthService,
              private advisorService: AdvisorManagementService,
              private dialog: MatDialog) {
    this.policyType = TYPE_OF_POLICY;
  }

  async ngOnInit(): Promise<void> {

    await this.getLoginUser();

    this.policyRequestType = true;
    await this.getPolicyTransferDetails(this.policyRequestType);
  }

  async getLoginUser() {
    this.userDetails = await this.getUserDetails().catch((error) => {
      console.log(error);
    });

    if (this.userDetails.status === 'OK') {
      const roleName = this.userDetails.data.roleDto.roleName;
      if (['Zonal Manager', 'SFA'].includes(roleName)) {
        this.hideZmSfaFeatures = true;
      }

      if (['SFA'].includes(roleName)) {
        this.hideSFAFeatures = true;
      }
    }
  }

  async getUserDetails() {
    return new Promise((resolve, reject) => {

      this.authService
        .getPermission()
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


  applyFilter(event: Event) {
    applyFilter(this.dataSource, event);
  }

  validateEnterSpecialCharacters(event: Event) {
    validateEnterSpecialCharacters(event);
  }


  rejectApplication(e: any, element: number) {
    const rejectDetails = {
      id: element,
      title: 'notApproved'
    };

    this.dialogRef = this.dialog.open(PolicyTransferRejectReasonComponent, {
      width: '600px',
      data: rejectDetails,
    });
  }

  editApplication(e: any, element: number) {
    this.router.navigate(['../policy-transfer-edit-form'], {
      relativeTo: this.route,
      queryParams: {
        formId : element,
        formStatus : 'notapprove'
      }
    });
  }

  openApprovalLevels(e: any, element: number) {
    this.dialogRef = this.dialog.open(PolicyTransferApprovalLevelsComponent, {
      width: '600px',
      data: element
    });
  }



  async getPolicyTransferDetails(isPolicyType: boolean) {

    this.tableStatus = 'NOT_APPROVED';
    this.policyRequestType = isPolicyType;

    this.formListObj = await this.getTableDetails().catch((error) => {
      console.log(error);
    });

    if (this.formListObj.status === 200) {

      this.formList = this.formListObj.data.map((item, index) => {
        return { ...item, sequenceNumber: index + 1 };
      });
    }

    this.dataSource = new MatTableDataSource(this.formList);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  async getTableDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getPolicyTransferDetailsByFilter(this.tableStatus,  this.policyRequestType, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
