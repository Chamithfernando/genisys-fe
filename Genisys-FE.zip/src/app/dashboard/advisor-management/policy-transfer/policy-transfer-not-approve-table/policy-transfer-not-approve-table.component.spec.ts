import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyTransferNotApproveTableComponent } from './policy-transfer-not-approve-table.component';

describe('PolicyTransferNotApproveTableComponent', () => {
  let component: PolicyTransferNotApproveTableComponent;
  let fixture: ComponentFixture<PolicyTransferNotApproveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PolicyTransferNotApproveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicyTransferNotApproveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
