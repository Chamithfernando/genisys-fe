import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyTransferDraftTableComponent } from './policy-transfer-draft-table.component';

describe('PolicyTransferDraftTableComponent', () => {
  let component: PolicyTransferDraftTableComponent;
  let fixture: ComponentFixture<PolicyTransferDraftTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PolicyTransferDraftTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicyTransferDraftTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
