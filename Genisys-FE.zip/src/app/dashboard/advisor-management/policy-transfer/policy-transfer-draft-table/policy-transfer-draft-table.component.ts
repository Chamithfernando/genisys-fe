import { Component, OnInit, ViewChild } from '@angular/core';
import {applyFilter} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {validateEnterSpecialCharacters} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {ActivatedRoute, Router} from '@angular/router';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {
  RemoveRecordComponent
} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/remove-record/remove-record.component';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';


@Component({
  selector: 'app-policy-transfer-draft-table',
  templateUrl: './policy-transfer-draft-table.component.html',
  styleUrls: ['./policy-transfer-draft-table.component.scss']
})
export class PolicyTransferDraftTableComponent implements OnInit {

  tableStatus: string;
  formListObj: any;
  policyRequestType = false;
  formList: Array<any> = [];
  dialogRef: MatDialogRef<any>;

  displayedColumns: string[] = ['sequenceNumber', 'id', 'agentName', 'branchName', 'newAgentName', 'newBranchName', 'policyNo', 'effectiveDate',
    'action', 'remove'];

  dataSource = new MatTableDataSource();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private router: Router,
              private route: ActivatedRoute,
              private authService: AuthService,
              private advisorService: AdvisorManagementService,
              private dialog: MatDialog) { }

  ngOnInit(): void {
    this.getPolicyTransferDetails();
  }

  applyFilter(event: Event) {
    applyFilter(this.dataSource, event);
  }

  validateEnterSpecialCharacters(event: Event) {
    validateEnterSpecialCharacters(event);
  }

  editApplication(e: any, element: number) {
    this.router.navigate(['../policy-transfer-edit-form'], {
      relativeTo: this.route,
      queryParams: {
        formId : element
      }
    });
  }

  removeApplication(e: any, formId: number) {

    const elements = {
      id: formId,
      formTitle: 'policyTransfer'
    };

    this.dialogRef = this.dialog.open(RemoveRecordComponent, {
      width: '600px',
      data: elements
    });

    this.dialogRef.afterClosed().subscribe((response) => {
      if (response) {
        this.dialogRef.close(true);
        this.getPolicyTransferDetails();
      }
    });
  }

  async getPolicyTransferDetails() {

    this.tableStatus = 'DRAFT';
    this.policyRequestType = false;

    this.formListObj = await this.getTableDetails().catch((error) => {
      console.log(error);
    });

    if (this.formListObj.status === 200) {

      this.formList = this.formListObj.data.map((item, index) => {
        return { ...item, sequenceNumber: index + 1 };
      });
    }

    this.dataSource = new MatTableDataSource(this.formList);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  async getTableDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getPolicyTransferDetailsByFilter(this.tableStatus, this.policyRequestType, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
