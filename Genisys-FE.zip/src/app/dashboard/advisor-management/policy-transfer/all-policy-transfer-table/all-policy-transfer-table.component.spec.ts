import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllPolicyTransferTableComponent } from './all-policy-transfer-table.component';

describe('AllPolicyTransferTableComponent', () => {
  let component: AllPolicyTransferTableComponent;
  let fixture: ComponentFixture<AllPolicyTransferTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllPolicyTransferTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AllPolicyTransferTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
