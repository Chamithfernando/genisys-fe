import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyTransferSummaryTableComponent } from './policy-transfer-summary-table.component';

describe('PolicyTransferSummaryTableComponent', () => {
  let component: PolicyTransferSummaryTableComponent;
  let fixture: ComponentFixture<PolicyTransferSummaryTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PolicyTransferSummaryTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicyTransferSummaryTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
