import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {ActivatedRoute, Router} from '@angular/router';
import {
  IMS_REMARK_OPTIONS,
  Selector,
  SELECTOR_OPTIONS,
  showErrorMessage, showSucessMessage
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {
  AddApproveStatusComponent
} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/add-approve-status/add-approve-status.component';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {OpenPdfComponent} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/open-pdf/open-pdf.component';
import {formatDate} from '@angular/common';

@Component({
  selector: 'app-policy-transfer-approve-form',
  templateUrl: './policy-transfer-approve-form.component.html',
  styleUrls: ['./policy-transfer-approve-form.component.scss']
})
export class PolicyTransferApproveFormComponent implements OnInit {

  policyForm: FormGroup;
  dialogRef: MatDialogRef<any>;
  branchId: string;
  formId: number;
  formStatus: string;
  uploadFile: string;
  formObj: any;
  isDisabled = false;
  requestType: boolean;

  imsRemark: Selector[];
  branchArray: Array<any> = [];
  agentsArray: Array<any> = [];

  @ViewChild('fileInput') fileInput: ElementRef<HTMLInputElement>;

  constructor(private formBuilder: FormBuilder,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              private router: Router,
              private route: ActivatedRoute,
              private dialog: MatDialog) {

    this.policyForm = this.formBuilder.group({
      policyNo: new FormControl('', [Validators.required]),
      branch: new FormControl('', [Validators.required]),
      agentCode: new FormControl('', [Validators.required]),
      newBranch: new FormControl('', [Validators.required]),
      newAgentCode: new FormControl('', [Validators.required]),
      reason: new FormControl('', [Validators.required]),
      effectiveDate: new FormControl('', [Validators.required]),
      ImsRemark: new FormControl('')
    });

    this.imsRemark = IMS_REMARK_OPTIONS;
  }



  async ngOnInit(): Promise<void> {
    this.route.queryParams.subscribe(params => {
      this.formId = (params.formId);
      this.formStatus = (params.formStatus);
      this.requestType = (params.requestType);

    });
    try {
      await Promise.all([this.allBranches(), this.getPolicyTransferDetails()]);
    } catch (error) {
      console.error(error);
    }
  }

  openApproveStatus() {
    const elements = {
      id: this.formId,
      formTitle: 'policyTransfer',
      typeOfRequest: this.requestType
    };

    this.dialogRef = this.dialog.open(AddApproveStatusComponent, {
      width: '600px',
      disableClose: true,
      data: elements,
    });

  }

  openLetterPdf(){

    const details = {
      id: this.formId,
      title: 'policyTransferUploadFile'
    };

    this.dialogRef = this.dialog.open(OpenPdfComponent, {
      width: '1150px',
      data: details
    });
  }

  async allBranches() {
    const branchList: any = await this.getBranchList().catch((error) => {
      console.log(error);
    });
    if (branchList.status === 200) {
      this.branchArray = branchList.payload.sort((a, b) => a.branchName.localeCompare(b.branchName));
      this.isDisabled = true;
    }
  }

  async getBranchList() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAllBranches(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async allAgentsByBranch() {
    const agentsList: any = await this.getAgentsDetails().catch((error) => {
      console.log(error);
    });
    if (agentsList.status === 200) {
      this.agentsArray = agentsList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));
    }
  }

  async getAgentsDetails() {

    const branchCode = +this.branchId;

    return new Promise((resolve, reject) => {
      this.advisorService
        .getAgentsbyBranch(branchCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getPolicyTransferDetails() {

    this.formObj = await this.getFormDetails().catch((error) => {
      console.log(error);
    });

    if (this.formObj.status === 200) {
      this.branchId = this.formObj.data.newBranchCode;
      await this.allAgentsByBranch();

      let requestingDate = '';
      if (this.formObj.data.effectiveDate) {
        const trimmedPeriodOfRequestingDate = this.formObj.data.effectiveDate.substring(0, 10);
        if (trimmedPeriodOfRequestingDate !== '1970-01-01') {
          requestingDate = formatDate(trimmedPeriodOfRequestingDate, 'yyyy-MM-dd', 'en-US');
        }
      }

      this.policyForm.patchValue({
        policyNo: this.formObj.data.policyNo,
        branch: this.formObj.data.branchCode?.toString() ?? '',
        agentCode: this.formObj.data.agentName,
        newBranch: this.formObj.data.newBranchCode?.toString() ?? '',
        newAgentCode: this.formObj.data.newAgentName,
        reason: this.formObj.data.reasonForPolicyTransfer,
        effectiveDate: requestingDate
      });

      this.uploadFile = this.formObj.data.hasPolicyTransferFile;

    }
  }

  async getFormDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .policyTransferDetailsGetById(this.formId)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


  validate() {

    const validationRules = [
      {field: 'ImsRemark', message: 'Please Update IMS Status.'},
    ];

    for (const rule of validationRules) {
      if (!this.policyForm.value[rule.field]) {
        showErrorMessage(rule.message);
        return false;
      }
    }

    return true;
  }

  async saveImsRemark() {
    if (this.validate()) {

      const data = {
        id:  this.formId,
        remark: this.policyForm.value.ImsRemark,
      };

      const saveResponse: any = await this.updateRemark(data).catch(
        (err) => {
          console.log(err);
        }
      );

      if (saveResponse.status === 200) {
        showSucessMessage(saveResponse.message);
        this.router.navigate(['/dashboard/advisor-management/policy-transfer-servicing']);
      } else {
        showErrorMessage(saveResponse.payload.message);
      }

    }
  }

  updateRemark(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .updatePolicyServicingRemark(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
