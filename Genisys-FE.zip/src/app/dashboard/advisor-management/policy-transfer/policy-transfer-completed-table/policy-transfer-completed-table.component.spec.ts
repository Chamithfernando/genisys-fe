import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyTransferCompletedTableComponent } from './policy-transfer-completed-table.component';

describe('PolicyTransferCompletedTableComponent', () => {
  let component: PolicyTransferCompletedTableComponent;
  let fixture: ComponentFixture<PolicyTransferCompletedTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PolicyTransferCompletedTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicyTransferCompletedTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
