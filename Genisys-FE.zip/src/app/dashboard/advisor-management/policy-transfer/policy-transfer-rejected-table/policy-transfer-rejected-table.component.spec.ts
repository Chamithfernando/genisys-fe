import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyTransferRejectedTableComponent } from './policy-transfer-rejected-table.component';

describe('PolicyTransferRejectedTableComponent', () => {
  let component: PolicyTransferRejectedTableComponent;
  let fixture: ComponentFixture<PolicyTransferRejectedTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PolicyTransferRejectedTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicyTransferRejectedTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
