import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyTransferRejectReasonComponent } from './policy-transfer-reject-reason.component';

describe('PolicyTransferRejectReasonComponent', () => {
  let component: PolicyTransferRejectReasonComponent;
  let fixture: ComponentFixture<PolicyTransferRejectReasonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PolicyTransferRejectReasonComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PolicyTransferRejectReasonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
