import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyTransferApprovalLevelsComponent } from './policy-transfer-approval-levels.component';

describe('PolicyTransferApprovalLevelsComponent', () => {
  let component: PolicyTransferApprovalLevelsComponent;
  let fixture: ComponentFixture<PolicyTransferApprovalLevelsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PolicyTransferApprovalLevelsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PolicyTransferApprovalLevelsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
