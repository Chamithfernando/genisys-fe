import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyTransferApproveTableComponent } from './policy-transfer-approve-table.component';

describe('PolicyTransferApproveTableComponent', () => {
  let component: PolicyTransferApproveTableComponent;
  let fixture: ComponentFixture<PolicyTransferApproveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PolicyTransferApproveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicyTransferApproveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
