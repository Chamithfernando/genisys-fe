import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyTransferFormComponent } from './policy-transfer-form.component';

describe('PolicyTransferFormComponent', () => {
  let component: PolicyTransferFormComponent;
  let fixture: ComponentFixture<PolicyTransferFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PolicyTransferFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicyTransferFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
