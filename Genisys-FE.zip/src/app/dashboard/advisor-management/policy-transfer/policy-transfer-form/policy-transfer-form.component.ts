import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {ActivatedRoute, Router} from '@angular/router';
import {
  showErrorMessage, showSucessMessage,
  showWarningMessage
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {formatDate} from '@angular/common';


@Component({
  selector: 'app-policy-transfer-form',
  templateUrl: './policy-transfer-form.component.html',
  styleUrls: ['./policy-transfer-form.component.scss']
})
export class PolicyTransferFormComponent implements OnInit {

  policyForm: FormGroup;

  branchId: string;
  fileToUpload: File;
  letterUrl: string;
  selectedFileName: string;
  policyNo: string;
  policyObj: any;
  currentDate: Date = new Date();
  isDisable = false;

  branchArray: Array<any> = [];
  agentsArray: Array<any> = [];

  @ViewChild('fileInput') fileInput: ElementRef<HTMLInputElement>;

  constructor(private formBuilder: FormBuilder,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              private router: Router,
              private route: ActivatedRoute) {

    this.policyForm = this.formBuilder.group({
      policyNo: ['', [
        Validators.required,
        Validators.pattern(/^[A-Za-z]{3}\/\d{1,7}$/)
      ]],
      branch: new FormControl('', [Validators.required]),
      agentCode: new FormControl('', [Validators.required]),
      newBranch: new FormControl('', [Validators.required]),
      newAgentCode: new FormControl('', [Validators.required]),
      reason: new FormControl('', [Validators.required]),
      effectiveDate: new FormControl('', [Validators.required]),
    });
  }


  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.branchId = (params.branchCode);
    });

    this.allBranches();
  }

  onPolicyNumberInput(event: any) {

    let input = event.target.value.toUpperCase();

    input = input.replace(/[^A-Z0-9]/g, '');


    const letters = input.substring(0, 3);
    const numbers = input.substring(3);

    const formattedLetters = letters.replace(/[^A-Z]/g, '');

    const formattedNumbers = numbers.substring(0, 7).replace(/[^0-9]/g, '');


    let formattedInput = formattedLetters;
    if (formattedNumbers.length > 0) {
      formattedInput += '/' + formattedNumbers;
    }

    if (formattedInput.length > 11) {
      formattedInput = formattedInput.substring(0, 11);
    }

    event.target.value = formattedInput;
    this.policyForm.patchValue({policyNo: formattedInput});

    if (formattedInput.length < 11) {
      this.clearFields();
    }
  }

  clearFields() {
    const policyNo = this.policyForm.get('policyNo')?.value;

    if (!policyNo || policyNo.trim().length < 10) {
      this.policyForm.get('branch')?.reset();
      this.policyForm.get('agentCode')?.reset();
      this.policyForm.get('newBranch')?.reset();
      this.policyForm.get('newAgentCode')?.reset();
      this.policyForm.get('reason')?.reset();
      this.policyForm.get('effectiveDate')?.reset();
      this.selectedFileName = '';


      if (this.fileInput && this.fileInput.nativeElement) {
        this.fileInput.nativeElement.value = '';
      }
    }
  }



  async validatePolicyNo() {

    this.policyNo = this.policyForm.value.policyNo;

    if (!this.policyNo ){
      showWarningMessage('Please Enter Policy No');
    } else {

      this.policyObj = await this.policyNoDetails().catch((error) => {
        console.log(error);
      });

      if (this.policyObj.status === 200) {

        if (this.policyObj.data.branchCode.toString() !== this.branchId) {
          showWarningMessage('This policy is not allocated to your branch');
        } else {
          this.policyForm.patchValue({
            agentCode: this.policyObj.data.agent,
            branch: this.policyObj.data.branchCode.toString()
          });
        }

      } else {
        showWarningMessage(this.policyObj.payload.message);
        this.clear();
      }
    }


  }

  async policyNoDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .validatePolicyNo(this.policyNo)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async allBranches() {
    const branchList: any = await this.getBranchList().catch((error) => {
      console.log(error);
    });
    if (branchList.status === 200) {
      this.branchArray = branchList.payload.sort((a, b) => a.branchName.localeCompare(b.branchName));
      this.isDisable = true;
    }
  }

  async getBranchList() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAllBranches(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async allAgentsByBranch() {
    const agentsList: any = await this.getAgentsDetails().catch((error) => {
      console.log(error);
    });
    if (agentsList.status === 200) {

      if (agentsList.data && agentsList.data.length > 0) {
        this.agentsArray = agentsList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));
      } else {
        showWarningMessage('No Agents in this Branch');
        this.policyForm.get('newAgentCode').setValue('');
        this.agentsArray = [];
      }

    }
  }

  async getAgentsDetails() {

    const branchCode = +this.policyForm.value.newBranch;

    return new Promise((resolve, reject) => {
      this.advisorService
        .getAgentsbyBranch(branchCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  fileUpload() {
    this.fileInput.nativeElement.click();
  }

  onFileSelected(event: any) {

    const file: File = event.target.files[0];
    if (file) {
      const fileType = this.getFileType(file);
      if (fileType === 'pdf') {
        this.fileToUpload = file;
        this.convertToBase64(file);
        this.selectedFileName = file.name;


      } else {
        showWarningMessage('Invalid file type. Please upload a pdf file.');
        this.fileInput.nativeElement.value = '';
      }
    } else {
      this.fileToUpload = null;
      this.selectedFileName = '';
    }

  }

  convertToBase64(file: File) {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const base64String = reader.result as string;
      const base64WithoutPath = base64String.split(',')[1];
      this.letterUrl = base64WithoutPath;
    };
    reader.onerror = (error) => {
      console.error('Error: ', error);
    };
  }

  getFileType(file: File): string {
    const fileName = file.name.toLowerCase();
    if (fileName.endsWith('.pdf')) {
      return 'pdf';
    } else {
      return '';
    }
  }

  clear() {
    const controlsToClear = [
      'policyNo',
      'branch',
      'agentCode',
      'newBranch',
      'newAgentCode',
      'reason',
      'effectiveDate',
    ];

    controlsToClear.forEach(controlName => {
      this.policyForm.get(controlName).setValue('');
      this.policyForm.get(controlName).clearValidators();
      this.policyForm.get(controlName).updateValueAndValidity();
    });

    this.policyForm.get('policyNo').setValidators([Validators.required]);
    this.policyForm.get('branch').setValidators([Validators.required]);
    this.policyForm.get('agentCode').setValidators([Validators.required]);
    this.policyForm.get('newBranch').setValidators([Validators.required]);
    this.policyForm.get('newAgentCode').setValidators([Validators.required]);
    this.policyForm.get('reason').setValidators([Validators.required]);
    this.policyForm.get('effectiveDate').setValidators([Validators.required]);


    this.policyForm.updateValueAndValidity();

    if (this.fileInput && this.fileInput.nativeElement) {
      this.fileInput.nativeElement.value = '';
    }

    this.selectedFileName = '';

  }

  validate() {

    const validationRules = [
      {field: 'policyNo', message: 'Policy No is Required.'},
      {field: 'branch', message: 'Branch is Required.'},
      {field: 'agentCode', message: 'Agent is Required.'},
      {field: 'newBranch', message: 'New Branch is Required.'},
      {field: 'newAgentCode', message: 'New Agent is Required.'},
      {field: 'reason', message: 'Reason is Required.'},
      {field: 'effectiveDate', message: 'Transfer Date is Required.'},
    ];

    for (const rule of validationRules) {
      if (!this.policyForm.value[rule.field]) {
        showErrorMessage(rule.message);
        return false;
      }
    }

    if (!this.policyForm.value.reason.toString().trim()) {
      showErrorMessage('Reason is Required.');
      return false;
    }


    if (!this.fileToUpload) {
      showErrorMessage('Please Upload Policy Transfer Letter.');
      return false;
    }

    return true;
  }


  async savePolicyForm() {
    if (this.validate()) {

      const data = {
        policyNo: this.policyForm.value.policyNo,
        newBranchCode: this.policyForm.value.newBranch,
        newAgentCode: this.policyForm.value.newAgentCode,
        reasonForPolicyTransfer: this.policyForm.value.reason,
        effectiveDate: formatDate(this.policyForm.value.effectiveDate ? this.policyForm.value.effectiveDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
        hasPolicyTransferFile: true,
        policyTransferFileUrl: this.letterUrl,
      };

      const saveResponse: any = await this.saveForm(data).catch(
        (err) => {
          console.log(err);
        }
      );


      if (saveResponse.status === 201) {
        showSucessMessage(saveResponse.message);
        this.router.navigate(['/dashboard/advisor-management/all-policy-transfer-table']);
        this.clear();
      } else {
        showErrorMessage(saveResponse.payload.message);
      }

    }
  }

  saveForm(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .submitPolicyTransferForm(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async draftPolicyForm() {

    const data = {
      policyNo: this.policyForm.value.policyNo,
      newBranchCode: this.policyForm.value.newBranch,
      newAgentCode: this.policyForm.value.newAgentCode,
      reasonForPolicyTransfer: this.policyForm.value.reason,
      effectiveDate: formatDate(this.policyForm.value.effectiveDate ? this.policyForm.value.effectiveDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
      hasPolicyTransferFile: this.letterUrl ? true : false,
      policyTransferFileUrl: this.letterUrl,
    };

    const saveResponse: any = await this.draftForm(data).catch(
      (err) => {
        console.log(err);
      }
    );

    if (saveResponse.status === 201) {
      showSucessMessage(saveResponse.message);
      this.router.navigate(['/dashboard/advisor-management/all-policy-transfer-table']);
      this.clear();
    } else {
      showErrorMessage(saveResponse.payload.message);
    }
  }

  draftForm(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .draftPolicyTransferForm(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
