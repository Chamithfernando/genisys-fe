import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyTransferEditFormComponent } from './policy-transfer-edit-form.component';

describe('PolicyTransferEditFormComponent', () => {
  let component: PolicyTransferEditFormComponent;
  let fixture: ComponentFixture<PolicyTransferEditFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PolicyTransferEditFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PolicyTransferEditFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
