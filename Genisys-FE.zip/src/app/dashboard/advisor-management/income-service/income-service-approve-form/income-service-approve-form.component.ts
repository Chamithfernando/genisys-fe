import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {ActivatedRoute} from '@angular/router';
import {
  COMMON_TITLES, LETTER_TYPES, Selector,
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {formatDate} from '@angular/common';
import {
  AddApproveStatusComponent
} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/add-approve-status/add-approve-status.component';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {OpenPdfComponent} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/open-pdf/open-pdf.component';


@Component({
  selector: 'app-income-service-approve-form',
  templateUrl: './income-service-approve-form.component.html',
  styleUrls: ['./income-service-approve-form.component.scss']
})
export class IncomeServiceApproveFormComponent implements OnInit {

  letterForm: FormGroup;

  branchId: string;
  branchCode: string;
  currentDesignation: string;
  selectedAgent: any;
  formId: number;
  formStatus: string;
  formObj: any;
  dueAmount: number;
  dialogRef: MatDialogRef<any>;
  isDisabled = false;
  isUploadFile = false;
  typeOfLetters: Selector[];
  agentTitles: Selector[];
  branchArray: Array<any> = [];
  agentsArray: Array<any> = [];

  constructor(private formBuilder: FormBuilder,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              private dialog: MatDialog,
              private route: ActivatedRoute) {

    this.letterForm = this.formBuilder.group({
      letterType: new FormControl('', [Validators.required]),
      branch: new FormControl('', [Validators.required]),
      agentCode: new FormControl('', [Validators.required]),
      agentTitle: new FormControl('', [Validators.required]),
      advisorStatus: new FormControl('', [Validators.required]),
      effectiveDate: new FormControl('', [Validators.required]),
      advisorAddress: new FormControl('', [Validators.required]),
      designation: new FormControl('', [Validators.required]),
      appointmentDate: new FormControl('', [Validators.required]),
      requestReason: new FormControl('', [Validators.required]),
      monthStatement: new FormControl('', [Validators.required]),
      callingName: new FormControl('', [Validators.required]),
      addressOne: new FormControl('', [Validators.required]),
      addressTwo: new FormControl('', [Validators.required]),
      addressThree: new FormControl('')
    });

    this.typeOfLetters = LETTER_TYPES;
    this.agentTitles = COMMON_TITLES;
  }


  async ngOnInit(): Promise<void> {
    this.route.queryParams.subscribe(params => {
      this.formId = (params.formId);
    });

    try {
      await Promise.all([this.allBranches(), this.fieldsDisabled(), this.getLetterDetails()]);
    } catch (error) {
      console.error(error);
    }
  }

  fieldsDisabled(){
    this.letterForm.get('advisorStatus').disable();
    this.letterForm.get('monthStatement').disable();
    this.isDisabled = false;
  }

  async allBranches() {
    const branchList: any = await this.getBranchList().catch((error) => {
      console.log(error);
    });
    if (branchList.status === 200) {
      this.branchArray = branchList.payload.sort((a, b) => a.branchName.localeCompare(b.branchName));
      this.isDisabled = true;
    }
  }

  async getBranchList() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAllBranches(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async allAgentsByBranch(branchCode: string) {

    const branchId = branchCode;

    const agentsList: any = await this.getAgentsDetails(branchId).catch((error) => {
      console.log(error);
    });
    if (agentsList.status === 200) {
      if (agentsList.data && agentsList.data.length > 0) {
        this.agentsArray = agentsList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));
      }
    }
  }

  async getAgentsDetails(branchId: any) {

    this.branchId = branchId;

    return new Promise((resolve, reject) => {
      this.advisorService
        .getAgentsbyBranch(+this.branchId, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getLetterDetails() {

    this.formObj = await this.getFormDetails().catch((error) => {
      console.log(error);
    });


    if (this.formObj.status === 200) {

      this.branchId = this.formObj.data.branchCode;

      let terminateDate = '';
      if (this.formObj.data.terminationDate) {
        const trimmedPeriodOfTerminateDate = this.formObj.data.terminationDate.substring(0, 10);
        if (trimmedPeriodOfTerminateDate !== '1970-01-01') {
          terminateDate = formatDate(trimmedPeriodOfTerminateDate, 'yyyy-MM-dd', 'en-US');
        }
      }

      let appoinmentDate = '';
      if (this.formObj.data.agentAppointmentDate) {
        const trimmedPeriodOfAppointmenteDate = this.formObj.data.agentAppointmentDate.substring(0, 10);
        if (trimmedPeriodOfAppointmenteDate !== '1970-01-01') {
          appoinmentDate = formatDate(trimmedPeriodOfAppointmenteDate, 'yyyy-MM-dd', 'en-US');
        }
      }

      if (this.branchId) {
        await Promise.all([this.allAgentsByBranch(this.branchId)]);
      }
      this.letterForm.patchValue({
        letterType: this.formObj.data.letterTypeEnum,
        branch: this.formObj.data.branchCode.toString(),
        agentCode: this.formObj.data.agentCode,
        agentTitle: this.formObj.data.agentTitle,
        designation: this.formObj.data.agentDesignation,
        advisorAddress: this.formObj.data.agentAddress,
        advisorStatus: this.formObj.data.agentStatus,
        effectiveDate: terminateDate,
        appointmentDate: appoinmentDate,
        callingName: this.formObj.data.recipientCallingName,
        addressOne: this.formObj.data.recipientAddress1,
        addressTwo: this.formObj.data.recipientAddress2,
        addressThree: this.formObj.data.recipientAddress3,
        requestReason: this.formObj.data.reasonForRequest,
        monthStatement: this.formObj.data.numOfMonths.toString(),

      });
      this.isUploadFile = this.formObj.data.hasRequestLetter;
      this.dueAmount = this.formObj.data.outstandingDues;
    }
  }

  async getFormDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .incomeServiceDetailsGetById(this.formId)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  openLetterPdf() {

    const details = {
      id: this.formId,
      title: 'incomeServiceUploadFile'
    };

    this.dialogRef = this.dialog.open(OpenPdfComponent, {
      width: '1150px',
      data: details
    });
  }

  openApproveStatus() {
    const elements = {
      id: this.formId,
      formTitle: 'incomeServiceLetter',
      letterStatus: this.formObj.data.letterTypeEnum,
      dueAmount: this.dueAmount,
    };

    this.dialogRef = this.dialog.open(AddApproveStatusComponent, {
      width: '600px',
      disableClose: true,
      data: elements,
    });

  }

}
