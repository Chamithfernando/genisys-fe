import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IncomeServiceApproveFormComponent } from './income-service-approve-form.component';

describe('IncomeServiceApproveFormComponent', () => {
  let component: IncomeServiceApproveFormComponent;
  let fixture: ComponentFixture<IncomeServiceApproveFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IncomeServiceApproveFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IncomeServiceApproveFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
