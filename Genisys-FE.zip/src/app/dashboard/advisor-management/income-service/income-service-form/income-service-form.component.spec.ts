import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IncomeServiceFormComponent } from './income-service-form.component';

describe('IncomeServiceFormComponent', () => {
  let component: IncomeServiceFormComponent;
  let fixture: ComponentFixture<IncomeServiceFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IncomeServiceFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IncomeServiceFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
