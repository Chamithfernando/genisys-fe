import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IncomeServiceCompletedTableComponent } from './income-service-completed-table.component';

describe('IncomeServiceCompletedTableComponent', () => {
  let component: IncomeServiceCompletedTableComponent;
  let fixture: ComponentFixture<IncomeServiceCompletedTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IncomeServiceCompletedTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IncomeServiceCompletedTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
