import { Component, OnInit, ViewChild } from '@angular/core';
import {
  applyFilter,
  LETTER_TYPES,
  showErrorMessage
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {validateEnterSpecialCharacters} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {OpenPdfComponent} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/open-pdf/open-pdf.component';
import {formatDate} from '@angular/common';
import * as fileSaver from 'file-saver';
import {
  IncomeServiceApprovalLevelsComponent
} from '@app/dashboard/advisor-management/income-service/income-service-approval-levels/income-service-approval-levels.component';
import {
  IncomeServiceRejectReasonComponent
} from '@app/dashboard/advisor-management/income-service/income-service-reject-reason/income-service-reject-reason.component';


@Component({
  selector: 'app-income-service-completed-table',
  templateUrl: './income-service-completed-table.component.html',
  styleUrls: ['./income-service-completed-table.component.scss']
})
export class IncomeServiceCompletedTableComponent implements OnInit {

  formId: number;
  tableStatus: string;
  formListObj: any;
  userDetails: any;
  hideSFAFeatures = true;
  formList: Array<any> = [];

  dialogRef: MatDialogRef<any>;

  displayedColumns: string[] = ['sequenceNumber', 'id', 'agentName', 'branchName', 'letterTypeEnum', 'agentAppointmentDate',
    'reason' ,  'approveLevels', 'view', 'download'];
  dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private authService: AuthService,
              private advisorService: AdvisorManagementService,
              private dialog: MatDialog) { }

  async ngOnInit(): Promise<void> {

    try{
      await Promise.all([this.getLoginUser(), this.getIncomeServiceDetails()]);
    } catch (error){
      console.log(error);
    }
  }

  mapLetterType(letterTypeEnum: string): string {
    const foundType = LETTER_TYPES.find(type => type.value === letterTypeEnum);
    return foundType ? foundType.viewValue : letterTypeEnum;
  }

  rejectApplication(e: any, element: number) {
    const rejectDetails = {
      id: element,
      title: 'approved'
    };

    this.dialogRef = this.dialog.open(IncomeServiceRejectReasonComponent, {
      width: '600px',
      data: rejectDetails,
    });
  }
  async getLoginUser() {
    this.userDetails = await this.getUserDetails().catch((error) => {
      console.log(error);
    });

    if (this.userDetails.status === 'OK') {
      const roleName = this.userDetails.data.roleDto.roleName;
      if (['SFA'].includes(roleName)) {
        this.hideSFAFeatures = false;
      }
    }
  }

  async getUserDetails() {
    return new Promise((resolve, reject) => {

      this.authService
        .getPermission()
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  applyFilter(event: Event) {
    applyFilter(this.dataSource, event);
  }

  validateEnterSpecialCharacters(event: Event) {
    validateEnterSpecialCharacters(event);
  }

  openApprovalLevels(e: any, element: number) {
    this.dialogRef = this.dialog.open(IncomeServiceApprovalLevelsComponent, {
      width: '600px',
      data: element
    });
  }

  openLetterPdf(e: any, element: number, type: string){

    let letterTitle = '';
    if (type === 'INCOME_LETTER') {
      letterTitle = 'incomeUploadFile';
    } else {
      letterTitle = 'serviceUploadFile';
    }

    const details = {
      id: element,
      title: letterTitle
    };

    this.dialogRef = this.dialog.open(OpenPdfComponent, {
      width: '1150px',
      data: details
    });
  }

  downloadLetter(e: any, element: number, letterType: string): void {
    this.formId = element;
    const currentDate = new Date();
    const formattedCreateDate = formatDate(currentDate, 'yyyy_MM_dd HH:mm', 'en-US');
    const serviceCall = letterType === 'INCOME_LETTER'
      ? this.advisorService.openIncomeDocument(this.formId)
      : this.advisorService.openServiceDocument(this.formId);

    serviceCall.subscribe((response: any) => {
      if (response.size > 100) {
        let prefix: string;
        if (letterType === 'INCOME_LETTER') {
          prefix = 'Income';
        } else if (letterType === 'SERVICE_ACTIVE_CODE_LETTER') {
          prefix = 'Service_Active';
        } else {
          prefix = 'Service_Terminate';
        }

        const filename = `Letter_${prefix}_${formattedCreateDate}.pdf`;
        this.saveFile(response, filename, 'application/pdf');
      } else if (response.payload.code === 400) {
        showErrorMessage(response.payload.message);
      } else {
        showErrorMessage('Document Download Failed.');
      }
    });
  }


  private saveFile(data: Blob, filename?: string, mimeType?: string): void {
    const blob = new Blob([data], { type: mimeType || 'application/octet-stream' });
    fileSaver.saveAs(blob, filename || 'file.pdf');
  }

  async getIncomeServiceDetails() {

    this.tableStatus = 'APPROVED';

    this.formListObj = await this.getTableDetails().catch((error) => {
      console.log(error);
    });

    if (this.formListObj.status === 200) {

      this.formList = this.formListObj.data.map((item, index) => {
        return { ...item, sequenceNumber: index + 1 };
      });
    }

    this.dataSource = new MatTableDataSource(this.formList);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  getTableDetails(){
    return this.advisorService.getIncomeServiceDetailsByFilter(this.tableStatus, this.authService.getCurrentUserDetails().access_token)
            .toPromise();
  }
}
