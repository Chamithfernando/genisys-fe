import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllIncomeServiceTableComponent } from './all-income-service-table.component';

describe('AllIncomeServiceTableComponent', () => {
  let component: AllIncomeServiceTableComponent;
  let fixture: ComponentFixture<AllIncomeServiceTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllIncomeServiceTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AllIncomeServiceTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
