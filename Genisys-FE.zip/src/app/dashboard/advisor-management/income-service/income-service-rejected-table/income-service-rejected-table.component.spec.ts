import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IncomeServiceRejectedTableComponent } from './income-service-rejected-table.component';

describe('IncomeServiceRejectedTableComponent', () => {
  let component: IncomeServiceRejectedTableComponent;
  let fixture: ComponentFixture<IncomeServiceRejectedTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IncomeServiceRejectedTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IncomeServiceRejectedTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
