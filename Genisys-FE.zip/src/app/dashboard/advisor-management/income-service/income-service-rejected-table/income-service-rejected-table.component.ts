import { Component, OnInit, ViewChild } from '@angular/core';
import {applyFilter, LETTER_TYPES} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {validateEnterSpecialCharacters} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {
  IncomeServiceRejectReasonComponent
} from '@app/dashboard/advisor-management/income-service/income-service-reject-reason/income-service-reject-reason.component';


@Component({
  selector: 'app-income-service-rejected-table',
  templateUrl: './income-service-rejected-table.component.html',
  styleUrls: ['./income-service-rejected-table.component.scss']
})
export class IncomeServiceRejectedTableComponent implements OnInit {

  tableStatus: string;
  formListObj: any;
  formList: Array<any> = [];
  dialogRef: MatDialogRef<any>;

  displayedColumns: string[] = ['sequenceNumber', 'id', 'agentName', 'branchName', 'letterTypeEnum', 'agentAppointmentDate',
    'reason'];
  dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private authService: AuthService,
              private advisorService: AdvisorManagementService,
              private dialog: MatDialog) { }

  ngOnInit(): void {

    this.getIncomeServiceDetails();
  }

  applyFilter(event: Event) {
    applyFilter(this.dataSource, event);
  }

  validateEnterSpecialCharacters(event: Event) {
    validateEnterSpecialCharacters(event);
  }

  mapLetterType(letterTypeEnum: string): string {
    const foundType = LETTER_TYPES.find(type => type.value === letterTypeEnum);
    return foundType ? foundType.viewValue : letterTypeEnum;
  }

  rejectApplication(e: any, element: number) {
    const rejectDetails = {
      id: element,
      title: 'reject'
    };

    this.dialogRef = this.dialog.open(IncomeServiceRejectReasonComponent, {
      width: '600px',
      data: rejectDetails,
    });
  }

  async getIncomeServiceDetails() {

    this.tableStatus = 'REJECTED';

    this.formListObj = await this.getTableDetails().catch((error) => {
      console.log(error);
    });

    if (this.formListObj.status === 200) {

      this.formList = this.formListObj.data.map((item, index) => {
        return { ...item, sequenceNumber: index + 1 };
      });
    }

    this.dataSource = new MatTableDataSource(this.formList);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  getTableDetails(){
    return this.advisorService.getIncomeServiceDetailsByFilter(this.tableStatus, this.authService.getCurrentUserDetails().access_token)
          .toPromise();
  }
}
