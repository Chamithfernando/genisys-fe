import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';

@Component({
  selector: 'app-income-service-approval-levels',
  templateUrl: './income-service-approval-levels.component.html',
  styleUrls: ['./income-service-approval-levels.component.scss']
})
export class IncomeServiceApprovalLevelsComponent implements OnInit {

  levelOneDecision = '';
  levelOneDeciderName = '';
  levelOneDecisionDate: string | null = '';

  levelTwoDecision = '';
  levelTwoDeciderName = '';
  levelTwoDecisionDate: string | null = '';

  levelThreeStatus = '';
  levelThreeDecision = '';
  levelThreeDeciderName = '';
  levelThreeDecisionDate: string | null = '';

  outstandingAmt: number;
  financeRemarks: string;
  financeUserFullName: string;

  constructor(public dialogRef: MatDialogRef<IncomeServiceApprovalLevelsComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private advisorService: AdvisorManagementService,
              private authService: AuthService) { }

  ngOnInit(): void {
    this.getApprovalStatus();
  }

  async getApprovalStatus() {
    const getResponse: any = await this.getLevelsDetails().catch(
      (err) => {
        console.log(err);
      }
    );

    if (getResponse.status === 200) {

      const data = getResponse.data;

      const decisionMapping = {
        APPROVED: 'Approved',
        NOT_APPROVED: 'Not Approved',
        REJECTED: 'Rejected'
      };

      this.levelOneDecision = decisionMapping[data.levelOneDecision] || data.levelOneDecision;
      this.levelOneDeciderName = data.levelOneDeciderName;
      this.levelOneDecisionDate = data.levelOneDecisionDate;

      this.levelTwoDecision = decisionMapping[data.levelTwoDecision] || data.levelTwoDecision;
      this.levelTwoDeciderName = data.levelTwoDeciderName;
      this.levelTwoDecisionDate = data.levelTwoDecisionDate;

      this.levelThreeDecision = decisionMapping[data.levelThreeDecision] || data.levelThreeDecision;
      this.levelThreeDeciderName = data.levelThreeDeciderName;
      this.levelThreeDecisionDate = data.levelThreeDecisionDate;

      this.outstandingAmt = data.outstandingAmt;
      this.financeUserFullName = data.financeUserFullName;
      this.financeRemarks = data.financeRemarks;

    }
  }

  getLevelsDetails() {
    return this.advisorService
      .getIncomeServiceApprovalLevel( this.data, this.authService.getCurrentUserDetails().access_token).toPromise();
  }

}
