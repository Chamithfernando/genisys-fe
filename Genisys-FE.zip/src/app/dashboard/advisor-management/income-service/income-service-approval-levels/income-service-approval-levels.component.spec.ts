import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IncomeServiceApprovalLevelsComponent } from './income-service-approval-levels.component';

describe('IncomeServiceApprovalLevelsComponent', () => {
  let component: IncomeServiceApprovalLevelsComponent;
  let fixture: ComponentFixture<IncomeServiceApprovalLevelsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IncomeServiceApprovalLevelsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IncomeServiceApprovalLevelsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
