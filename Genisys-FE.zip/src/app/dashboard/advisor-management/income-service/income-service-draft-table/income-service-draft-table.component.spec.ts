import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IncomeServiceDraftTableComponent } from './income-service-draft-table.component';

describe('IncomeServiceDraftTableComponent', () => {
  let component: IncomeServiceDraftTableComponent;
  let fixture: ComponentFixture<IncomeServiceDraftTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IncomeServiceDraftTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IncomeServiceDraftTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
