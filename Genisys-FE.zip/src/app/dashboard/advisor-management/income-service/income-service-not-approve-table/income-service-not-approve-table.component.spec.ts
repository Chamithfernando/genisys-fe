import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IncomeServiceNotApproveTableComponent } from './income-service-not-approve-table.component';

describe('IncomeServiceNotApproveTableComponent', () => {
  let component: IncomeServiceNotApproveTableComponent;
  let fixture: ComponentFixture<IncomeServiceNotApproveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IncomeServiceNotApproveTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IncomeServiceNotApproveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
