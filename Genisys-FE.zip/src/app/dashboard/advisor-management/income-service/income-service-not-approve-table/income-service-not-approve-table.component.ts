import { Component, OnInit, ViewChild } from '@angular/core';
import {applyFilter, LETTER_TYPES} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {validateEnterSpecialCharacters} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {ActivatedRoute, Router} from '@angular/router';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {
  IncomeServiceRejectReasonComponent
} from '@app/dashboard/advisor-management/income-service/income-service-reject-reason/income-service-reject-reason.component';
import {
  IncomeServiceApprovalLevelsComponent
} from '@app/dashboard/advisor-management/income-service/income-service-approval-levels/income-service-approval-levels.component';

@Component({
  selector: 'app-income-service-not-approve-table',
  templateUrl: './income-service-not-approve-table.component.html',
  styleUrls: ['./income-service-not-approve-table.component.scss']
})
export class IncomeServiceNotApproveTableComponent implements OnInit {

  tableStatus: string;
  formListObj: any;
  hideZmSfaFeatures = false;
  userDetails: any;
  formList: Array<any> = [];
  dialogRef: MatDialogRef<any>;

  displayedColumns: string[] = ['sequenceNumber', 'id', 'agentName', 'branchName', 'letterTypeEnum', 'agentAppointmentDate',
    'reason', 'action', 'approveLevels'];
  dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private router: Router,
              private route: ActivatedRoute,
              private authService: AuthService,
              private advisorService: AdvisorManagementService,
              private dialog: MatDialog) { }

  async ngOnInit(): Promise<void> {

    try{
      await Promise.all([this.getLoginUser(), this.getIncomeServiceDetails()]);
    } catch (error){
      console.log(error);
    }
  }

  mapLetterType(letterTypeEnum: string): string {
    const foundType = LETTER_TYPES.find(type => type.value === letterTypeEnum);
    return foundType ? foundType.viewValue : letterTypeEnum;
  }

  async getLoginUser() {
    this.userDetails = await this.getUserDetails().catch((error) => {
      console.log(error);
    });

    if (this.userDetails.status === 'OK') {
      const roleName = this.userDetails.data.roleDto.roleName;
      if (['Zonal Manager', 'SFA'].includes(roleName)) {
        this.hideZmSfaFeatures = true;
      }
    }
  }

  async getUserDetails() {
    return new Promise((resolve, reject) => {

      this.authService
        .getPermission()
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  applyFilter(event: Event) {
    applyFilter(this.dataSource, event);
  }

  validateEnterSpecialCharacters(event: Event) {
    validateEnterSpecialCharacters(event);
  }

  rejectApplication(e: any, element: number) {
    const rejectDetails = {
      id: element,
      title: 'notApproved'
    };

    this.dialogRef = this.dialog.open(IncomeServiceRejectReasonComponent, {
      width: '600px',
      data: rejectDetails,
    });
  }

  editApplication(e: any, element: number) {
    this.router.navigate(['../income-service-edit-form'], {
      relativeTo: this.route,
      queryParams: {
        formId : element,
        formStatus : 'notapprove'
      }
    });
  }

  openApprovalLevels(e: any, element: number) {
    this.dialogRef = this.dialog.open(IncomeServiceApprovalLevelsComponent, {
      width: '600px',
      data: element
    });
  }

  async getIncomeServiceDetails() {

    this.tableStatus = 'NOT_APPROVED';

    this.formListObj = await this.getTableDetails().catch((error) => {
      console.log(error);
    });

    if (this.formListObj.status === 200) {

      this.formList = this.formListObj.data.map((item, index) => {
        return { ...item, sequenceNumber: index + 1 };
      });
    }

    this.dataSource = new MatTableDataSource(this.formList);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  getTableDetails(){
    return this.advisorService.getIncomeServiceDetailsByFilter
    (this.tableStatus, this.authService.getCurrentUserDetails().access_token).toPromise();
  }
}
