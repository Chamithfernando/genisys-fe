import {Component, ViewChild, OnInit} from '@angular/core';
import {
  applyFilter,
  LETTER_TYPES,
  showErrorMessage
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {validateEnterSpecialCharacters} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {formatDate} from '@angular/common';
import {MatDatepickerInput} from '@angular/material/datepicker';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-income-service-summary-table',
  templateUrl: './income-service-summary-table.component.html',
  styleUrls: ['./income-service-summary-table.component.scss']
})
export class IncomeServiceSummaryTableComponent implements OnInit {

  displayedColumns: string[] = ['sequenceNumber', 'id', 'agentName', 'branchName', 'letterTypeEnum', 'agentAppointmentDate'];
  dataSource = new MatTableDataSource();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('startDateInput') startDateInput: MatDatepickerInput<Date>;
  @ViewChild('endDateInput') endDateInput: MatDatepickerInput<Date>;

  tableStatus: string;
  formListObj: any;
  formList: Array<any> = [];
  startDate: Date = null;
  endDate: Date = null;

  constructor(private authService: AuthService,
              private advisorService: AdvisorManagementService) {
  }

  ngOnInit(): void {
    const currentDate = new Date();
    const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    const startDate = this.formatDate(firstDayOfMonth);
    const endDate = this.formatDate(lastDayOfMonth);

    this.startDate = firstDayOfMonth;
    this.endDate = lastDayOfMonth;

    this.getIncomeServiceSummaryDetails(startDate, endDate);
  }


  formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = ('0' + (date.getMonth() + 1)).slice(-2);
    const day = ('0' + date.getDate()).slice(-2);
    return `${year}-${month}-${day}`;
  }

  applyFilter(event: Event) {
    applyFilter(this.dataSource, event);
  }

  validateEnterSpecialCharacters(event: Event) {
    validateEnterSpecialCharacters(event);
  }

  mapLetterType(letterTypeEnum: string): string {
    const foundType = LETTER_TYPES.find(type => type.value === letterTypeEnum);
    return foundType ? foundType.viewValue : letterTypeEnum;
  }

  parseDateString(dateString: string): Date {
    const parts = dateString.split('/');
    const formattedDate = `${parts[2]}-${parts[1]}-${parts[0]}`;
    return new Date(formattedDate);
  }

  formatDateForBackend(date: Date): string {
    return formatDate(date, 'yyyy-MM-dd', 'en-US');
  }

  clear() {
    this.formList = [];
    this.dataSource = new MatTableDataSource(this.formList);

    this.startDate = null;
    this.endDate = null;
  }

  exportToExcel() {
    const columnsToExport = [
      { key: 'sequenceNumber', header: 'No' },
      { key: 'agentName', header: 'Agent' },
      { key: 'branchName', header: 'Branch' },
      { key: 'letterTypeEnum', header: 'Letter Type' },
      { key: 'agentAppointmentDate', header: 'Date of Appointment' },
    ];

    const wb = XLSX.utils.book_new();

    const data = this.dataSource.data.map(item => {
      const row = {};
      columnsToExport.forEach(col => {
        if (col.key === 'agentAppointmentDate') {
          row[col.key] = this.formatDate(new Date(item[col.key]));
        } else if (col.key === 'letterTypeEnum') {
          row[col.key] = this.mapLetterType(item[col.key]);
        } else {
          row[col.key] = item[col.key];
        }
      });
      return row;
    });

    const headerNames = columnsToExport.map(col => col.header);

    const ws = XLSX.utils.json_to_sheet(data, { header: columnsToExport.map(col => col.key) });

    ws['!rows'] = [{ hpx: 30 }];
    XLSX.utils.sheet_add_aoa(ws, [headerNames], { origin: 'A1' });

    const columnWidths = this.calculateColumnWidths(data, columnsToExport.map(col => col.key));
    ws['!cols'] = columnWidths.map(width => ({ wpx: width }));

    XLSX.utils.book_append_sheet(wb, ws, 'Income Service Summary');

    XLSX.writeFile(wb, 'income_service_summary.xlsx');
  }


  calculateColumnWidths(data: any[], columns: string[]): number[] {
    if (data.length === 0) {
      return columns.map(() => 100);
    }


    const widths = columns.map(col => col.length);


    data.forEach(item => {
      columns.forEach((col, index) => {
        const cellValue = item[col] ? item[col].toString() : '';
        widths[index] = Math.max(widths[index], cellValue.length * 10);
      });
    });

    return widths;
  }


  async getIncomeServiceSummaryDetails(startDate: string, endDate: string) {

    if (!startDate || !endDate) {
      showErrorMessage('Please Select Date Range.');
    } else {

      const startDateObj = this.parseDateString(startDate);
      const endDateObj = this.parseDateString(endDate);

      const fromDate = this.formatDateForBackend(startDateObj);
      const toDate = this.formatDateForBackend(endDateObj);


      this.formListObj = await this.getTableDetails(fromDate, toDate).catch((error) => {
        console.log(error);
      });

      if (this.formListObj.status === 200) {

        this.formList = this.formListObj.data.map((item, index) => {
          return {...item, sequenceNumber: index + 1};
        });
      }

      this.dataSource = new MatTableDataSource(this.formList);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }
  }

  async getTableDetails(startDate: string, endDate: string) {
    const dateRange = {
      fromtDate: startDate,
      toDate: endDate,
    };
    return this.advisorService.incomeServiceSummaryTable(dateRange, this.authService.getCurrentUserDetails().access_token).toPromise();
  }

}
