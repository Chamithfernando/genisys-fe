import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IncomeServiceSummaryTableComponent } from './income-service-summary-table.component';

describe('IncomeServiceSummaryTableComponent', () => {
  let component: IncomeServiceSummaryTableComponent;
  let fixture: ComponentFixture<IncomeServiceSummaryTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IncomeServiceSummaryTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IncomeServiceSummaryTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
