import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IncomeServiceApproveTableComponent } from './income-service-approve-table.component';

describe('IncomeServiceApproveTableComponent', () => {
  let component: IncomeServiceApproveTableComponent;
  let fixture: ComponentFixture<IncomeServiceApproveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IncomeServiceApproveTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IncomeServiceApproveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
