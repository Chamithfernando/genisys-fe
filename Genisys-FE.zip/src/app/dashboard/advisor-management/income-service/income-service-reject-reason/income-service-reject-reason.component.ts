import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';

@Component({
  selector: 'app-income-service-reject-reason',
  templateUrl: './income-service-reject-reason.component.html',
  styleUrls: ['./income-service-reject-reason.component.scss']
})
export class IncomeServiceRejectReasonComponent implements OnInit {

  reasonId: number;
  reasonObj: any;
  reason = '';
  deciderName = '';
  reasonTitle: string;
  rejectedBy: string;
  constructor(public dialogRef: MatDialogRef<IncomeServiceRejectReasonComponent>,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {
    this.getRejectReason();

    if (this.data.title === 'reject') {
      this.reasonTitle = 'Reject Reason';
      this.rejectedBy = 'Rejected by';
    } else if (this.data.title === 'notApproved') {
      this.reasonTitle = 'Not Approved Reason';
      this.rejectedBy = 'Not Approved by';
    }else if (this.data.title === 'approved') {
      this.reasonTitle = 'Approved Reason';
      this.rejectedBy = 'Approved by';
    }
  }

  async getRejectReason() {

    this.reasonId = this.data.id;

    this.reasonObj = await this.getReasonDetails().catch((error) => {
      console.log(error);
    });

    if (this.reasonObj.status === 200) {
      this.reason = this.reasonObj.data.reason;
      this.deciderName = this.reasonObj.data.deciderName;

    }
  }

  async getReasonDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getIncomeServiceReasonStatus(this.reasonId, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
