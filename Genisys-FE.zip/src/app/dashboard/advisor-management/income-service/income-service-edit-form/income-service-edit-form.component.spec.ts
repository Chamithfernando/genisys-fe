import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IncomeServiceEditFormComponent } from './income-service-edit-form.component';

describe('IncomeServiceEditFormComponent', () => {
  let component: IncomeServiceEditFormComponent;
  let fixture: ComponentFixture<IncomeServiceEditFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IncomeServiceEditFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IncomeServiceEditFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
