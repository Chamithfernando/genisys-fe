import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {ActivatedRoute, Router} from '@angular/router';
import {
  COMMON_TITLES, LETTER_TYPES, Selector,
  showErrorMessage, showSucessMessage,
  showWarningMessage
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {formatDate} from '@angular/common';
import {
  allowLettersOnly
} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {OpenPdfComponent} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/open-pdf/open-pdf.component';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';


@Component({
  selector: 'app-income-service-edit-form',
  templateUrl: './income-service-edit-form.component.html',
  styleUrls: ['./income-service-edit-form.component.scss']
})
export class IncomeServiceEditFormComponent implements OnInit {

  letterForm: FormGroup;

  branchId: string;
  currentDesignation: string;
  selectedAgent: any;
  formId: number;
  formStatus: string;
  fileToUpload: File;
  letterUrl: string;
  selectedFileName: string;
  uploadFile: string;
  formObj: any;
  isDisabled = false;
  dialogRef: MatDialogRef<any>;
  typeOfLetters: Selector[];
  agentTitles: Selector[];
  branchArray: Array<any> = [];
  agentsArray: Array<any> = [];

  @ViewChild('fileInput') fileInput: ElementRef<HTMLInputElement>;

  constructor(private formBuilder: FormBuilder,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              private router: Router,
              private route: ActivatedRoute,
              private dialog: MatDialog) {

    this.letterForm = this.formBuilder.group({
      letterType: new FormControl('', [Validators.required]),
      branch: new FormControl('', [Validators.required]),
      agentCode: new FormControl('', [Validators.required]),
      agentTitle: new FormControl('', [Validators.required]),
      advisorStatus: new FormControl('', [Validators.required]),
      effectiveDate: new FormControl('', [Validators.required]),
      advisorAddress: new FormControl('', [Validators.required]),
      designation: new FormControl('', [Validators.required]),
      appointmentDate: new FormControl('', [Validators.required]),
      requestReason: new FormControl('', [Validators.required]),
      monthStatement: new FormControl('', [Validators.required]),
      callingName: new FormControl('', [Validators.required]),
      addressOne: new FormControl('', [Validators.required]),
      addressTwo: new FormControl('', [Validators.required]),
      addressThree: new FormControl('', )
    });

    this.typeOfLetters = LETTER_TYPES;
    this.agentTitles = COMMON_TITLES;
  }


  async ngOnInit(): Promise<void> {
    this.route.queryParams.subscribe(params => {
      this.formId = (params.formId);
      this.formStatus = (params.formStatus);
    });

    try {
      await Promise.all([this.allBranches(), this.getLetterDetails()]);
    } catch (error) {
      console.error(error);
    }


  }

  allowLettersOnly(event: Event) {
    allowLettersOnly(event);
  }


  async allBranches() {
    const branchList: any = await this.getBranchList().catch((error) => {
      console.log(error);
    });
    if (branchList.status === 200) {
      this.branchArray = branchList.payload.sort((a, b) => a.branchName.localeCompare(b.branchName));
      this.isDisabled = true;
    }
  }

  async getBranchList() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAllBranches(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


  async allAgentsByBranch(branchCode: string) {

    const branchId = branchCode;

    const agentsList: any = await this.getAgentsDetails(branchId).catch((error) => {
      console.log(error);
    });
    if (agentsList.status === 200) {
      if (agentsList.data && agentsList.data.length > 0) {
        this.agentsArray = agentsList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));
      } else {
        showWarningMessage('No Agents in this Branch');
        this.letterForm.get('agentCode').setValue('');
        this.agentsArray = [];
      }
    }
  }

  async getAgentsDetails(branchId: any) {

    this.branchId = branchId;

    return new Promise((resolve, reject) => {
      this.advisorService
        .getAgentsbyBranch(+this.branchId, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  onAgentSelected(agentCode: string) {
    this.selectedAgent = this.agentsArray.find(agent => agent.agentCode === agentCode);

    if (this.selectedAgent) {

      this.letterForm.patchValue({
        designation: this.selectedAgent.designation,
      });
    }
  }

  fileUpload() {
    this.fileInput.nativeElement.click();
  }

  onFileSelected(event: any) {
    const file: File = event.target.files[0];

    const fileType = this.getFileType(file);
    if (fileType === 'pdf') {
      this.fileToUpload = file;
      this.convertToBase64(file);
      this.selectedFileName = file.name;
    } else {
      showWarningMessage('Invalid file type. Please upload a pdf file.');
    }
  }

  convertToBase64(file: File) {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const base64String = reader.result as string;
      const base64WithoutPath = base64String.split(',')[1];
      this.letterUrl = base64WithoutPath;
    };
    reader.onerror = (error) => {
      console.error('Error: ', error);
    };
  }

  getFileType(file: File): string {
    const fileName = file.name.toLowerCase();
    if (fileName.endsWith('.pdf')) {
      return 'pdf';
    } else {
      return '';
    }
  }

  openLetterPdf() {

    const details = {
      id: this.formId,
      title: 'incomeServiceUploadFile'
    };

    this.dialogRef = this.dialog.open(OpenPdfComponent, {
      width: '1150px',
      data: details
    });
  }

  async getLetterDetails() {

    this.formObj = await this.getFormDetails().catch((error) => {
      console.log(error);
    });


    if (this.formObj.status === 200) {

      this.letterForm.get('advisorStatus').disable();
      this.branchId = this.formObj.data.branchCode;

      let terminateDate = '';
      if (this.formObj.data.terminationDate) {
        const trimmedPeriodOfTerminateDate = this.formObj.data.terminationDate.substring(0, 10);
        if (trimmedPeriodOfTerminateDate !== '1970-01-01') {
          terminateDate = formatDate(trimmedPeriodOfTerminateDate, 'yyyy-MM-dd', 'en-US');
        }
      }

      let appoinmentDate = '';
      if (this.formObj.data.agentAppointmentDate) {
        const trimmedPeriodOfAppointmenteDate = this.formObj.data.agentAppointmentDate.substring(0, 10);
        if (trimmedPeriodOfAppointmenteDate !== '1970-01-01') {
          appoinmentDate = formatDate(trimmedPeriodOfAppointmenteDate, 'yyyy-MM-dd', 'en-US');
        }
      }

      if (this.branchId) {
        await Promise.all([this.allAgentsByBranch(this.branchId)]);
      }
      this.letterForm.patchValue({
        letterType: this.formObj.data.letterTypeEnum,
        branch: this.formObj.data.branchCode.toString(),
        agentCode: this.formObj.data.agentCode,
        agentTitle: this.formObj.data.agentTitle,
        designation: this.formObj.data.agentDesignation,
        advisorAddress: this.formObj.data.agentAddress,
        advisorStatus: this.formObj.data.agentStatus,
        effectiveDate: terminateDate,
        appointmentDate: appoinmentDate,
        callingName: this.formObj.data.recipientCallingName,
        addressOne: this.formObj.data.recipientAddress1,
        addressTwo: this.formObj.data.recipientAddress2,
        addressThree: this.formObj.data.recipientAddress3,
        requestReason: this.formObj.data.reasonForRequest,
        monthStatement: this.formObj.data.numOfMonths.toString(),
      });
      this.uploadFile = this.formObj.data.hasRequestLetter;
    }
  }

  async getFormDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .incomeServiceDetailsGetById(this.formId)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  clear() {

    Object.keys(this.letterForm.controls).forEach(controlName => {
      const control = this.letterForm.get(controlName);
      if (control) {
        control.setValue('');
        control.clearValidators();
        control.updateValueAndValidity();
      }
    });

    this.letterForm.get('letterType').setValidators([Validators.required]);
    this.letterForm.get('agentCode').setValidators([Validators.required]);
    this.letterForm.get('agentTitle').setValidators([Validators.required]);
    this.letterForm.get('advisorStatus').setValidators([Validators.required]);
    this.letterForm.get('advisorAddress').setValidators([Validators.required]);
    this.letterForm.get('effectiveDate').setValidators([Validators.required]);
    this.letterForm.get('designation').setValidators([Validators.required]);
    this.letterForm.get('appointmentDate').setValidators([Validators.required]);
    this.letterForm.get('requestReason').setValidators([Validators.required]);
    this.letterForm.get('monthStatement').setValidators([Validators.required]);
    this.letterForm.get('callingName').setValidators([Validators.required]);
    this.letterForm.get('addressOne').setValidators([Validators.required]);
    this.letterForm.get('addressTwo').setValidators([Validators.required]);

    this.letterForm.updateValueAndValidity();
  }


  validate() {

    const validationRules = [
      {field: 'letterType', message: 'Letter Type is Required.'},
      {field: 'branch', message: 'Branch is Required.'},
      {field: 'agentCode', message: 'Agent is Required.'},
      {field: 'agentTitle', message: 'Agent Title is Required.'}
    ];

    for (const rule of validationRules) {
      if (!this.letterForm.value[rule.field]) {
        showErrorMessage(rule.message);
        return false;
      }
    }

    if (this.letterForm.get('letterType').value === 'INCOME_LETTER' && !this.letterForm.value.requestReason) {
      showErrorMessage('Reason for requesting a income letter  is Required.');
      return false;
    }

    if (this.letterForm.get('letterType').value === 'INCOME_LETTER' && !this.letterForm.value.monthStatement) {
      showErrorMessage('Months that Statement  is Required.');
      return false;
    }

    if (this.letterForm.get('letterType').value === 'INCOME_LETTER' && !this.letterForm.value.callingName) {
      showErrorMessage('Letter Receiver Calling Name  is Required.');
      return false;
    }


    if (this.letterForm.get('letterType').value === 'SERVICE_TERMINATED_CODE_LETTER' && !this.letterForm.value.requestReason) {
      showErrorMessage('Termination reason is Required.');
      return false;
    }


    if (this.letterForm.get('letterType').value === 'SERVICE_ACTIVE_CODE_LETTER' &&
      !this.letterForm.value.requestReason.toString().trim()) {
      showErrorMessage('Service Reason  Required.');
      return false;
    }


    if (this.letterForm.get('letterType').value === 'SERVICE_ACTIVE_CODE_LETTER' && !this.letterForm.value.callingName) {
      showErrorMessage('Letter Receiver Calling Name is Required.');
      return false;
    }

    if (!this.letterForm.value.addressOne || !this.letterForm.value.addressOne.toString().trim()) {
      showErrorMessage('Letter receiver Address Line 1 is Required.');
      return false;
    }

    if (!this.letterForm.value.addressTwo || !this.letterForm.value.addressTwo.toString().trim()) {
      showErrorMessage('Letter receiver Address Line 2 is Required.');
      return false;
    }

    return true;
  }

  draftValidate() {

    const validationRules = [
      {field: 'letterType', message: 'Letter Type is Required.'},
      {field: 'branch', message: 'Branch is Required.'},
      {field: 'agentCode', message: 'Agent is Required.'},
    ];

    for (const rule of validationRules) {
      if (!this.letterForm.value[rule.field]) {
        showErrorMessage(rule.message);
        return false;
      }
    }
    return true;
  }

  async saveIncomeServiceForm() {
    if (this.validate()) {

      const addressOne = this.letterForm.value.addressOne || '';
      const addressTwo = this.letterForm.value.addressTwo || '';
      const addressThree = this.letterForm.value.addressThree || '';

      const recipientAllAddress = [addressOne, addressTwo, addressThree].filter(address => address.trim() !== '');

      const data = {
        id: this.formId,
        letterTypeEnum: this.letterForm.value.letterType,
        branchCode: +this.letterForm.value.branch,
        agentCode: this.letterForm.value.agentCode,
        agentTitle: this.letterForm.value.agentTitle,
        agentDesignation: this.letterForm.value.designation,
        recipientCallingName: this.letterForm.value.callingName,
        reasonForRequest: this.letterForm.value.requestReason,
        numOfMonths: +this.letterForm.value.monthStatement,
        recipientAddress: recipientAllAddress,
        hasRequestLetter: this.letterUrl || this.uploadFile ? true : false,
        requestLetterFileUrl: this.letterUrl,
      };
      const saveResponse: any = await this.saveForm(data).catch(
        (err) => {
          console.log(err);
        }
      );


      if (saveResponse.status === 201) {
        showSucessMessage(saveResponse.message);
        this.router.navigate(['/dashboard/advisor-management/all-income-service-table']);
        this.clear();
      } else if ( saveResponse.payload.code === 400) {
        showErrorMessage(saveResponse.payload.message);
      }else {
        showErrorMessage(saveResponse.message);
      }

    }
  }

  saveForm(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .submitIncomeServiceForm(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async draftIncomeServiceForm() {
    if (this.draftValidate()) {
      const addressOne = this.letterForm.value.addressOne || '';
      const addressTwo = this.letterForm.value.addressTwo || '';
      const addressThree = this.letterForm.value.addressThree || '';

      const recipientAllAddress = [addressOne, addressTwo, addressThree].filter(address => address.trim() !== '');

      const data = {
        id: this.formId,
        letterTypeEnum: this.letterForm.value.letterType,
        branchCode: +this.letterForm.value.branch,
        agentCode: this.letterForm.value.agentCode,
        agentTitle: this.letterForm.value.agentTitle,
        agentDesignation: this.letterForm.value.designation,
        recipientCallingName: this.letterForm.value.callingName,
        reasonForRequest: this.letterForm.value.requestReason,
        numOfMonths: +this.letterForm.value.monthStatement,
        recipientAddress: recipientAllAddress,
        hasRequestLetter: this.letterUrl || this.uploadFile ? true : false,
        requestLetterFileUrl: this.letterUrl,
      };

      const saveResponse: any = await this.draftForm(data).catch(
        (err) => {
          console.log(err);
        }
      );

      if (saveResponse.status === 201) {
        showSucessMessage(saveResponse.message);
        this.router.navigate(['/dashboard/advisor-management/all-income-service-table']);
        this.clear();
      } else if ( saveResponse.payload.code === 400) {
        showErrorMessage(saveResponse.payload.message);
      }else {
        showErrorMessage(saveResponse.message);
      }
    }
  }

  draftForm(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .draftIncomeServiceForm(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
