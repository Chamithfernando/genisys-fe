import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchTransferCompletedTableComponent } from './branch-transfer-completed-table.component';

describe('BranchTransferCompletedTableComponent', () => {
  let component: BranchTransferCompletedTableComponent;
  let fixture: ComponentFixture<BranchTransferCompletedTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BranchTransferCompletedTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BranchTransferCompletedTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
