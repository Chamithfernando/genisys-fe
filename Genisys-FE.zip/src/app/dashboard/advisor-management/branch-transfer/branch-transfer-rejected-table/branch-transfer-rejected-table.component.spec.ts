import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchTransferRejectedTableComponent } from './branch-transfer-rejected-table.component';

describe('BranchTransferRejectedTableComponent', () => {
  let component: BranchTransferRejectedTableComponent;
  let fixture: ComponentFixture<BranchTransferRejectedTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BranchTransferRejectedTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BranchTransferRejectedTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
