import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';


@Component({
  selector: 'app-branch-transfer-approval-levels',
  templateUrl: './branch-transfer-approval-levels.component.html',
  styleUrls: ['./branch-transfer-approval-levels.component.scss']
})
export class BranchTransferApprovalLevelsComponent implements OnInit {


  sameZone: string;

  levelOneDecision = '';
  levelOneDeciderName = '';
  levelOneDecisionDate: string | null = '';

  levelTwoDecision = '';
  levelTwoDeciderName = '';
  levelTwoDecisionDate: string | null = '';

  levelThreeStatus = '';
  levelThreeDecision = '';
  levelThreeDeciderName = '';
  levelThreeDecisionDate: string | null = '';

  levelFourDecision = '';
  levelFourDeciderName = '';
  levelFourDecisionDate: string | null = '';

  levelFiveDecision = '';
  levelFiveDeciderName = '';
  levelFiveDecisionDate: string | null = '';


  constructor(public dialogRef: MatDialogRef<BranchTransferApprovalLevelsComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private advisorService: AdvisorManagementService,
              private authService: AuthService) {
  }

  async ngOnInit(): Promise<void> {

    try {
      await Promise.all([this.getApprovalStatus()]);
    } catch (error) {
      console.log(error);
    }
  }

  async getApprovalStatus() {
    const getResponse: any = await this.getLevelsDetails().catch(
      (err) => {
        console.log(err);
      }
    );

    if (getResponse.status === 200) {

      const data = getResponse.data;

      const decisionMapping = {
        APPROVED: 'Approved',
        NOT_APPROVED: 'Not Approved',
        REJECTED: 'Rejected'
      };

      this.levelOneDecision = decisionMapping[data.levelOneDecision] || data.levelOneDecision;
      this.levelOneDeciderName = data.levelOneDeciderName;
      this.levelOneDecisionDate = data.levelOneDecisionDate;

      this.levelTwoDecision = decisionMapping[data.levelTwoDecision] || data.levelTwoDecision;
      this.levelTwoDeciderName = data.levelTwoDeciderName;
      this.levelTwoDecisionDate = data.levelTwoDecisionDate;

      this.levelThreeDecision = decisionMapping[data.levelThreeDecision] || data.levelThreeDecision;
      this.levelThreeDeciderName = data.levelThreeDeciderName;
      this.levelThreeDecisionDate = data.levelThreeDecisionDate;

      this.levelFourDecision = decisionMapping[data.levelFourDecision] || data.levelFourDecision;
      this.levelFourDeciderName = data.levelFourDeciderName;
      this.levelFourDecisionDate = data.levelFourDecisionDate;

      this.levelFiveDecision = decisionMapping[data.levelFiveDecision] || data.levelFiveDecision;
      this.levelFiveDeciderName = data.levelFiveDeciderName;
      this.levelFiveDecisionDate = data.levelFiveDecisionDate;

      this.sameZone = this.data.sameZone;


    }
  }

  getLevelsDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getBranchApprovalLevel(this.data.id, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


}
