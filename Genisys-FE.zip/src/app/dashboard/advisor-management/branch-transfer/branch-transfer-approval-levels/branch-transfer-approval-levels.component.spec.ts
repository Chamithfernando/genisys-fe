import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchTransferApprovalLevelsComponent } from './branch-transfer-approval-levels.component';

describe('BranchTransferApprovalLevelsComponent', () => {
  let component: BranchTransferApprovalLevelsComponent;
  let fixture: ComponentFixture<BranchTransferApprovalLevelsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BranchTransferApprovalLevelsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BranchTransferApprovalLevelsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
