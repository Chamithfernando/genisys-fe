import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchTransferApproveTableComponent } from './branch-transfer-approve-table.component';

describe('BranchTransferApproveTableComponent', () => {
  let component: BranchTransferApproveTableComponent;
  let fixture: ComponentFixture<BranchTransferApproveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BranchTransferApproveTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BranchTransferApproveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
