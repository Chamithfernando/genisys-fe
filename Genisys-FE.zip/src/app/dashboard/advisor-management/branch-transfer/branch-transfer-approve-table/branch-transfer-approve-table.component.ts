import {Component, OnInit, ViewChild} from '@angular/core';
import {
  applyFilter,
  PolicyType, TYPE_OF_BRANCH,
  TYPE_OF_POLICY
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {validateEnterSpecialCharacters} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {ActivatedRoute, Router} from '@angular/router';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {
  PolicyTransferApprovalLevelsComponent
} from '@app/dashboard/advisor-management/policy-transfer/policy-transfer-approval-levels/policy-transfer-approval-levels.component';
import {
  BranchTransferApprovalLevelsComponent
} from '@app/dashboard/advisor-management/branch-transfer/branch-transfer-approval-levels/branch-transfer-approval-levels.component';


@Component({
  selector: 'app-branch-transfer-approve-table',
  templateUrl: './branch-transfer-approve-table.component.html',
  styleUrls: ['./branch-transfer-approve-table.component.scss']
})
export class BranchTransferApproveTableComponent implements OnInit {

  tableStatus: string;
  formListObj: any;
  hideBmFeatures = false;
  userDetails: any;
  branchRequestType = false;
  hideSFAFeatures = false;

  branchType: PolicyType[];

  formList: Array<any> = [];
  dialogRef: MatDialogRef<any>;

  displayedColumns: string[] = ['sequenceNumber', 'id', 'agentName', 'branchName', 'newReportingLeaderName', 'newReportingBranchName', 'effectiveDate',
    'action', 'approveLevels'];

  dataSource = new MatTableDataSource();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private router: Router,
              private route: ActivatedRoute,
              private authService: AuthService,
              private advisorService: AdvisorManagementService,
              private dialog: MatDialog) {
    this.branchType = TYPE_OF_BRANCH;
  }

  async ngOnInit(): Promise<void> {

    this.branchRequestType = true;
    await this.getBranchTransferDetails(this.branchRequestType);
    try {
      await Promise.all([this.getLoginUser()]);
    } catch (error) {
      console.log(error);
    }

  }

  async getLoginUser() {
    this.userDetails = await this.getUserDetails().catch((error) => {
      console.log(error);
    });

    if (this.userDetails.status === 'OK') {
      const roleName = this.userDetails.data.roleDto.roleName;
      if (['Branch Manager'].includes(roleName)) {
        this.hideBmFeatures = true;
      }

      if (['SFA'].includes(roleName)) {
        this.hideSFAFeatures = true;
      }
    }
  }

  async getUserDetails() {
    return new Promise((resolve, reject) => {

      this.authService
        .getPermission()
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  applyFilter(event: Event) {
    applyFilter(this.dataSource, event);
  }

  validateEnterSpecialCharacters(event: Event) {
    validateEnterSpecialCharacters(event);
  }

  editApplication(e: any, element: number) {
    this.router.navigate(['../branch-transfer-approve-form'], {
      relativeTo: this.route,
      queryParams: {
        formId: element,
        formStatus: 'submitted',
        requestType: this.branchRequestType
      }
    });
  }

  openApprovalLevels(e: any, element: any) {
    this.dialogRef = this.dialog.open(BranchTransferApprovalLevelsComponent, {
      width: '600px',
      data: element
    });
  }

  async getBranchTransferDetails(isBranchType: boolean) {

    this.tableStatus = 'PENDING';
    this.branchRequestType = isBranchType;

    this.formListObj = await this.getTableDetails().catch((error) => {
      console.log(error);
    });

    if (this.formListObj.status === 200) {

      this.formList = this.formListObj.data.map((item, index) => {
        return {...item, sequenceNumber: index + 1};
      });
    }

    this.dataSource = new MatTableDataSource(this.formList);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  async getTableDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getBranchTransferDetailsByFilter(this.tableStatus, this.branchRequestType, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
}
