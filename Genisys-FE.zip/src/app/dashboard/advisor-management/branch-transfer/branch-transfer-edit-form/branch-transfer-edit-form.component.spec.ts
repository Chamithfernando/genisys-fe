import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchTransferEditFormComponent } from './branch-transfer-edit-form.component';

describe('BranchTransferEditFormComponent', () => {
  let component: BranchTransferEditFormComponent;
  let fixture: ComponentFixture<BranchTransferEditFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BranchTransferEditFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BranchTransferEditFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
