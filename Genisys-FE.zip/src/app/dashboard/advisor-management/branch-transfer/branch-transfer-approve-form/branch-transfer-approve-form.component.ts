import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {ActivatedRoute, Router} from '@angular/router';
import {
  AddApproveStatusComponent
} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/add-approve-status/add-approve-status.component';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {showWarningMessage} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {formatDate} from '@angular/common';

interface Types {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-branch-transfer-approve-form',
  templateUrl: './branch-transfer-approve-form.component.html',
  styleUrls: ['./branch-transfer-approve-form.component.scss']
})
export class BranchTransferApproveFormComponent implements OnInit {

  branchForm: FormGroup;
  branchId: string;
  formId: number;
  formStatus: string;
  isDisabled = false;
  requestType: boolean;
  dialogRef: MatDialogRef<any>;
  reportingType: Types[];
  branchArray: Array<any> = [];
  agentsArray: Array<any> = [];
  reportingLeadersArray: Array<any> = [];


  selectedAgent: any;
  formObj: any;

  newBranchId: string;
  newBranchCode: number;
  agentCode: string;
  newLeaderCode: string;


  constructor(private formBuilder: FormBuilder,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              private router: Router,
              private route: ActivatedRoute,
              private dialog: MatDialog) {

    this.branchForm = this.formBuilder.group({
      branch: new FormControl('', [Validators.required]),
      agentCode: new FormControl('', [Validators.required]),
      reportingTo: new FormControl('', [Validators.required]),
      reportingType: new FormControl('', [Validators.required]),
      newBranch: new FormControl('', [Validators.required]),
      newLeaderCode: new FormControl('', [Validators.required]),
      reason: new FormControl(''),
      effectiveDate: new FormControl('', [Validators.required]),
    });

    this.reportingType = [
      {value: 'TEAM_LEADER', viewValue: 'Team Lead'},
      {value: 'FIELD_MANAGER', viewValue: 'Field Manager'},
      {value: 'DIRECT_REPORTING', viewValue: 'Direct Reporting'},
    ];
  }

  async ngOnInit(): Promise<void> {

    this.route.queryParams.subscribe(params => {
      this.formId = (params.formId);
      this.formStatus = (params.formStatus);
      this.requestType = (params.requestType);

    });

    try {
      await Promise.all([this.allBranches(), this.getBranchTransferDetails()]);
    } catch (error) {
      console.log(error);
    }
  }

  openApproveStatus() {
    const elements = {
      id: this.formId,
      formTitle: 'branchTransfer',
      typeOfRequest: this.requestType
    };

    this.dialogRef = this.dialog.open(AddApproveStatusComponent, {
      width: '600px',
      disableClose: true,
      data: elements,
    });

  }

  async allBranches() {
    const branchList: any = await this.getBranchList().catch((error) => {
      console.log(error);
    });
    if (branchList.status === 200) {
      this.branchArray = branchList.payload.sort((a, b) => a.branchName.localeCompare(b.branchName));
      this.isDisabled = true;
    }
  }

  async getBranchList() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAllBranches(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async allAgentsByBranch(branchCode: string) {

    const branchId = branchCode;

    const agentsList: any = await this.getAgentsDetails(branchId).catch((error) => {
      console.log(error);
    });
    if (agentsList.status === 200) {
      if (agentsList.data && agentsList.data.length > 0) {
        this.agentsArray = agentsList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));
        this.branchForm.get('reportingTo').setValue('');

      } else {
        showWarningMessage('No Agents in this Branch');
        this.agentsArray = [];
      }
    }
  }

  async getAgentsDetails(branchId: any) {

    this.branchId = branchId;

    return new Promise((resolve, reject) => {
      this.advisorService
        .getAgentsbyBranch(+this.branchId, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


  async allReportingLeadersByBranch() {

    const params = {
      agentCode: this.branchForm.value.agentCode,
      branchId: +this.newBranchId ? +this.newBranchId : this.newBranchCode,
      reportingType: this.branchForm.value.reportingType
    };

    const leadersList: any = await this.getLeadersDetails(params).catch((error) => {
      console.log(error);
    });
    if (leadersList.status === 200) {
      if (leadersList.data && leadersList.data.length > 0) {
        this.reportingLeadersArray = leadersList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));

      } else {
        showWarningMessage('No New Reporting Leaders in this Branch');
        this.branchForm.get('newLeaderCode').setValue('');
        this.reportingLeadersArray = [];
      }
    }
  }

  async getLeadersDetails(params: any) {

    return new Promise((resolve, reject) => {
      this.advisorService
        .getReportingLeaders(params.agentCode, params.branchId, params.reportingType, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  onAgentSelected(agentCode: string) {

    this.selectedAgent = this.agentsArray.find(agent => agent.agentCode === agentCode);

    if (this.selectedAgent) {
      this.branchForm.patchValue({
        reportingTo: this.selectedAgent.reportingTo,
      });

    }
  }

  async getBranchTransferDetails() {

    this.formObj = await this.getFormDetails().catch((error) => {
      console.log(error);
    });

    if (this.formObj.status === 200) {
      const branchId = this.formObj.data.branchCode;
      this.agentCode = this.formObj.data.agentCode;
      this.newBranchCode = this.formObj.data.newReportingBranchCode;
      this.newLeaderCode = this.formObj.data.newReportingLeaderCode;

      if (branchId) {
        await Promise.all([this.allAgentsByBranch(branchId)]);
      }

      let requestingDate = '';
      if (this.formObj.data.effectiveDate) {
        const trimmedPeriodOfRequestingDate = this.formObj.data.effectiveDate.substring(0, 10);
        if (trimmedPeriodOfRequestingDate !== '1970-01-01') {
          requestingDate = formatDate(trimmedPeriodOfRequestingDate, 'yyyy-MM-dd', 'en-US');
        }
      }

      this.branchForm.patchValue({
        branch: this.formObj.data.branchCode?.toString() ?? '',
        agentCode: this.formObj.data.agentCode,
        newBranch: this.formObj.data.newReportingBranchCode?.toString() ?? '',
        reportingType: this.formObj.data.newReportingType,
        reason: this.formObj.data.reasonForBranchTransfer,
        effectiveDate: requestingDate
      });
      if (this.newBranchCode) {
        this.allReportingLeadersByBranch();
      }

      if (this.newLeaderCode) {
        this.branchForm.patchValue({
          newLeaderCode: this.formObj.data.newReportingLeaderCode
        });
      }

      if (this.agentCode) {
        this.onAgentSelected(this.agentCode);
      }
    }
  }

  async getFormDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .branchTransferDetailsGetById(this.formId)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
