import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchTransferApproveFormComponent } from './branch-transfer-approve-form.component';

describe('BranchTransferApproveFormComponent', () => {
  let component: BranchTransferApproveFormComponent;
  let fixture: ComponentFixture<BranchTransferApproveFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BranchTransferApproveFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BranchTransferApproveFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
