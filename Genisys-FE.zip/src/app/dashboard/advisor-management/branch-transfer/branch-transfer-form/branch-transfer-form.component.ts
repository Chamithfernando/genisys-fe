import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {ActivatedRoute, Router} from '@angular/router';
import {
  showErrorMessage, showSucessMessage,
  showWarningMessage
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {formatDate} from '@angular/common';

interface Types {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-branch-transfer-form',
  templateUrl: './branch-transfer-form.component.html',
  styleUrls: ['./branch-transfer-form.component.scss']
})
export class BranchTransferFormComponent implements OnInit {

  branchForm: FormGroup;
  branchId: string;
  newBranchId: string;
  selectedAgent: any;
  isDisabled = false;
  currentDate: Date = new Date();
  reportingType: Types[];
  branchArray: Array<any> = [];
  agentsArray: Array<any> = [];
  reportingLeadersArray: Array<any> = [];

  constructor(private formBuilder: FormBuilder,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              private router: Router,
              private route: ActivatedRoute) {

    this.branchForm = this.formBuilder.group({
      branch: new FormControl('', [Validators.required]),
      agentCode: new FormControl('', [Validators.required]),
      reportingTo: new FormControl('', [Validators.required]),
      reportingType: new FormControl('', [Validators.required]),
      newBranch: new FormControl('', [Validators.required]),
      newLeaderCode: new FormControl('', [Validators.required]),
      reason: new FormControl(''),
      effectiveDate: new FormControl('', [Validators.required]),
    });

    this.reportingType = [
      {value: 'TEAM_LEADER', viewValue: 'Team Lead'},
      {value: 'FIELD_MANAGER', viewValue: 'Field Manager'},
      {value: 'DIRECT_REPORTING', viewValue: 'Direct Reporting'},
    ];
  }

  ngOnInit(): void {

    this.route.queryParams.subscribe(params => {
      this.newBranchId = (params.branchCode);
    });

    this.branchForm.get('newBranch').setValue(this.newBranchId);

    this.allBranches();

  }

  async allBranches() {
    const branchList: any = await this.getBranchList().catch((error) => {
      console.log(error);
    });
    if (branchList.status === 200) {
      this.branchArray = branchList.payload.sort((a, b) => a.branchName.localeCompare(b.branchName));
      this.isDisabled = true;
    }
  }

  async getBranchList() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAllBranches(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async allAgentsByBranch(event: any) {

    const branchId = event.value;

    const agentsList: any = await this.getAgentsDetails(branchId).catch((error) => {
      console.log(error);
    });
    if (agentsList.status === 200) {
      if (agentsList.data && agentsList.data.length > 0) {
        this.agentsArray = agentsList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));
        this.branchForm.get('reportingTo').setValue('');
      } else {
        showWarningMessage('No Agents in this Branch');
        this.branchForm.get('agentCode').setValue('');
        this.branchForm.get('reportingTo').setValue('');
        this.agentsArray = [];
      }
    }
  }

  async getAgentsDetails(branchId: any) {

    this.branchId = branchId;

    return new Promise((resolve, reject) => {
      this.advisorService
        .getAgentsbyBranch(+this.branchId, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  onAgentSelected(agentCode: string) {
    this.selectedAgent = this.agentsArray.find(agent => agent.agentCode === agentCode);

    if (this.selectedAgent) {

      this.branchForm.patchValue({
        reportingTo: this.selectedAgent.reportingTo,
      });

    }

    if (this.branchForm.value.reportingType === 'DIRECT_REPORTING') {
      this.allReportingLeadersByBranch();
    }
  }


  async allReportingLeadersByBranch() {

    if (this.branchForm.value.reportingType === 'DIRECT_REPORTING' && !this.branchForm.value.agentCode) {
      showErrorMessage('Please Select Agent');
      this.reportingLeadersArray = [];
    } else {

      const params = {
        agentCode: this.branchForm.value.agentCode,
        branchId: +this.newBranchId,
        reportingType: this.branchForm.value.reportingType
      };

    const leadersList: any = await this.getLeadersDetails(params).catch((error) => {
      console.log(error);
    });

    if (leadersList.status === 200) {
      if (leadersList.data && leadersList.data.length > 0) {

        this.reportingLeadersArray = leadersList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));

      } else {
        showWarningMessage('No New Reporting Leaders in this Branch');
        this.branchForm.get('newLeaderCode').setValue('');
        this.reportingLeadersArray = [];
      }
    }
  }
  }

  async getLeadersDetails(params: any) {

    return new Promise((resolve, reject) => {
      this.advisorService
        .getReportingLeaders(params.agentCode, params.branchId, params.reportingType, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  clear() {
    const controlsToClear = [
      'branch',
      'agentCode',
      'reportingTo',
      'reportingType',
      'newLeaderCode',
      'reason',
      'effectiveDate',
    ];

    controlsToClear.forEach(controlName => {
      this.branchForm.get(controlName).setValue('');
      this.branchForm.get(controlName).clearValidators();
      this.branchForm.get(controlName).updateValueAndValidity();
    });

    this.branchForm.get('branch').setValidators([Validators.required]);
    this.branchForm.get('agentCode').setValidators([Validators.required]);
    this.branchForm.get('reportingTo').setValidators([Validators.required]);
    this.branchForm.get('reportingType').setValidators([Validators.required]);
    this.branchForm.get('newLeaderCode').setValidators([Validators.required]);
    this.branchForm.get('reason').setValidators([Validators.required]);
    this.branchForm.get('effectiveDate').setValidators([Validators.required]);

    this.branchForm.updateValueAndValidity();
  }

  validate() {

    const validationRules = [
      {field: 'branch', message: 'Branch is Required.'},
      {field: 'agentCode', message: 'Agent is Required.'},
      {field: 'reportingType', message: 'New Reporting Type is Required.'},
      {field: 'newBranch', message: 'New Reporting Branch is Required.'},
      {field: 'newLeaderCode', message: 'New Reporting Leader is Required.'},
      {field: 'reason', message: 'Reason is Required.'},
      {field: 'effectiveDate', message: 'Transfer Date is Required.'},
    ];

    for (const rule of validationRules) {
      if (!this.branchForm.value[rule.field]) {
        showErrorMessage(rule.message);
        return false;
      }
    }

    if (this.branchForm.value.branch === this.branchForm.value.newBranch){
      showErrorMessage('Cannot enter same Branch.');
      return false;
    }

    if (!this.branchForm.value.reason.toString().trim()) {
      showErrorMessage('Reason is Required.');
      return false;
    }

    return true;
  }

  draftValidate() {

    const validationRules = [
      {field: 'branch', message: 'Branch is Required.'},
      {field: 'agentCode', message: 'Advisor is Required.'},
      {field: 'reportingType', message: 'New Reporting Type is Required.'},
    ];

    for (const rule of validationRules) {
      if (!this.branchForm.value[rule.field]) {
        showErrorMessage(rule.message);
        return false;
      }
    }

    if (this.branchForm.value.branch === this.branchForm.value.newBranch){
      showErrorMessage('Cannot enter same Branch.');
      return false;
    }

    return true;
  }

  async saveBranchForm() {
    if (this.validate()) {

      const data = {

        branchCode: this.branchForm.value.branch,
        agentCode: this.branchForm.value.agentCode,
        newReportingType: this.branchForm.value.reportingType,
        newReportingBranchCode: this.branchForm.value.newBranch,
        newReportingLeaderCode: this.branchForm.value.newLeaderCode,
        reasonForBranchTransfer: this.branchForm.value.reason,
        effectiveDate: formatDate(this.branchForm.value.effectiveDate ? this.branchForm.value.effectiveDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
      };

      const saveResponse: any = await this.saveForm(data).catch(
        (err) => {
          console.log(err);
        }
      );


      if (saveResponse.status === 201) {
        showSucessMessage(saveResponse.message);
        this.router.navigate(['/dashboard/advisor-management/all-branch-transfer-table']);
        this.clear();
      } else {
        showErrorMessage(saveResponse.payload.message);
      }

    }
  }

  saveForm(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .submitBranchTransferForm(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


  async draftBranchForm() {
    if (this.draftValidate()) {

      const data = {
        branchCode: this.branchForm.value.branch,
        agentCode: this.branchForm.value.agentCode,
        newReportingType: this.branchForm.value.reportingType,
        newReportingBranchCode: this.branchForm.value.newBranch,
        newReportingLeaderCode: this.branchForm.value.newLeaderCode,
        reasonForBranchTransfer: this.branchForm.value.reason,
        effectiveDate: formatDate(this.branchForm.value.effectiveDate ? this.branchForm.value.effectiveDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
      };

      const saveResponse: any = await this.draftForm(data).catch(
        (err) => {
          console.log(err);
        }
      );


      if (saveResponse.status === 201) {
        showSucessMessage(saveResponse.message);
        this.router.navigate(['/dashboard/advisor-management/all-branch-transfer-table']);
        this.clear();
      } else {
        showErrorMessage(saveResponse.payload.message);
      }
    }
  }

  draftForm(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .draftBranchTransferForm(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


}
