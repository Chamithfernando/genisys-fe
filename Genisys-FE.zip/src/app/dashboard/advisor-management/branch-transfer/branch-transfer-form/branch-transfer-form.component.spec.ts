import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchTransferFormComponent } from './branch-transfer-form.component';

describe('BranchTransferFormComponent', () => {
  let component: BranchTransferFormComponent;
  let fixture: ComponentFixture<BranchTransferFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BranchTransferFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BranchTransferFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
