import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchTransferSummaryTableComponent } from './branch-transfer-summary-table.component';

describe('BranchTransferSummaryTableComponent', () => {
  let component: BranchTransferSummaryTableComponent;
  let fixture: ComponentFixture<BranchTransferSummaryTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BranchTransferSummaryTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BranchTransferSummaryTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
