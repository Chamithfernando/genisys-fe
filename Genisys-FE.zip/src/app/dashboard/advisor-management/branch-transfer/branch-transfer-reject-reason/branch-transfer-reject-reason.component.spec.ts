import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchTransferRejectReasonComponent } from './branch-transfer-reject-reason.component';

describe('BranchTransferRejectReasonComponent', () => {
  let component: BranchTransferRejectReasonComponent;
  let fixture: ComponentFixture<BranchTransferRejectReasonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BranchTransferRejectReasonComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BranchTransferRejectReasonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
