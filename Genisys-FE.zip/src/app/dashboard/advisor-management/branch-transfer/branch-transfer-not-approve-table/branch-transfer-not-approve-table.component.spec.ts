import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchTransferNotApproveTableComponent } from './branch-transfer-not-approve-table.component';

describe('BranchTransferNotApproveTableComponent', () => {
  let component: BranchTransferNotApproveTableComponent;
  let fixture: ComponentFixture<BranchTransferNotApproveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BranchTransferNotApproveTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BranchTransferNotApproveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
