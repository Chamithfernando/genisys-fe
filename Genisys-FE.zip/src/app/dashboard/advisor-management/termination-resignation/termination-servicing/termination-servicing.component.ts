import { Component, ViewChild, OnInit } from '@angular/core';
import {applyFilter, showErrorMessage} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {validateEnterSpecialCharacters} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {MatDatepickerInput} from '@angular/material/datepicker';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {
  TerminationServicingSubmitComponent
} from '@app/dashboard/advisor-management/termination-resignation/termination-servicing-submit/termination-servicing-submit.component';
import {ActivatedRoute, Router} from '@angular/router';


@Component({
  selector: 'app-termination-servicing',
  templateUrl: './termination-servicing.component.html',
  styleUrls: ['./termination-servicing.component.scss']
})
export class TerminationServicingComponent implements OnInit {

  displayedColumns: string[] = ['sequenceNumber',  'agentName', 'branchName', 'designation',
    'requestingDate' , 'outstandingAmt', 'hasOutstanding', 'serviceRemarks', 'action'];

  dataSource = new MatTableDataSource();
  dialogRef: MatDialogRef<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('startDateInput') startDateInput: MatDatepickerInput<Date>;
  @ViewChild('endDateInput') endDateInput: MatDatepickerInput<Date>;

  tableStatus: string;
  formListObj: any;
  formList: Array<any> = [];
  startDate: Date = null;
  endDate: Date = null;

  constructor(private authService: AuthService,
              private advisorService: AdvisorManagementService,
              private dialog: MatDialog,
              private router: Router,
              private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.getServicingDetails();
  }

  openServicingForm(e: any, element: number) {
    this.router.navigate(['../termination-approve-form'], {
      relativeTo: this.route,
      queryParams: {
        formId : element,
      }
    });
  }

  openServicingSubmit(e: any, formId: number) {

    this.dialogRef = this.dialog.open(TerminationServicingSubmitComponent, {
      width: '600px',
      data: formId
    });

    this.dialogRef.afterClosed().subscribe((response) => {
      if (response) {
        this.dialogRef.close(true);
        this.getServicingDetails();
      }
    });
  }

  applyFilter(event: Event) {
    applyFilter(this.dataSource, event);
  }

  validateEnterSpecialCharacters(event: Event) {
    validateEnterSpecialCharacters(event);
  }



  async getServicingDetails() {
    this.formListObj = await this.getTableDetails().catch((error) => {
      console.log(error);
    });


    if (this.formListObj.status === 200) {

      this.formList = this.formListObj.data.map((item, index) => {
        return {...item, sequenceNumber: index + 1};
      });
    }

    this.dataSource = new MatTableDataSource(this.formList);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  async getTableDetails() {

    return new Promise((resolve, reject) => {
      this.advisorService
        .servicingTable(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
