import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TerminationServicingComponent } from './termination-servicing.component';

describe('TerminationServicingComponent', () => {
  let component: TerminationServicingComponent;
  let fixture: ComponentFixture<TerminationServicingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TerminationServicingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TerminationServicingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
