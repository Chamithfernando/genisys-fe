import { Component, OnInit, ViewChild } from '@angular/core';
import {applyFilter} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {validateEnterSpecialCharacters} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {ActivatedRoute, Router} from '@angular/router';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {
  TerminationRejcetReasonComponent
} from '@app/dashboard/advisor-management/termination-resignation/termination-rejcet-reason/termination-rejcet-reason.component';


@Component({
  selector: 'app-termination-rejected-table',
  templateUrl: './termination-rejected-table.component.html',
  styleUrls: ['./termination-rejected-table.component.scss']
})
export class TerminationRejectedTableComponent implements OnInit {

  tableStatus: string;
  formListObj: any;
  formList: Array<any> = [];
  dialogRef: MatDialogRef<any>;

  displayedColumns: string[] = ['sequenceNumber', 'id', 'agentName', 'branchName', 'requestingDate',
    'reason'];

  // dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private router: Router,
              private route: ActivatedRoute,
              private authService: AuthService,
              private advisorService: AdvisorManagementService,
              private dialog: MatDialog) { }

  ngOnInit(): void {

    this.getTerminationDetails();
  }

  applyFilter(event: Event) {
    applyFilter(this.dataSource, event);
  }

  validateEnterSpecialCharacters(event: Event) {
    validateEnterSpecialCharacters(event);
  }

  rejectApplication(e: any, element: number) {
    const rejectDetails = {
      id: element,
      title: 'reject'
    };

    this.dialogRef = this.dialog.open(TerminationRejcetReasonComponent, {
      width: '600px',
      data: rejectDetails,
    });
  }

  async getTerminationDetails() {

    this.tableStatus = 'REJECTED';

    this.formListObj = await this.getTableDetails().catch((error) => {
      console.log(error);
    });

    if (this.formListObj.status === 200) {

      this.formList = this.formListObj.data.map((item, index) => {
        return { ...item, sequenceNumber: index + 1 };
      });
    }

    this.dataSource = new MatTableDataSource(this.formList);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  async getTableDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getTerminationDetailsByFilter(this.tableStatus, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
