import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TerminationRejectedTableComponent } from './termination-rejected-table.component';

describe('TerminationRejectedTableComponent', () => {
  let component: TerminationRejectedTableComponent;
  let fixture: ComponentFixture<TerminationRejectedTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TerminationRejectedTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TerminationRejectedTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
