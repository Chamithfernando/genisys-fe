import { Component, ViewChild, OnInit } from '@angular/core';
import {applyFilter, showErrorMessage} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {validateEnterSpecialCharacters} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {formatDate} from '@angular/common';
import {MatDatepickerInput} from '@angular/material/datepicker';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {
  TerminationDueAmountComponent
} from '@app/dashboard/advisor-management/termination-resignation/termination-due-amount/termination-due-amount.component';

@Component({
  selector: 'app-termination-finance-clearance-table',
  templateUrl: './termination-finance-clearance-table.component.html',
  styleUrls: ['./termination-finance-clearance-table.component.scss']
})
export class TerminationFinanceClearanceTableComponent implements OnInit {
  displayedColumns: string[] = ['sequenceNumber',  'agentName', 'branchName', 'designation',
    'requestingDate' , 'outstandingAmt', 'hasOutstanding', 'financeRemarks', 'action'];

  dataSource = new MatTableDataSource();

  dialogRef: MatDialogRef<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('startDateInput') startDateInput: MatDatepickerInput<Date>;
  @ViewChild('endDateInput') endDateInput: MatDatepickerInput<Date>;

  tableStatus: string;
  formListObj: any;
  formList: Array<any> = [];
  startDate: Date = null;
  endDate: Date = null;

  constructor(private authService: AuthService,
              private advisorService: AdvisorManagementService,
              private dialog: MatDialog) { }

  ngOnInit(): void {

    this.getFinanceDetails();
  }

  openDueAmount(e: any, formId: number, amount: string, remark: string) {

    const amountDetails = {
      id: formId,
      outstandingAmt: amount,
      financeRemarks: remark
    };

    this.dialogRef = this.dialog.open(TerminationDueAmountComponent, {
      width: '600px',
      data: amountDetails
    });

    this.dialogRef.afterClosed().subscribe((response) => {
      if (response) {
        this.dialogRef.close(true);
        this.getFinanceDetails();
      }
    });
  }

  applyFilter(event: Event) {
    applyFilter(this.dataSource, event);
  }

  validateEnterSpecialCharacters(event: Event) {
    validateEnterSpecialCharacters(event);
  }

  clear() {
    this.formList = [];
    this.dataSource = new MatTableDataSource(this.formList);

    this.startDate = null;
    this.endDate = null;
  }


  async getFinanceDetails() {
      this.formListObj = await this.getTableDetails().catch((error) => {
        console.log(error);
      });


      if (this.formListObj.status === 200) {

        this.formList = this.formListObj.data.map((item, index) => {
          return {...item, sequenceNumber: index + 1};
        });
      }

      this.dataSource = new MatTableDataSource(this.formList);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
  }

  async getTableDetails() {

    return new Promise((resolve, reject) => {
      this.advisorService
        .financeTable(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
