import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TerminationFinanceClearanceTableComponent } from './termination-finance-clearance-table.component';

describe('TerminationFinanceClearanceTableComponent', () => {
  let component: TerminationFinanceClearanceTableComponent;
  let fixture: ComponentFixture<TerminationFinanceClearanceTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TerminationFinanceClearanceTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TerminationFinanceClearanceTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
