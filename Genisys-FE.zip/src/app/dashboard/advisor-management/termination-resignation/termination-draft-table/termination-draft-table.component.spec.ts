import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TerminationDraftTableComponent } from './termination-draft-table.component';

describe('TerminationDraftTableComponent', () => {
  let component: TerminationDraftTableComponent;
  let fixture: ComponentFixture<TerminationDraftTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TerminationDraftTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TerminationDraftTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
