import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {showErrorMessage} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';

@Component({
  selector: 'app-termination-servicing-submit',
  templateUrl: './termination-servicing-submit.component.html',
  styleUrls: ['./termination-servicing-submit.component.scss']
})
export class TerminationServicingSubmitComponent implements OnInit {

  amountForm: FormGroup;
  formId: number;

  constructor(public dialogRef: MatDialogRef<TerminationServicingSubmitComponent>,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private formBuilder: FormBuilder) {

    this.amountForm = this.formBuilder.group({
      reason: new FormControl('', [Validators.required]),
    });
  }

  ngOnInit(): void {
  }

  validate() {

    if (!this.amountForm.value.remark.toString().trim()) {
      showErrorMessage('Remark is Required.');
      return false;
    }

    return true;
  }

}
