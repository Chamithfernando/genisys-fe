import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TerminationServicingSubmitComponent } from './termination-servicing-submit.component';

describe('TerminationServicingSubmitComponent', () => {
  let component: TerminationServicingSubmitComponent;
  let fixture: ComponentFixture<TerminationServicingSubmitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TerminationServicingSubmitComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TerminationServicingSubmitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
