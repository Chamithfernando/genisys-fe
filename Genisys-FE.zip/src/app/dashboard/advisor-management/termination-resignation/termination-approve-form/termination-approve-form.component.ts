import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {ActivatedRoute, Router} from '@angular/router';
import {
  formatNumber, IMS_REMARK_OPTIONS,
  Selector,
  SELECTOR_OPTIONS, showErrorMessage, showSucessMessage,
  TERMINATION_REASON
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {
  AddApproveStatusComponent
} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/add-approve-status/add-approve-status.component';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {DecimalPipe, formatDate} from '@angular/common';
import {
  OpenDocumentComponent
} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/open-document/open-document.component';
import {OpenPdfComponent} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/open-pdf/open-pdf.component';
import {SelectionModel} from '@angular/cdk/collections';

interface Scenario {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-termination-approve-form',
  templateUrl: './termination-approve-form.component.html',
  styleUrls: ['./termination-approve-form.component.scss']
})
export class TerminationApproveFormComponent implements OnInit {
  terminationForm: FormGroup;

  branchId: string;
  policyTransferType: string;
  dialogRef: MatDialogRef<any>;
  selectedFileName: string;
  formStatus: string;
  formId: number;
  formObj: any;
  agentCode: number;
  isDisabled = false;
  isUploadFile = false;

  reason: Selector[];
  selector: Selector[];
  imsRemark: Selector[];
  scenarios: Scenario[];
  agentsArray: Array<any> = [];
  sameAgentsArray: Array<any> = [];
  branchArray: Array<any> = [];
  tableList: Array<any> = [];

  displayedColumns: string[] = ['sequenceNumber', 'id', 'policyNo', 'policyStatus', 'policyHolder'];
  displayedPolicyColumns: string[] = ['sequenceNumber', 'addAgentName', 'addPolicyNo'];

  dataSource = new MatTableDataSource<any>();
  dataSourceAddPolicy = new MatTableDataSource<any>();
  selection = new SelectionModel<any>(true, []);

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('paginator2') paginator2: MatPaginator;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('sort2') sort2: MatSort;

  @ViewChild('fileInput') fileInput: ElementRef<HTMLInputElement>;

  constructor(private formBuilder: FormBuilder,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              private router: Router,
              private route: ActivatedRoute,
              private dialog: MatDialog,
              private decimalPipe: DecimalPipe) {

    this.terminationForm = this.formBuilder.group({
      terminationType: new FormControl('', [Validators.required]),
      branch: new FormControl('', [Validators.required]),
      agentCode: new FormControl('', [Validators.required]),
      address: new FormControl('', [Validators.required]),
      reason: new FormControl('', [Validators.required]),
      requestingDate: new FormControl(''),
      isPolicyTransfer: new FormControl('', [Validators.required]),
      scenario: new FormControl(''),
      lastAnp: new FormControl(''),
      lastGwp: new FormControl(''),
      lastNop: new FormControl(''),
      lastFyr: new FormControl(''),
      lastSyr: new FormControl(''),
      newAgentCode: new FormControl('', [Validators.required]),
      newAnp: new FormControl(''),
      newGwp: new FormControl(''),
      newNop: new FormControl(''),
      newFyr: new FormControl(''),
      newSyr: new FormControl(''),
      ImsRemark: new FormControl(''),
    });

    this.reason = TERMINATION_REASON;
    this.selector = SELECTOR_OPTIONS;
    this.imsRemark = IMS_REMARK_OPTIONS;
  }

  async ngOnInit(): Promise<void> {

    this.route.queryParams.subscribe(params => {
      this.formId = (params.formId);
      this.formStatus = (params.formStatus);

    });

    try {
      await Promise.all([this.allBranches(), this.getTerminationDetails()]);
    } catch (error) {
      console.error(error);
    }

  }

  openApproveStatus() {
    const elements = {
      id: this.formId,
      formTitle: 'termination'
    };

    this.dialogRef = this.dialog.open(AddApproveStatusComponent, {
      width: '600px',
      disableClose: true,
      data: elements,
    });

  }

  async allBranches() {
    const branchList: any = await this.getBranchList().catch((error) => {
      console.log(error);
    });
    if (branchList.status === 200) {
      this.branchArray = branchList.payload.sort((a, b) => a.branchName.localeCompare(b.branchName));
      this.isDisabled = true;
      this.terminationForm.get('newAgentCode').disable();
    }
  }

  async getBranchList() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAllBranches(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async allAgentsByBranch() {
    const agentsList: any = await this.getAgentsDetails().catch((error) => {
      console.log(error);
    });
    if (agentsList.status === 200) {
      this.agentsArray = agentsList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));
    }

  }

  async getAgentsDetails() {

    const branchCode = +this.branchId;

    return new Promise((resolve, reject) => {
      this.advisorService
        .getTerminationAgentsbyBranch(branchCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async allNewAgentsByBranch(selectedAgentCode: string) {
    const agentsList: any = await this.getNewAgentsDetails().catch((error) => {
      console.log(error);
    });

    if (agentsList.status === 200) {

      this.sameAgentsArray = agentsList.data
        .filter(agent => agent.agentCode !== selectedAgentCode)
        .sort((a, b) => a.agentName.localeCompare(b.agentName));
    }
  }

  async getNewAgentsDetails() {

    const branchCode = +this.branchId;

    return new Promise((resolve, reject) => {
      this.advisorService
        .getTerminationAgentsbyBranch(branchCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getTerminationDetails() {

    this.formObj = await this.getFormDetails().catch((error) => {
      console.log(error);
    });


    if (this.formObj.status === 200) {
      this.branchId = this.formObj.data.branchCode;

      let requestingDate = '';
      if (this.formObj.data.requestingDate) {
        const trimmedPeriodOfRequestingDate = this.formObj.data.requestingDate.substring(0, 10);
        if (trimmedPeriodOfRequestingDate !== '1970-01-01') {
          requestingDate = formatDate(trimmedPeriodOfRequestingDate, 'yyyy-MM-dd', 'en-US');
        }
      }

      await this.allAgentsByBranch();
      await this.allNewAgentsByBranch(this.formObj.data.agentCode);


      this.terminationForm.patchValue({
        terminationType: this.formObj.data.requestType,
        branch: this.formObj.data.branchCode.toString(),
        agentCode: this.formObj.data.agentCode,
        address: this.formObj.data.agentAddress,
        reason: this.formObj.data.subjectReason,
        requestingDate: requestingDate,
        lastAnp: formatNumber(this.formObj.data.performanceAnpLast6Months, this.decimalPipe),
        lastGwp: formatNumber(this.formObj.data.performanceGwpLast6Months, this.decimalPipe),
        lastNop: (this.formObj.data.performanceNopLast6Months),
        lastFyr: formatNumber(this.formObj.data.performanceFyrLast6Months, this.decimalPipe),
        lastSyr: formatNumber(this.formObj.data.performanceSyrLast6Months, this.decimalPipe),
        isPolicyTransfer: this.formObj.data.policyTransfer?.toString() ?? '',
        scenario: this.formObj.data.policyTransferType
      });
      this.policyTransferType = this.formObj.data.policyTransferType;
      this.isUploadFile = this.formObj.data.hasEndServiceFile;

      await Promise.all([
        this.getPolicyRequest(this.formObj.data.agentCode),
      ]);

      await this.loadTransferData(this.formObj.data.transferData);
    }
  }

  getFormDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .terminationDetailsGetById(this.formId)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  loadTransferData(transferData: any) {
    this.dataSourceAddPolicy.data = [];

    let sequenceNumber = 1;
    for (const agentCode in transferData) {
      if (transferData.hasOwnProperty(agentCode)) {
        const policyNumbers = transferData[agentCode];


        const agent = this.sameAgentsArray.find(agent => agent.agentCode === agentCode);
        const agentName = agent ? agent.agentName : '';


        const combinedPolicyNumbers = policyNumbers.join(', ');


        this.dataSourceAddPolicy.data.push({
          sequenceNumber: sequenceNumber++,
          addAgentCode: agentCode,
          addAgentName: agentName,
          addPolicyNo: combinedPolicyNumbers
        });
      }
    }


    this.dataSourceAddPolicy._updateChangeSubscription();
    this.dataSourceAddPolicy.paginator = this.paginator2;
    this.dataSourceAddPolicy.sort = this.sort2;
  }

  async getLast6Performance(code: string) {
    const agentCode = code;
    const performanceDetails: any = await this.getPerformance(agentCode).catch((error) => {
      console.log(error);
    });

    if (performanceDetails.status === 200) {
      const performance = performanceDetails.data;
      if (performance) {
        this.terminationForm.patchValue({
          lastAnp: performance.anp,
          lastGwp: performance.gwp,
          lastNop: performance.nop,
          lastFyr: performance.fyr,
          lastSyr: performance.syr,

        });
      }
    }
  }

  async getNewPerformance(code: string) {
    const agentCode = code;
    const performanceDetails: any = await this.getPerformance(agentCode).catch((error) => {
      console.log(error);
    });
    if (performanceDetails.status === 200) {
      const performance = performanceDetails.data;
      if (performance) {
        this.terminationForm.patchValue({
          newAnp: performance.anp,
          newGwp: performance.gwp,
          newNop: performance.nop,
          newFyr: performance.fyr,
          newSyr: performance.syr,

        });
      }
    }
  }

  getPerformance(agentCode: string) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .last6Performance(agentCode)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getPolicyRequest(code: string) {
    const agentCode = code;

    const policyList: any = await this.getTableDetails(agentCode).catch((error) => {
      console.log(error);
    });

    if (policyList.status === 200) {
      this.tableList = policyList.data.map((item, index) => {
        return {...item, sequenceNumber: index + 1};
      });
    }

    this.dataSource = new MatTableDataSource(this.tableList);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  getTableDetails(agentCode: string) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .policyTransferDetails(agentCode)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  openLetterPdf() {

    const details = {
      id: this.formId,
      title: 'terminationUploadFile'
    };

    this.dialogRef = this.dialog.open(OpenPdfComponent, {
      width: '1150px',
      data: details
    });
  }

  displayLetter() {

    this.advisorService.openTerminationDocument(this.formId).subscribe(
      (pdfData) => {

        if (pdfData.status === 200) {
          let blob;
          let fileURL;

          blob = this.convertPdfFile(pdfData.byteArray, 'application/pdf');
          fileURL = URL.createObjectURL(blob);

          this.openDocument(fileURL, pdfData.data.fileType);

        } else {
          showErrorMessage(pdfData.message);
          this.dialogRef.close(true);
        }

      },
      (error) => {
        console.error('Error getting PDF data:', error);
      }
    );
  }

  convertPdfFile(b64Data, contentType) {
    contentType = contentType || '';
    let sliceSize = 512;

    var byteCharacters = atob(b64Data);
    var byteArrays = [];

    for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      var slice = byteCharacters.slice(offset, offset + sliceSize);

      var byteNumbers = new Array(slice.length);
      for (var i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }

      var byteArray = new Uint8Array(byteNumbers);

      byteArrays.push(byteArray);
    }

    var blob = new Blob(byteArrays, {type: contentType});
    return blob;
  }

  openDocument(fileURL: string, docType: string): void {

    this.dialogRef = this.dialog.open(OpenDocumentComponent, {
      width: '1150px',
      data: {
        pdfSrc: fileURL,
        fileType: 'pdf'
      }
    });
  }

  validate() {

    const validationRules = [
      {field: 'terminationType', message: 'Please Update IMS Status.'},
    ];

    for (const rule of validationRules) {
      if (!this.terminationForm.value[rule.field]) {
        showErrorMessage(rule.message);
        return false;
      }
    }

    return true;
  }

  async saveImsRemark() {
    if (this.validate()) {

      const data = {
        id: this.formId,
        remark: this.terminationForm.value.ImsRemark,
      };

      const saveResponse: any = await this.updateRemark(data).catch(
        (err) => {
          console.log(err);
        }
      );

      if (saveResponse.status === 200) {
        showSucessMessage(saveResponse.message);
        this.router.navigate(['/dashboard/advisor-management/termination-servicing']);
      } else {
        showErrorMessage(saveResponse.payload.message);
      }

    }
  }

  updateRemark(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .updateServicingRemark(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


}
