import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TerminationApproveFormComponent } from './termination-approve-form.component';

describe('TerminationApproveFormComponent', () => {
  let component: TerminationApproveFormComponent;
  let fixture: ComponentFixture<TerminationApproveFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TerminationApproveFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TerminationApproveFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
