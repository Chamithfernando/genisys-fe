import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {
  formatNumber,
  showErrorMessage,
  showSucessMessage
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {DecimalPipe, formatDate} from '@angular/common';
import {Router} from '@angular/router';

@Component({
  selector: 'app-termination-due-amount',
  templateUrl: './termination-due-amount.component.html',
  styleUrls: ['./termination-due-amount.component.scss']
})
export class TerminationDueAmountComponent implements OnInit {

  amountForm: FormGroup;
  formId: number;
  amount: string;
  remark: string;

  constructor(public dialogRef: MatDialogRef<TerminationDueAmountComponent>,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private formBuilder: FormBuilder,
              private router: Router,
              private decimalPipe: DecimalPipe) {

    this.amountForm = this.formBuilder.group({
      amount: new FormControl('',[Validators.required] ),
      reason: new FormControl(''),
    });
  }

  ngOnInit(): void {

    this.amount = formatNumber(this.data.outstandingAmt, this.decimalPipe);
    this.remark = this.data.financeRemarks;

  }

  validate() {

    if (!this.amountForm.value.amount) {
      showErrorMessage('Amount is Required');
      return false;
    }

    return true;
  }

  async updateDueAmount() {
    if (this.validate()) {

      const data = {
        id:  this.data.id,
        amount: parseFloat(this.amountForm.value.amount.replace(/,/g, '')),
        remark: this.amountForm.value.reason,
      };

      const saveResponse: any = await this.saveAmount(data).catch(
        (err) => {
          console.log(err);
        }
      );


      if (saveResponse.status === 200) {
        showSucessMessage(saveResponse.message);
        this.dialogRef.close(true);
        this.router.navigate(['/dashboard/advisor-management/termination-finance']);

      } else {
        showErrorMessage(saveResponse.payload.message);
      }

    }
  }

  saveAmount(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .setDueAmount(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
