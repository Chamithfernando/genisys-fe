import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TerminationRejcetReasonComponent } from './termination-rejcet-reason.component';

describe('TerminationRejcetReasonComponent', () => {
  let component: TerminationRejcetReasonComponent;
  let fixture: ComponentFixture<TerminationRejcetReasonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TerminationRejcetReasonComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TerminationRejcetReasonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
