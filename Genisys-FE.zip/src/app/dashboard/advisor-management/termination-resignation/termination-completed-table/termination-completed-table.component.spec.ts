import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TerminationCompletedTableComponent } from './termination-completed-table.component';

describe('TerminationCompletedTableComponent', () => {
  let component: TerminationCompletedTableComponent;
  let fixture: ComponentFixture<TerminationCompletedTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TerminationCompletedTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TerminationCompletedTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
