import { Component, OnInit, ViewChild } from '@angular/core';
import {applyFilter, showErrorMessage} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {validateEnterSpecialCharacters} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {ActivatedRoute, Router} from '@angular/router';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {
  TerminationApprovalLevelsComponent
} from '@app/dashboard/advisor-management/termination-resignation/termination-approval-levels/termination-approval-levels.component';
import {OpenPdfComponent} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/open-pdf/open-pdf.component';
import {formatDate} from '@angular/common';
import * as fileSaver from 'file-saver';
import {
  TerminationRejcetReasonComponent
} from '@app/dashboard/advisor-management/termination-resignation/termination-rejcet-reason/termination-rejcet-reason.component';


@Component({
  selector: 'app-termination-completed-table',
  templateUrl: './termination-completed-table.component.html',
  styleUrls: ['./termination-completed-table.component.scss']
})
export class TerminationCompletedTableComponent implements OnInit {

  formId: number;
  tableStatus: string;
  formListObj: any;
  userDetails: any;
  hideSFAFeatures = true;
  formList: Array<any> = [];

  dialogRef: MatDialogRef<any>;

  displayedColumns: string[] = ['sequenceNumber', 'id', 'agentName', 'branchName', 'requestingDate',
    'reason' ,  'approveLevels', 'view', 'download'];


  dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private router: Router,
              private route: ActivatedRoute,
              private authService: AuthService,
              private advisorService: AdvisorManagementService,
              private dialog: MatDialog) { }

  ngOnInit(): void {

    this.getLoginUser();
    this.getTerminationDetails();
  }

  async getLoginUser() {
    this.userDetails = await this.getUserDetails().catch((error) => {
      console.log(error);
    });

    if (this.userDetails.status === 'OK') {
      const roleName = this.userDetails.data.roleDto.roleName;
      if (['SFA'].includes(roleName)) {
        this.hideSFAFeatures = false;
      }
    }
  }

  rejectApplication(e: any, element: number) {
    const rejectDetails = {
      id: element,
      title: 'approved'
    };

    this.dialogRef = this.dialog.open(TerminationRejcetReasonComponent, {
      width: '600px',
      data: rejectDetails,
    });
  }
  async getUserDetails() {
    return new Promise((resolve, reject) => {

      this.authService
        .getPermission()
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  applyFilter(event: Event) {
    applyFilter(this.dataSource, event);
  }

  validateEnterSpecialCharacters(event: Event) {
    validateEnterSpecialCharacters(event);
  }

  openApprovalLevels(e: any, element: number) {
    this.dialogRef = this.dialog.open(TerminationApprovalLevelsComponent, {
      width: '600px',
      data: element
    });
  }

  openLetterPdf(e: any, element: number){

    const details = {
      id: element,
      title: 'termination'
    };

    this.dialogRef = this.dialog.open(OpenPdfComponent, {
      width: '1150px',
      data: details
    });
  }

  downloadLetter(e: any, element: number): void {
    this.formId = element;
    const currentDate = new Date();
    const formattedCreateDate = formatDate(currentDate, 'yyyy_MM_dd HH:mm', 'en-US');

    this.advisorService.downloadTerminationLetter(this.formId)
      .subscribe(
        (response: any) => {

          if (response.size > 100) {
            const filename = `Letter_${formattedCreateDate}.pdf`;
            this.saveFile(response, filename, 'application/pdf');
          }
          else if (response.payload.code === 400){
            showErrorMessage(response.payload.message);
          }
          else {
            showErrorMessage('Document Download Failed.');
          }
        },
      );
  }

  private saveFile(data: Blob, filename?: string, mimeType?: string): void {
    const blob = new Blob([data], { type: mimeType || 'application/octet-stream' });
    fileSaver.saveAs(blob, filename || 'file.pdf');
  }

  async getTerminationDetails() {

    this.tableStatus = 'APPROVED';

    this.formListObj = await this.getTableDetails().catch((error) => {
      console.log(error);
    });

    if (this.formListObj.status === 200) {

      this.formList = this.formListObj.data.map((item, index) => {
        return { ...item, sequenceNumber: index + 1 };
      });
    }

    this.dataSource = new MatTableDataSource(this.formList);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  async getTableDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getTerminationDetailsByFilter(this.tableStatus, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }



}
