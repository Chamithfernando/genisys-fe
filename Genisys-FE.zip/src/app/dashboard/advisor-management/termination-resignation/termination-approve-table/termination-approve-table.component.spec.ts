import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TerminationApproveTableComponent } from './termination-approve-table.component';

describe('TerminationApproveTableComponent', () => {
  let component: TerminationApproveTableComponent;
  let fixture: ComponentFixture<TerminationApproveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TerminationApproveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TerminationApproveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
