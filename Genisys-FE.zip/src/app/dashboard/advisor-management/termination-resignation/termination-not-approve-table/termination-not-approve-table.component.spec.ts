import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TerminationNotApproveTableComponent } from './termination-not-approve-table.component';

describe('TerminationNotApproveTableComponent', () => {
  let component: TerminationNotApproveTableComponent;
  let fixture: ComponentFixture<TerminationNotApproveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TerminationNotApproveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TerminationNotApproveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
