import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';

@Component({
  selector: 'app-all-termination-table',
  templateUrl: './all-termination-table.component.html',
  styleUrls: ['./all-termination-table.component.scss']
})
export class AllTerminationTableComponent implements OnInit {

  token: any;
  userDetails: any;
  branchCode: string;
  fname: string;
  lname: string;
  hideFeatures = false;
  hideSFAFeatures = false;
  constructor(private router: Router,
              private authService: AuthService,
              private advisorService: AdvisorManagementService,
              private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.token = this.authService.getCurrentUserDetails().access_token;
    this.getUserData(this.token);
    this.getLoginUser();
  }

  addNewForm() {
    this.router.navigate([ '../termination-form'], {
      relativeTo: this.route,
      queryParams: {
        branchCode : this.branchCode,
      }
    });
  }



  async getUserData(token: string) {
    const loggedUserDataObj: any = await this.dashboardListing(token).catch((err) => {
      console.log(err);
    });

    if (loggedUserDataObj.status === 200 && loggedUserDataObj.branchResponse.branchDTOList.length > 0) {
      this.branchCode  = loggedUserDataObj.branchResponse.branchDTOList[0].branchCode;

    }
  }

  async dashboardListing(token: string) {
    return new Promise((resolve, reject) => {
      this.advisorService.onInitFunction(token).subscribe(data => {
        resolve(data);
      }, error => {
        reject(error);
      });
    });
  }


  async getLoginUser() {
    this.userDetails = await this.getUserDetails().catch((error) => {
      console.log(error);
    });

    if (this.userDetails.status === 'OK') {
      const roleName = this.userDetails.data.roleDto.roleName;
      if (['Zonal Manager', 'SFA'].includes(roleName)) {
        this.hideFeatures = true;
      }

      if (['SFA'].includes(roleName)) {
        this.hideSFAFeatures = true;
      }

    }
  }

  async getUserDetails() {
    return new Promise((resolve, reject) => {

      this.authService
        .getPermission()
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
