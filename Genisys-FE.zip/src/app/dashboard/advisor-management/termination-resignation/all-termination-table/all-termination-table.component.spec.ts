import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllTerminationTableComponent } from './all-termination-table.component';

describe('AllTerminationTableComponent', () => {
  let component: AllTerminationTableComponent;
  let fixture: ComponentFixture<AllTerminationTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllTerminationTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AllTerminationTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
