import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TerminationEditFormComponent } from './termination-edit-form.component';

describe('TerminationEditFormComponent', () => {
  let component: TerminationEditFormComponent;
  let fixture: ComponentFixture<TerminationEditFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TerminationEditFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TerminationEditFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
