import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TerminationApprovalLevelsComponent } from './termination-approval-levels.component';

describe('TerminationApprovalLevelsComponent', () => {
  let component: TerminationApprovalLevelsComponent;
  let fixture: ComponentFixture<TerminationApprovalLevelsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TerminationApprovalLevelsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TerminationApprovalLevelsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
