import {AfterViewInit, Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {ActivatedRoute, Router} from '@angular/router';
import {
  Selector,
  SELECTOR_OPTIONS, showErrorMessage, showSucessMessage, showWarningMessage, formatNumber,
  TERMINATION_REASON
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {addressValidate} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {formatDate} from '@angular/common';
import {DecimalPipe} from '@angular/common';
import {SelectionModel} from '@angular/cdk/collections';
import {applyFilter} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {validateEnterSpecialCharacters} from '@app/dashboard/advisor-management/utilities/validation/validation.component';

interface Scenario {
  value: string;
  viewValue: string;
}

export interface Element {
  sequenceNumber: number;
  id: string;
  policyNo: string;
  policyStatus: string;
  policyHolder: string;
}

@Component({
  selector: 'app-termination-form',
  templateUrl: './termination-form.component.html',
  styleUrls: ['./termination-form.component.scss']
})
export class TerminationFormComponent implements OnInit, AfterViewInit {
  terminationForm: FormGroup;

  branchId: string;
  fileToUpload: File;
  letterUrl: string;
  agentCode: number;
  selectedFileName: string;
  selectedAgent: any;
  isDisabled = false;

  reason: Selector[];
  selector: Selector[];
  scenarios: Scenario[];
  agentsArray: Array<any> = [];
  branchArray: Array<any> = [];
  tableList: Array<any> = [];
  sameAgentsArray: Array<any> = [];

  displayedColumns: string[] = ['sequenceNumber', 'id', 'policyNo', 'policyStatus',
    'policyHolder', 'select'];

  displayedPolicyColumns: string[] = ['sequenceNumber', 'addAgentCode', 'addAgentName', 'addPolicyNo', 'remove'];

  dataSource = new MatTableDataSource<any>();
  dataSourceAddPolicy = new MatTableDataSource<any>();
  selection = new SelectionModel<any>(true, []);

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('paginator2') paginator2: MatPaginator;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('sort2') sort2: MatSort;

  @ViewChild('fileInput') fileInput: ElementRef<HTMLInputElement>;

  constructor(private formBuilder: FormBuilder,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              private router: Router,
              private route: ActivatedRoute,
              private decimalPipe: DecimalPipe) {

    this.terminationForm = this.formBuilder.group({
      terminationType: new FormControl('', [Validators.required]),
      branch: new FormControl('', [Validators.required]),
      agentCode: new FormControl('', [Validators.required]),
      address: new FormControl('', [Validators.required]),
      reason: new FormControl('', [Validators.required]),
      requestingDate: new FormControl('', [Validators.required]),
      isPolicyTransfer: new FormControl('', [Validators.required]),
      scenario: new FormControl(''),
      lastAnp: new FormControl(''),
      lastGwp: new FormControl(''),
      lastNop: new FormControl(''),
      lastFyr: new FormControl(''),
      lastSyr: new FormControl(''),
      newAgentCode: new FormControl('', [Validators.required]),
      newAnp: new FormControl(''),
      newGwp: new FormControl(''),
      newNop: new FormControl(''),
      newFyr: new FormControl(''),
      newSyr: new FormControl('')
    });

    this.reason = TERMINATION_REASON;
    this.selector = SELECTOR_OPTIONS;

  }


  async ngOnInit(): Promise<void> {

    this.route.queryParams.subscribe(params => {
      this.branchId = (params.branchCode);
    });

    console.log('termination this.branchId', this.branchId);
    this.terminationForm.get('branch').setValue(this.branchId);

    try {
      await Promise.all([this.allBranches(), this.allAgentsByBranch()]);
    } catch (error) {
      console.error(error);
    }
  }

  addressValidate(event: Event) {
    addressValidate(event);
  }

  applyFilter(event: Event) {
    applyFilter(this.dataSource, event);
  }

  applyFilterPolicyTable(event: Event) {
    applyFilter(this.dataSourceAddPolicy, event);
  }

  validateEnterSpecialCharacters(event: Event) {
    validateEnterSpecialCharacters(event);
  }

  clearPolicyRequestData(isPolicyTransferValue: string) {

    if (isPolicyTransferValue === 'false') {
      this.terminationForm.get('scenario').reset();
      this.terminationForm.get('newAgentCode').reset();
      this.terminationForm.get('newAnp').reset();
      this.terminationForm.get('newGwp').reset();
      this.terminationForm.get('newNop').reset();
      this.terminationForm.get('newFyr').reset();
      this.terminationForm.get('newSyr').reset();

    }
  }

  clearRequestData() {

    this.terminationForm.get('newAnp').reset();
    this.terminationForm.get('newGwp').reset();
    this.terminationForm.get('newNop').reset();
    this.terminationForm.get('newFyr').reset();
    this.terminationForm.get('newSyr').reset();

  }

  onChangeAgentClearData() {

    this.terminationForm.get('isPolicyTransfer').reset();
    this.terminationForm.get('scenario').reset();
    this.terminationForm.get('newAgentCode').reset();
    this.terminationForm.get('newAnp').reset();
    this.terminationForm.get('newGwp').reset();
    this.terminationForm.get('newNop').reset();
    this.terminationForm.get('newFyr').reset();
    this.terminationForm.get('newSyr').reset();

    this.dataSource.data = [];
    this.dataSourceAddPolicy.data = [];
    this.selection.clear();
  }

  async allBranches() {
    const branchList: any = await this.getBranchList().catch((error) => {
      console.log(error);
    });
    if (branchList.status === 200) {
      this.branchArray = branchList.payload.sort((a, b) => a.branchName.localeCompare(b.branchName));
      this.isDisabled = true;
    }
  }

  getBranchList() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAllBranches(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async allAgentsByBranch() {
    const agentsList: any = await this.getAgentsDetails().catch((error) => {
      console.log(error);
    });
    if (agentsList.status === 200) {
      this.agentsArray = agentsList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));
      this.onChangeAgentClearData();

    }
  }

  async getAgentsDetails() {

    const branchCode = +this.branchId;

    return new Promise((resolve, reject) => {
      this.advisorService
        .getTerminationAgentsbyBranch(branchCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async allNewAgentsByBranch(selectedAgentCode: string) {

    const agentsList: any = await this.getNewAgentsDetails().catch((error) => {
      console.log(error);
    });

    if (agentsList.status === 200) {

      this.sameAgentsArray = agentsList.data
        .filter(agent => agent.agentCode !== selectedAgentCode)
        .sort((a, b) => a.agentName.localeCompare(b.agentName));
      this.clearRequestData();
    }
  }

  async getNewAgentsDetails() {

    const branchCode = +this.branchId;

    return new Promise((resolve, reject) => {
      this.advisorService
        .getTerminationAgentsbyBranch(branchCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


  async getLast6Performance(event: any) {
    const agentCode = event.value;
    const performanceDetails: any = await this.getPerformance(agentCode).catch((error) => {
      console.log(error);
    });
    if (performanceDetails.status === 200) {
      const performance = performanceDetails.data;
      if (performance) {
        this.terminationForm.patchValue({
          lastAnp: formatNumber(performance.anp, this.decimalPipe),
          lastGwp: formatNumber(performance.gwp, this.decimalPipe),
          lastNop: performance.nop,
          lastFyr: formatNumber(performance.fyr, this.decimalPipe),
          lastSyr: formatNumber(performance.syr, this.decimalPipe),

        });
      }
    }

    this.onChangeAgentClearData();
    this.getPolicyRequest(this.terminationForm.value.agentCode);
  }

  async getNewPerformance(event: any) {
    const agentCode = event.value;
    const performanceDetails: any = await this.getPerformance(agentCode).catch((error) => {
      console.log(error);
    });
    if (performanceDetails.status === 200) {
      const performance = performanceDetails.data;
      if (performance) {
        this.terminationForm.patchValue({
          newAnp: formatNumber(performance.anp, this.decimalPipe),
          newGwp: formatNumber(performance.gwp, this.decimalPipe),
          newNop: performance.nop,
          newFyr: formatNumber(performance.fyr, this.decimalPipe),
          newSyr: formatNumber(performance.syr, this.decimalPipe),

        });
      }
    }

  }

  async getPerformance(agentCode: string) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .last6Performance(agentCode)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  fileUpload() {
    this.fileInput.nativeElement.click();
  }

  onFileSelected(event: any) {
    const file: File = event.target.files[0];

    const fileType = this.getFileType(file);
    if (fileType === 'pdf') {
      this.fileToUpload = file;
      this.convertToBase64(file);
      this.selectedFileName = file.name;
    } else {
      showWarningMessage('Invalid file type. Please upload a pdf file.');
    }
  }

  convertToBase64(file: File) {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const base64String = reader.result as string;
      const base64WithoutPath = base64String.split(',')[1];
      this.letterUrl = base64WithoutPath;
    };
    reader.onerror = (error) => {
      console.error('Error: ', error);
    };
  }

  getFileType(file: File): string {
    const fileName = file.name.toLowerCase();
    if (fileName.endsWith('.pdf')) {
      return 'pdf';
    } else {
      return '';
    }
  }

  async getPolicyRequest(code: string) {
    const agentCode = code;

    const policyList: any = await this.getTableDetails(agentCode).catch((error) => {
      console.log(error);
    });

    if (policyList.status === 200) {
      this.tableList = policyList.data.map((item, index) => {
        return {...item, sequenceNumber: index + 1};
      });
    }

    this.dataSource = new MatTableDataSource(this.tableList);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;

  }

  async getTableDetails(agentCode: string) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .policyTransferDetails(agentCode)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  isAllSelected() {
    if (!this.paginator) {
      return false;
    }
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.filteredData.slice
    (this.paginator.pageIndex * this.paginator.pageSize, (this.paginator.pageIndex + 1) * this.paginator.pageSize).length;
    return numSelected === numRows && numRows > 0;
  }

  masterToggle() {
    if (!this.paginator) {
      return;
    }
    const currentPageData = this.dataSource.filteredData.slice
    (this.paginator.pageIndex * this.paginator.pageSize, (this.paginator.pageIndex + 1) * this.paginator.pageSize);
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }
    this.selection.select(...currentPageData);
  }

  checkboxLabel(row?: Element): string {
    if (!row) {
      return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.sequenceNumber}`;
  }


  onAddPolicy() {

    if (!this.terminationForm.value.newAgentCode || !this.selection.hasValue()) {
      showWarningMessage('Please select a New Agent and at least one Policy No to proceed.');
      return;
    }

    const selectedPolicies = this.selection.selected;
    const newAgentCode = this.terminationForm.get('newAgentCode')?.value;
    const newAgentName = this.sameAgentsArray.find(agent => agent.agentCode === newAgentCode)?.agentName;

    const uniquePolicyNumbers = new Set<string>();

    selectedPolicies.forEach(policy => {
      uniquePolicyNumbers.add(policy.policyNo);
    });

    const policyNumbersString = Array.from(uniquePolicyNumbers).join(', ');

    const existingPoliciesInAddPolicy = this.dataSourceAddPolicy.data.reduce((acc, item) => {
      return acc.concat(item.addPolicyNo.split(', '));
    }, []);

    const duplicates = Array.from(uniquePolicyNumbers).filter(policyNo =>
      existingPoliciesInAddPolicy.includes(policyNo)
    );

    if (duplicates.length > 0) {
      showWarningMessage(`Duplicate Policy No: ${duplicates.join(', ')}`);
      return;
    }

    const existingEntry = this.dataSourceAddPolicy.data.find(item => item.addAgentName === newAgentName);

    if (existingEntry) {

      const existingPolicyNumbers = existingEntry.addPolicyNo.split(', ');
      const allPolicyNumbers = new Set([...existingPolicyNumbers, ...uniquePolicyNumbers]);
      existingEntry.addPolicyNo = Array.from(allPolicyNumbers).join(', ');
    } else {

      this.dataSourceAddPolicy.data.push({
        sequenceNumber: this.dataSourceAddPolicy.data.length + 1,
        addAgentCode: newAgentCode,
        addAgentName: newAgentName,
        addPolicyNo: policyNumbersString
      });
    }

    this.dataSourceAddPolicy._updateChangeSubscription();
    this.dataSourceAddPolicy.paginator = this.paginator2;
    this.dataSourceAddPolicy.sort = this.sort2;
    this.selection.clear();
  }

  onDelete(element: any) {
    const index = this.dataSourceAddPolicy.data.indexOf(element);

    if (index >= 0) {

      this.dataSourceAddPolicy.data.splice(index, 1);
      this.updateSequenceNumbers();
      this.dataSourceAddPolicy._updateChangeSubscription();
    }
  }

  updateSequenceNumbers() {
    this.dataSourceAddPolicy.data.forEach((item, index) => {
      item.sequenceNumber = index + 1;
    });
  }


  clear() {
    const controlsToClear = [
      'terminationType',
      'agentCode',
      'address',
      'reason',
      'requestingDate',
      'isPolicyTransfer',
      'scenario',
      'lastAnp',
      'lastGwp',
      'lastNop',
      'lastFyr',
      'lastSyr',
      'newAgentCode',
      'newAnp',
      'newGwp',
      'newNop',
      'newFyr',
      'newSyr',
    ];

    controlsToClear.forEach(controlName => {
      this.terminationForm.get(controlName).setValue('');
      this.terminationForm.get(controlName).clearValidators();
      this.terminationForm.get(controlName).updateValueAndValidity();
    });

    this.terminationForm.get('terminationType').setValidators([Validators.required]);
    this.terminationForm.get('agentCode').setValidators([Validators.required]);
    this.terminationForm.get('address').setValidators([Validators.required]);
    this.terminationForm.get('reason').setValidators([Validators.required]);
    this.terminationForm.get('isPolicyTransfer').setValidators([Validators.required]);


    this.terminationForm.updateValueAndValidity();

    this.fileToUpload = null;
    this.selectedFileName = '';
    this.dataSource = new MatTableDataSource([]);
    this.dataSourceAddPolicy = new MatTableDataSource([]);
    this.selection.clear();

  }

  validate() {

    const validationRules = [
      {field: 'terminationType', message: 'Request Type is Required.'},
      {field: 'branch', message: 'Branch is Required.'},
      {field: 'agentCode', message: 'Agent is Required.'},
      {field: 'reason', message: 'Reason is Required.'},
      {field: 'requestingDate', message: 'Requesting Date is Required.'},
      {field: 'isPolicyTransfer', message: 'Policy Transfer is Required.'},
    ];

    for (const rule of validationRules) {
      if (!this.terminationForm.value[rule.field]) {
        showErrorMessage(rule.message);
        return false;
      }
    }

    if (!this.terminationForm.value.address.toString().trim()) {
      showErrorMessage('Address is Required.');
      return false;
    }


    if (this.terminationForm.value.terminationType === 'RESIGNATION' && !this.fileToUpload) {
      showErrorMessage('Please Upload Termination/ Resignation Letter.');
      return false;
    }

    if (this.terminationForm.value.isPolicyTransfer === 'true') {
      const allPolicyNumbers = this.dataSource.data.map(policy => policy.policyNo);
      const allocatedPolicyNumbers = this.dataSourceAddPolicy.data.reduce((acc, item) => {
        return acc.concat(item.addPolicyNo.split(', '));
      }, []);

      const unallocatedPolicies = allPolicyNumbers.filter(policyNo =>
        !allocatedPolicyNumbers.includes(policyNo)
      );

      console.log('unallocatedPolicies.length', unallocatedPolicies.length);
      if (unallocatedPolicies.length > 0) {
        showErrorMessage('Please allocate all policy numbers to new agents ');
        return false;
      }
    }

    return true;
  }

  createTransferData() {
    const transferData = {};

    this.dataSourceAddPolicy.data.forEach(element => {
      const agentCode = element.addAgentCode;
      const policyNo = element.addPolicyNo;

      if (!transferData[agentCode]) {
        transferData[agentCode] = [];
      }


      const policyNumbers = policyNo.split(',').map(p => p.trim());


      transferData[agentCode].push(...policyNumbers);
    });

    return transferData;
  }


  async saveTerminationForm() {
    if (this.validate()) {

      const transferPolicyData = this.createTransferData();

      const data = {
        requestType: this.terminationForm.value.terminationType,
        branchCode: this.terminationForm.value.branch,
        agentCode: this.terminationForm.value.agentCode,
        agentAddress: this.terminationForm.value.address,
        subjectReason: this.terminationForm.value.reason,
        requestingDate: formatDate(this.terminationForm.value.requestingDate ? this.terminationForm.value.requestingDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
        policyTransfer: this.terminationForm.value.isPolicyTransfer,
        policyTransferType: !this.terminationForm.value.scenario ? 'NO_TRANSFER' : this.terminationForm.value.scenario,
        hasEndServiceFile: this.letterUrl ? true : false,
        endServiceFileUrl: this.letterUrl,
        newAgentCode: this.terminationForm.value.newAgentCode,
        transferData: transferPolicyData
      };

      console.log('Save data', data);

      const saveResponse: any = await this.saveForm(data).catch(
        (err) => {
          console.log(err);
        }
      );


      if (saveResponse.status === 201) {
        showSucessMessage(saveResponse.message);
        this.router.navigate(['/dashboard/advisor-management/all-termination-table']);
        this.clear();
      } else {
        showErrorMessage(saveResponse.payload.message);
      }

    }
  }

  saveForm(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .submitTerminationForm(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async draftTerminationForm() {

    const transferPolicyData = this.createTransferData();

    const data = {
      requestType: this.terminationForm.value.terminationType,
      branchCode: this.terminationForm.value.branch,
      agentCode: this.terminationForm.value.agentCode,
      agentAddress: this.terminationForm.value.address,
      subjectReason: this.terminationForm.value.reason,
      requestingDate: formatDate(this.terminationForm.value.requestingDate ? this.terminationForm.value.requestingDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
      policyTransfer: this.terminationForm.value.isPolicyTransfer,
      policyTransferType: !this.terminationForm.value.scenario ? 'NO_TRANSFER' : this.terminationForm.value.scenario,
      hasEndServiceFile: this.letterUrl ? true : false,
      endServiceFileUrl: this.letterUrl,
      newAgentCode: this.terminationForm.value.newAgentCode,
      transferData: transferPolicyData

    };

    console.log('Draft Data', data);
    const saveResponse: any = await this.draftForm(data).catch(
      (err) => {
        console.log(err);
      }
    );


    if (saveResponse.status === 201) {
      showSucessMessage(saveResponse.message);
      this.router.navigate(['/dashboard/advisor-management/all-termination-table']);
      this.clear();
    } else {
      showErrorMessage(saveResponse.payload.message);
    }
  }

  draftForm(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .draftTerminationForm(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


}
