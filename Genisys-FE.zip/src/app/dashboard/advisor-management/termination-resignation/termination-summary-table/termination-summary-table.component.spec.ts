import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TerminationSummaryTableComponent } from './termination-summary-table.component';

describe('TerminationSummaryTableComponent', () => {
  let component: TerminationSummaryTableComponent;
  let fixture: ComponentFixture<TerminationSummaryTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TerminationSummaryTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TerminationSummaryTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
