import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {AdvisorManagementComponent} from '@app/dashboard/advisor-management/advisor-management.component';
import {CreateFormComponent} from '@app/dashboard/advisor-management/promotion-demotion/create-form/create-form.component';
import {ViewTableComponent} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/view-table/view-table.component';
import {
  ApproveFormComponent
} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/approve-form/approve-form.component';
import {EditFormComponent} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/edit-form/edit-form.component';
import {
  AllTransferDataTableComponent
} from '@app/dashboard/advisor-management/code&team-transfers/all-transfer-data-table/all-transfer-data-table.component';
import {TransferFormComponent} from '@app/dashboard/advisor-management/code&team-transfers/transfer-form/transfer-form.component';
import {
  TransferEditFormComponent
} from '@app/dashboard/advisor-management/code&team-transfers/transfer-edit-form/transfer-edit-form.component';
import {
  TransferApproveFormComponent
} from '@app/dashboard/advisor-management/code&team-transfers/transfer-approve-form/transfer-approve-form.component';
import {
  AllTerminationTableComponent
} from '@app/dashboard/advisor-management/termination-resignation/all-termination-table/all-termination-table.component';
import {
  TerminationFormComponent
} from '@app/dashboard/advisor-management/termination-resignation/termination-form/termination-form.component';
import {
  TerminationEditFormComponent
} from '@app/dashboard/advisor-management/termination-resignation/termination-edit-form/termination-edit-form.component';
import {
  TerminationApproveFormComponent
} from '@app/dashboard/advisor-management/termination-resignation/termination-approve-form/termination-approve-form.component';
import {
  TerminationFinanceClearanceTableComponent
} from '@app/dashboard/advisor-management/termination-resignation/termination-finance-clearance-table/termination-finance-clearance-table.component';
import {
  TerminationServicingComponent
} from '@app/dashboard/advisor-management/termination-resignation/termination-servicing/termination-servicing.component';
import {
  AllPolicyTransferTableComponent
} from '@app/dashboard/advisor-management/policy-transfer/all-policy-transfer-table/all-policy-transfer-table.component';
import {
  PolicyTransferFormComponent
} from '@app/dashboard/advisor-management/policy-transfer/policy-transfer-form/policy-transfer-form.component';
import {
  PolicyTransferEditFormComponent
} from '@app/dashboard/advisor-management/policy-transfer/policy-transfer-edit-form/policy-transfer-edit-form.component';
import {
  PolicyTransferApproveFormComponent
} from '@app/dashboard/advisor-management/policy-transfer/policy-transfer-approve-form/policy-transfer-approve-form.component';
import {
  PolicyTransferServicingComponent
} from '@app/dashboard/advisor-management/policy-transfer/policy-transfer-servicing/policy-transfer-servicing.component';
import {
  AllBranchTransferTableComponent
} from '@app/dashboard/advisor-management/branch-transfer/all-branch-transfer-table/all-branch-transfer-table.component';
import {
  BranchTransferFormComponent
} from '@app/dashboard/advisor-management/branch-transfer/branch-transfer-form/branch-transfer-form.component';
import {
  BranchTransferEditFormComponent
} from '@app/dashboard/advisor-management/branch-transfer/branch-transfer-edit-form/branch-transfer-edit-form.component';
import {
  BranchTransferApproveFormComponent
} from '@app/dashboard/advisor-management/branch-transfer/branch-transfer-approve-form/branch-transfer-approve-form.component';
import {
  AllIncomeServiceTableComponent
} from '@app/dashboard/advisor-management/income-service/all-income-service-table/all-income-service-table.component';
import {
  IncomeServiceFormComponent
} from '@app/dashboard/advisor-management/income-service/income-service-form/income-service-form.component';
import {
  IncomeServiceEditFormComponent
} from '@app/dashboard/advisor-management/income-service/income-service-edit-form/income-service-edit-form.component';
import {
  IncomeServiceApproveFormComponent
} from '@app/dashboard/advisor-management/income-service/income-service-approve-form/income-service-approve-form.component';

const routes: Routes = [

  {
    path: '',
    component: AdvisorManagementComponent,

    children: [
      {
        path: 'create-form',
        component: CreateFormComponent
      },

      {
        path: 'view-applications-table',
        component: ViewTableComponent
      },

      {
        path: 'approve-form',
        component: ApproveFormComponent
      },

      {
        path: 'edit-form',
        component: EditFormComponent
      },

      {
        path: 'all-transfer-table',
        component: AllTransferDataTableComponent
      },

      {
        path: 'transfer-form',
        component: TransferFormComponent
      },

      {
        path: 'transfer-edit-form',
        component: TransferEditFormComponent
      },

      {
        path: 'transfer-approve-form',
        component: TransferApproveFormComponent
      },

      {
        path: 'all-termination-table',
        component: AllTerminationTableComponent
      },

      {
        path: 'termination-form',
        component: TerminationFormComponent
      },

      {
        path: 'termination-edit-form',
        component: TerminationEditFormComponent
      },

      {
        path: 'termination-approve-form',
        component: TerminationApproveFormComponent
      },

      {
        path: 'termination-finance',
        component: TerminationFinanceClearanceTableComponent
      },

      {
        path: 'termination-servicing',
        component: TerminationServicingComponent
      },

      {
        path: 'all-policy-transfer-table',
        component: AllPolicyTransferTableComponent
      },

      {
        path: 'policy-transfer-form',
        component: PolicyTransferFormComponent
      },

      {
        path: 'policy-transfer-edit-form',
        component: PolicyTransferEditFormComponent
      },

      {
        path: 'policy-transfer-approve-form',
        component: PolicyTransferApproveFormComponent
      },

      {
        path: 'policy-transfer-servicing',
        component: PolicyTransferServicingComponent
      },

      {
        path: 'all-branch-transfer-table',
        component: AllBranchTransferTableComponent
      },

      {
        path: 'branch-transfer-form',
        component: BranchTransferFormComponent
      },

      {
        path: 'branch-transfer-edit-form',
        component: BranchTransferEditFormComponent
      },

      {
        path: 'branch-transfer-approve-form',
        component: BranchTransferApproveFormComponent
      },

      {
        path: 'all-income-service-table',
        component: AllIncomeServiceTableComponent
      },

      {
        path: 'income-service-form',
        component: IncomeServiceFormComponent
      },

      {
        path: 'income-service-edit-form',
        component: IncomeServiceEditFormComponent
      },

      {
        path: 'income-service-approve-form',
        component: IncomeServiceApproveFormComponent
      },

    ]
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdvisorManagementRoutingModule {
}
