import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferApprovalLevelsComponent } from './transfer-approval-levels.component';

describe('TransferApprovalLevelsComponent', () => {
  let component: TransferApprovalLevelsComponent;
  let fixture: ComponentFixture<TransferApprovalLevelsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransferApprovalLevelsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferApprovalLevelsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
