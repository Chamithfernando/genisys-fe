import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllTransferDataTableComponent } from './all-transfer-data-table.component';

describe('AllTransferDataTableComponent', () => {
  let component: AllTransferDataTableComponent;
  let fixture: ComponentFixture<AllTransferDataTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllTransferDataTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AllTransferDataTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
