import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferRejectedTableComponent } from './transfer-rejected-table.component';

describe('TransferRejectedTableComponent', () => {
  let component: TransferRejectedTableComponent;
  let fixture: ComponentFixture<TransferRejectedTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransferRejectedTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferRejectedTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
