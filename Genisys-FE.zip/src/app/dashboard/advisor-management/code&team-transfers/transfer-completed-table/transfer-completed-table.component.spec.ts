import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferCompletedTableComponent } from './transfer-completed-table.component';

describe('TransferCompletedTableComponent', () => {
  let component: TransferCompletedTableComponent;
  let fixture: ComponentFixture<TransferCompletedTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransferCompletedTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferCompletedTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
