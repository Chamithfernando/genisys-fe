import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferDraftTableComponent } from './transfer-draft-table.component';

describe('TransferDraftTableComponent', () => {
  let component: TransferDraftTableComponent;
  let fixture: ComponentFixture<TransferDraftTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransferDraftTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferDraftTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
