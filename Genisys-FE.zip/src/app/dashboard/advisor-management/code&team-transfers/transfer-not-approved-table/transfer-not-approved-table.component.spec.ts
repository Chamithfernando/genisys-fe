import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferNotApprovedTableComponent } from './transfer-not-approved-table.component';

describe('TransferNotApprovedTableComponent', () => {
  let component: TransferNotApprovedTableComponent;
  let fixture: ComponentFixture<TransferNotApprovedTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransferNotApprovedTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferNotApprovedTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
