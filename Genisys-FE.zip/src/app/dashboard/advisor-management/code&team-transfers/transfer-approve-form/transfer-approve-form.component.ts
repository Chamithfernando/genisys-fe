import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {ActivatedRoute, Router} from '@angular/router';
import {
  Selector,
  SELECTOR_OPTIONS,
  showErrorMessage
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {
  AddApproveStatusComponent
} from '@app/dashboard/advisor-management/promotion-demotion/manage-application/add-approve-status/add-approve-status.component';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {formatDate} from '@angular/common';


@Component({
  selector: 'app-transfer-approve-form',
  templateUrl: './transfer-approve-form.component.html',
  styleUrls: ['./transfer-approve-form.component.scss']
})
export class TransferApproveFormComponent implements OnInit {

  transferForm: FormGroup;
  branchArray: Array<any> = [];
  agentsArray: Array<any> = [];
  selector: Selector[];
  branchId: string;
  fname: string;
  lname: string;
  formId: number;
  formObj: any;

  dialogRef: MatDialogRef<any>;

  showError = false;
  showLabel = false;
  isDisabled = false;

  constructor(private formBuilder: FormBuilder,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              private dialog: MatDialog,
              private router: Router,
              private route: ActivatedRoute) {

    this.transferForm = this.formBuilder.group({
      branch: new FormControl('', [Validators.required]),
      agentCode: new FormControl('', [Validators.required]),
      indFirstYRetention: new FormControl(''),
      indSecondYRetention: new FormControl(''),
      indThirteenMRetention: new FormControl(''),
      indTwentyfiveMRetention: new FormControl(''),
      existingAgentCode: new FormControl('', [Validators.required]),
      exFirstYRetention: new FormControl(''),
      exSecondYRetention: new FormControl(''),
      exThirteenMRetention: new FormControl(''),
      exTwentyfiveMRetention: new FormControl(''),
      newAgentCode: new FormControl('', [Validators.required]),
      newFirstYRetention: new FormControl(''),
      newSecondYRetention: new FormControl(''),
      newThirteenMRetention: new FormControl(''),
      newTwentyfiveMRetention: new FormControl(''),
      reasonForTransfer: new FormControl('', [Validators.required]),
      impactBranch: new FormControl(''),
      impactBranchReason: new FormControl(''),
      impactLeader: new FormControl(''),
      impactLeaderReason: new FormControl(''),
      effectiveDate: new FormControl('', [Validators.required]),
    });

    this.selector = SELECTOR_OPTIONS;
  }

  async ngOnInit(): Promise<void> {
    this.route.queryParams.subscribe(params => {
      this.formId = (params.formId);
    });

    try {
      await Promise.all([this.allBranches(), this.getTransferDraftDetails()]);
    } catch (error) {
      console.error(error);
    }
  }

  async allBranches() {
    const branchList: any = await this.getBranchList().catch((error) => {
      console.log(error);
    });
    if (branchList.status === 200) {
      this.branchArray = branchList.payload.sort((a, b) => a.branchName.localeCompare(b.branchName));
      this.isDisabled = true;
    }
  }

  async getBranchList() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAllBranches(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async allAgentsByBranch() {
    const agentsList: any = await this.getAgentsDetails().catch((error) => {
      console.log(error);
    });
    if (agentsList.status === 200) {
      this.agentsArray = agentsList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));
    }
  }

  async getAgentsDetails() {

    const branchCode = +this.branchId;

    return new Promise((resolve, reject) => {
      this.advisorService
        .getAgentsbyBranch(branchCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  onAgentSelection(event: any) {
    const selectedAgentCode = event.value;
    const selectedAgent = this.agentsArray.find(agent => agent.agentCode === selectedAgentCode);
    if (selectedAgent && selectedAgent.categoryId === '3') {
      this.showError = true;
    } else {
      this.showError = false;
    }

    if (selectedAgent && selectedAgent.directReporting) {
      this.showLabel = true;
    } else {
      this.showLabel = false;
    }
  }

  async displayAgentRetention(selectedAgentCode: string) {
    const teamAgentCode = selectedAgentCode;
    const agentsList: any = await this.getRetentionByAgent(teamAgentCode).catch((error) => {
      console.log(error);
    });

    if (agentsList.status === 200) {
      const retention = agentsList.data;

      if (retention) {
        this.transferForm.patchValue({
          indFirstYRetention: retention.firstYearRetention,
          indSecondYRetention: retention.secondYearRetention,
          indThirteenMRetention: retention.thirteenMonthsPersistence,
          indTwentyfiveMRetention: retention.twentyFiveMonthsPersistence,
        });
      }

    }
  }

  async getRetentionByAgent(agentCode?: string) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAgentRetention(agentCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async displayTeamRetention(reportingAgentCode: string) {
    const teamAgentCode = reportingAgentCode;
    const teamList: any = await this.getRetentionByReportingAgent(teamAgentCode).catch((error) => {
      console.log(error);
    });

    if (teamList.status === 204) {
      const retention = teamList.data;
      if (retention) {
        this.transferForm.patchValue({
          exFirstYRetention: retention.firstYearRetention,
          exSecondYRetention: retention.secondYearRetention,
          exThirteenMRetention: retention.thirteenMonthsPersistence,
          exTwentyfiveMRetention: retention.twentyFiveMonthsPersistence
        });
      }
    }
  }

  async displayNewAgentRetention(newAgenCode: string) {
    const newAgentCode = newAgenCode;
    const retentionList: any = await this.getRetentionByReportingAgent(newAgentCode).catch((error) => {
      console.log(error);
    });

    if (retentionList.status === 204) {
      const retention = retentionList.data;
      if (retention) {
        this.transferForm.patchValue({
          newFirstYRetention: retention.firstYearRetention,
          newSecondYRetention: retention.secondYearRetention,
          newThirteenMRetention: retention.thirteenMonthsPersistence,
          newTwentyfiveMRetention: retention.twentyFiveMonthsPersistence,
        });
      }

    }
  }

  async getRetentionByReportingAgent(agentCode: string) {

    return new Promise((resolve, reject) => {
      this.advisorService
        .getTeamRetention(agentCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getTransferDraftDetails() {

    this.formObj = await this.getFormDetails().catch((error) => {
      console.log(error);
    });

    if (this.formObj.status === 200) {
      this.branchId = this.formObj.data.branchCode;

      await this.allAgentsByBranch();

      this.transferForm.patchValue({
        branch: this.formObj.data.branchCode.toString(),
        agentCode: this.formObj.data.agentCode,
        existingAgentCode: this.formObj.data.existingReportingPerson,
        newAgentCode: this.formObj.data.newReportingPerson,
        reasonForTransfer: this.formObj.data.reasonForAgentTransfer,
        impactBranch: this.formObj.data.impactOnBranch ? 'true' : 'false',
        impactLeader: this.formObj.data.impactOnLeader ? 'true' : 'false',
        impactBranchReason: this.formObj.data.impactOnBranch,
        impactLeaderReason: this.formObj.data.impactOnLeader,
        effectiveDate: formatDate(this.formObj.data.effectiveDate, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
      });

      await Promise.all(
        [this.displayAgentRetention(this.formObj.data.agentCode),
          this.displayTeamRetention(this.formObj.data.existingReportingPerson),
          this.displayNewAgentRetention(this.formObj.data.newReportingPerson)]);

    }
  }

  async getFormDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getTransferFormDetails(this.formId, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  clear() {
    this.transferForm.reset();
    this.transferForm.get('branch').setValue(this.branchId);
  }


  openApproveStatus() {
    const elements = {
      id: this.formId,
      formTitle: 'transfer'
    };

    this.dialogRef = this.dialog.open(AddApproveStatusComponent, {
      width: '600px',
      disableClose: true,
      data: elements,
    });

  }


}
