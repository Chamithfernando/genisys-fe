import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferApproveFormComponent } from './transfer-approve-form.component';

describe('TransferApproveFormComponent', () => {
  let component: TransferApproveFormComponent;
  let fixture: ComponentFixture<TransferApproveFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransferApproveFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferApproveFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
