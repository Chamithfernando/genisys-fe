import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferEditFormComponent } from './transfer-edit-form.component';

describe('TransferEditFormComponent', () => {
  let component: TransferEditFormComponent;
  let fixture: ComponentFixture<TransferEditFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransferEditFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferEditFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
