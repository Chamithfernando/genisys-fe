import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {ActivatedRoute, Router} from '@angular/router';
import {
  Selector,
  SELECTOR_OPTIONS,
  showErrorMessage, showSucessMessage
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {formatDate} from '@angular/common';


@Component({
  selector: 'app-transfer-edit-form',
  templateUrl: './transfer-edit-form.component.html',
  styleUrls: ['./transfer-edit-form.component.scss']
})
export class TransferEditFormComponent implements OnInit {

  transferEditForm: FormGroup;
  branchArray: Array<any> = [];
  agentsArray: Array<any> = [];
  reportingAgent: Array<any> = [];
  selector: Selector[];
  branchId: string;
  fname: string;
  lname: string;
  formId: number;
  formObj: any;
  formStatus: string;
  reportingAgentCode: string;

  showError = false;
  showLabel = false;
  isDisabled = false;

  constructor(private formBuilder: FormBuilder,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              private router: Router,
              private route: ActivatedRoute) {

    this.transferEditForm = this.formBuilder.group({
      branch: new FormControl([Validators.required]),
      agentCode: new FormControl('', [Validators.required]),
      indFirstYRetention: new FormControl(''),
      indSecondYRetention: new FormControl(''),
      indThirteenMRetention: new FormControl(''),
      indTwentyfiveMRetention: new FormControl(''),
      existingAgentCode: new FormControl([Validators.required]),
      exFirstYRetention: new FormControl(''),
      exSecondYRetention: new FormControl(''),
      exThirteenMRetention: new FormControl(''),
      exTwentyfiveMRetention: new FormControl(''),
      newAgentCode: new FormControl('', [Validators.required]),
      newFirstYRetention: new FormControl(''),
      newSecondYRetention: new FormControl(''),
      newThirteenMRetention: new FormControl(''),
      newTwentyfiveMRetention: new FormControl(''),
      reasonForTransfer: new FormControl('', [Validators.required]),
      impactBranch: new FormControl(''),
      impactBranchReason: new FormControl(''),
      impactLeader: new FormControl(''),
      impactLeaderReason: new FormControl(''),
      effectiveDate: new FormControl('', [Validators.required]),
    });

    this.selector = SELECTOR_OPTIONS;
  }

  async ngOnInit(): Promise<void> {
    this.route.queryParams.subscribe(params => {
      this.formId = (params.formId);
      this.formStatus = (params.formStatus);
    });

    try {
      await Promise.all([this.allBranches(), this.getTransferDraftDetails(), this.newReportingAgent()]);
    } catch (error) {
      console.error(error);
    }

  }

  async allBranches() {
    const branchList: any = await this.getBranchList().catch((error) => {
      console.log(error);
    });
    if (branchList.status === 200) {
      this.branchArray = branchList.payload.sort((a, b) => a.branchName.localeCompare(b.branchName));
      this.isDisabled = true;
    }
  }

  async getBranchList() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAllBranches(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async allAgentsByBranch() {
    const agentsList: any = await this.getAgentsDetails().catch((error) => {
      console.log(error);
    });
    if (agentsList.status === 200) {
      this.agentsArray = agentsList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));

    }
  }

  async getAgentsDetails() {

    const branchCode = +this.branchId;

    return new Promise((resolve, reject) => {
      this.advisorService
        .getAgentsbyBranch(branchCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async newReportingAgent() {
    const newReportingList: any = await this.getNewReportingAgent().catch((error) => {
      console.log(error);
    });

    if (newReportingList.status === 200) {
      this.reportingAgent = newReportingList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));
    }
  }

  async getNewReportingAgent() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .newReportingAgent(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


  async onAgentSelection(event: any) {
    const selectedAgentCode = event.value;
    const selectedAgent = this.agentsArray.find(agent => agent.agentCode === selectedAgentCode);
    if (selectedAgent && selectedAgent.categoryId === '3') {
      this.showError = true;
    } else {
      this.showError = false;
    }

    if (selectedAgent && selectedAgent.directReporting) {
      this.showLabel = true;
    } else {
      this.showLabel = false;
    }

    if (selectedAgent) {
      this.reportingAgentCode = selectedAgent.reportingAgentCode;
    }

    try {
      await Promise.all([this.displayAgentRetention(selectedAgentCode), this.displayTeamRetention(this.reportingAgentCode)]);
    } catch (error) {
      console.error(error);
    }
  }

  async displayAgentRetention(selectedAgentCode: string) {
    const teamAgentCode = selectedAgentCode;
    const agentsList: any = await this.getRetentionByAgent(teamAgentCode).catch((error) => {
      console.log(error);
    });

    if (agentsList.status === 200) {
      const retention = agentsList.data;

      if (retention) {
        this.transferEditForm.patchValue({
          indFirstYRetention: retention.firstYearRetention,
          indSecondYRetention: retention.secondYearRetention,
          indThirteenMRetention: retention.thirteenMonthsPersistence,
          indTwentyfiveMRetention: retention.twentyFiveMonthsPersistence,
        });
      }

    }
  }

  async getRetentionByAgent(agentCode?: string) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAgentRetention(agentCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async displayTeamRetention(reportingAgentCode: string) {
    const teamAgentCode = reportingAgentCode;
    const teamList: any = await this.getRetentionByReportingAgent(teamAgentCode).catch((error) => {
      console.log(error);
    });

    if (teamList.status === 204) {
      const retention = teamList.data;
      if (retention) {
        this.transferEditForm.patchValue({
          exFirstYRetention: retention.firstYearRetention,
          exSecondYRetention: retention.secondYearRetention,
          exThirteenMRetention: retention.thirteenMonthsPersistence,
          exTwentyfiveMRetention: retention.twentyFiveMonthsPersistence
        });
      }
    }
  }

  async displayNewAgentRetention(event: any) {
    let newAgentCode: string;
    if (event) {
      newAgentCode = event.value;
    } else {
      newAgentCode = this.formObj.data.newReportingPerson;
    }
    const retentionList: any = await this.getRetentionByReportingAgent(newAgentCode).catch((error) => {
      console.log(error);
    });

    if (retentionList.status === 204) {
      const retention = retentionList.data;
      if (retention) {
        this.transferEditForm.patchValue({
          newFirstYRetention: retention.firstYearRetention,
          newSecondYRetention: retention.secondYearRetention,
          newThirteenMRetention: retention.thirteenMonthsPersistence,
          newTwentyfiveMRetention: retention.twentyFiveMonthsPersistence,
        });
      }

    }
  }

  async getRetentionByReportingAgent(agentCode: string) {

    return new Promise((resolve, reject) => {
      this.advisorService
        .getTeamRetention(agentCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getTransferDraftDetails() {

    this.formObj = await this.getFormDetails().catch((error) => {
      console.log(error);
    });

    if (this.formObj.status === 200) {
      this.branchId = this.formObj.data.branchCode;
      await this.allAgentsByBranch();

      let effectiveDate = '';
      if (this.formObj.data.effectiveDate) {
        const trimmedPeriodOfEffectiveDate = this.formObj.data.effectiveDate.substring(0, 10);
        if (trimmedPeriodOfEffectiveDate !== '1970-01-01') {
          effectiveDate = formatDate(trimmedPeriodOfEffectiveDate, 'yyyy-MM-dd', 'en-US');
        }
      }


      this.transferEditForm.patchValue({
        branch: this.formObj.data.branchCode.toString(),
        agentCode: this.formObj.data.agentCode,
        existingAgentCode: this.formObj.data.existingReportingPerson,
        newAgentCode: this.formObj.data.newReportingPerson,
        reasonForTransfer: this.formObj.data.reasonForAgentTransfer,
        impactBranch: this.formObj.data.impactOnBranch ? 'true' : 'false',
        impactLeader: this.formObj.data.impactOnLeader ? 'true' : 'false',
        impactBranchReason: this.formObj.data.impactOnBranch,
        impactLeaderReason: this.formObj.data.impactOnLeader,
        effectiveDate: effectiveDate

      });

      const dummyEvent = {value: this.formObj.data.newReportingPerson};
      await Promise.all(
        [this.displayAgentRetention(this.formObj.data.agentCode),
          this.displayTeamRetention(this.formObj.data.existingReportingPerson),
          this.displayNewAgentRetention(dummyEvent)
         ]);
    }
  }

  async getFormDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getTransferFormDetails(this.formId, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  clear() {
    this.transferEditForm.reset();
    this.transferEditForm.get('branch').setValue(this.branchId.toString());
  }

  validate() {

    const validationRules = [
      {field: 'branch', message: 'Branch is Required'},
      {field: 'agentCode', message: 'Agent is Required'},
      {field: 'existingAgentCode', message: 'Existing Reporting is Required'},
      {field: 'newAgentCode', message: 'New Reporting is Required'},
      {field: 'reasonForTransfer', message: 'Reason For Transfer is Required'},
    ];

    for (const rule of validationRules) {
      if (!this.transferEditForm.value[rule.field]) {
        showErrorMessage(rule.message);
        return false;
      }
    }

    if (this.transferEditForm.value.impactBranch === 'true' && !this.transferEditForm.value.impactBranchReason) {
      showErrorMessage('Impact on the Branch Reason is Required');
      return false;
    }

    if (this.transferEditForm.value.impactLeader === 'true' && !this.transferEditForm.value.impactLeaderReason) {
      showErrorMessage('Impact on the Leader Reason is Required');
      return false;
    }

    return true;
  }

  draftValidate() {

    const validationRules = [
      {field: 'agentCode', message: 'Agent is Required'},
    ];

    for (const rule of validationRules) {
      if (!this.transferEditForm.value[rule.field]) {
        showErrorMessage(rule.message);
        return false;
      }
    }

    if (this.transferEditForm.value.impactBranch === 'true' && !this.transferEditForm.value.impactBranchReason) {
      showErrorMessage('Impact on the Branch Reason is Required');
      return false;
    }

    if (this.transferEditForm.value.impactLeader === 'true' && !this.transferEditForm.value.impactLeaderReason) {
      showErrorMessage('Impact on the Leader Reason is Required');
      return false;
    }

    return true;
  }

  async saveTransferForm() {
    if (this.validate()) {

      const data = {
        id: this.formId,
        branchCode: +this.transferEditForm.value.branch,
        agentCode: this.transferEditForm.value.agentCode,
        existingReportingPerson: this.transferEditForm.value.existingAgentName,
        newReportingPerson: this.transferEditForm.value.newAgentCode,
        reasonForAgentTransfer: this.transferEditForm.value.reasonForTransfer,
        impactOnBranch: this.transferEditForm.value.impactBranchReason,
        impactOnLeader: this.transferEditForm.value.impactLeaderReason,
        effectiveDate: formatDate(this.transferEditForm.value.effectiveDate, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),

      };

      const saveResponse: any = await this.saveForm(data).catch(
        (err) => {
          console.log(err);
        }
      );

      if (saveResponse.status === 201) {

        showSucessMessage(saveResponse.message);
        this.router.navigate(['/dashboard/advisor-management/all-transfer-table']);
        this.clear();
      } else {
        showErrorMessage(saveResponse.payload.message);
      }

    }
  }

  saveForm(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .submitTransferForm(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  // Draft Form
  async draftTransferForm() {

    if (this.draftValidate()) {
      const data = {
        id: this.formId,
        branchCode: +this.transferEditForm.value.branch,
        agentCode: this.transferEditForm.value.agentCode,
        existingReportingPerson: this.transferEditForm.value.existingAgentName,
        newReportingPerson: this.transferEditForm.value.newAgentCode,
        reasonForAgentTransfer: this.transferEditForm.value.reasonForTransfer,
        impactOnBranch: this.transferEditForm.value.impactBranchReason,
        impactOnLeader: this.transferEditForm.value.impactLeaderReason,
        effectiveDate: formatDate(this.transferEditForm.value.effectiveDate ? this.transferEditForm.value.effectiveDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
      };


      const saveResponse: any = await this.draftForm(data).catch(
        (err) => {
          console.log(err);
        }
      );

      if (saveResponse.status === 201) {

        showSucessMessage(saveResponse.message);
        this.router.navigate(['/dashboard/advisor-management/all-transfer-table']);
        this.clear();
      } else {
        showErrorMessage(saveResponse.payload.message);
      }
    }

  }

  draftForm(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .draftTransferForm(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }


}
