import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, UntypedFormBuilder, Validators} from '@angular/forms';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {ActivatedRoute, Router, NavigationStart} from '@angular/router';
import {
  Selector,
  SELECTOR_OPTIONS,
  showSucessMessage,
  showErrorMessage
} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {formatDate} from '@angular/common';

@Component({
  selector: 'app-transfer-form',
  templateUrl: './transfer-form.component.html',
  styleUrls: ['./transfer-form.component.scss']
})
export class TransferFormComponent implements OnInit {

  transferForm: FormGroup;
  branchArray: Array<any> = [];
  agentsArray: Array<any> = [];
  reportingAgent: Array<any> = [];
  selector: Selector[];
  branchId: string;
  selectedAgentCode: string;
  reportingAgentCode: string;

  showError = false;
  showLabel = false;
  isDisabled = false;

  constructor(private formBuilder: FormBuilder,
              private advisorService: AdvisorManagementService,
              private authService: AuthService,
              private router: Router,
              private route: ActivatedRoute) {

    this.transferForm = this.formBuilder.group({
      branch: new FormControl([Validators.required]),
      agentCode: new FormControl('', [Validators.required]),
      indFirstYRetention: new FormControl(''),
      indSecondYRetention: new FormControl(''),
      indThirteenMRetention: new FormControl(''),
      indTwentyfiveMRetention: new FormControl(''),
      existingAgentName: new FormControl('', [Validators.required]),
      exFirstYRetention: new FormControl(''),
      exSecondYRetention: new FormControl(''),
      exThirteenMRetention: new FormControl(''),
      exTwentyfiveMRetention: new FormControl(''),
      newAgentCode: new FormControl('', [Validators.required]),
      newFirstYRetention: new FormControl(''),
      newSecondYRetention: new FormControl(''),
      newThirteenMRetention: new FormControl(''),
      newTwentyfiveMRetention: new FormControl(''),
      reasonForTransfer: new FormControl('', [Validators.required]),
      impactBranch: new FormControl(''),
      impactBranchReason: new FormControl(''),
      impactLeader: new FormControl(''),
      impactLeaderReason: new FormControl(''),
      effectiveDate: new FormControl('', [Validators.required]),
    });

    this.selector = SELECTOR_OPTIONS;
  }

  async ngOnInit(): Promise<void> {

    this.route.queryParams.subscribe(params => {
      this.branchId = (params.branchCode);
    });

    this.transferForm.get('branch').setValue(this.branchId);

    try {
      await Promise.all([this.allBranches(), this.allAgentsByBranch()]);
    } catch (error) {
      console.error(error);
    }
  }

  async allBranches() {
    const branchList: any = await this.getBranchList().catch((error) => {
      console.log(error);
    });
    if (branchList.status === 200) {
      this.branchArray = branchList.payload.sort((a, b) => a.branchName.localeCompare(b.branchName));
      this.isDisabled = true;
    }
  }

  async getBranchList() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAllBranches(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async allAgentsByBranch() {
    const agentsList: any = await this.getAgentsDetails().catch((error) => {
      console.log(error);
    });
    if (agentsList.status === 200) {
      this.agentsArray = agentsList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));
      this.newReportingAgent();
    }
  }

  async getAgentsDetails() {

    const branchCode = +this.branchId;

    return new Promise((resolve, reject) => {
      this.advisorService
        .getAgentsbyBranch(branchCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async onAgentSelection(event: any) {
    this.selectedAgentCode = event.value;
    const selectedAgent = this.agentsArray.find(agent => agent.agentCode === this.selectedAgentCode);
    if (selectedAgent && selectedAgent.categoryId === '3') {
      this.showError = true;
    } else {
      this.showError = false;
    }

    if (selectedAgent && selectedAgent.directReporting) {
      this.showLabel = true;
    } else {
      this.showLabel = false;
    }

    if (selectedAgent) {
      this.reportingAgentCode = selectedAgent.reportingAgentCode;

      this.transferForm.patchValue({
        existingAgentName: selectedAgent.reportingTo,
      });
    }

    try {
      await Promise.all([this.displayAgentRetention(), this.displayTeamRetention()]);
    } catch (error) {
      console.error(error);
    }
  }

  async displayAgentRetention() {
    const teamAgentCode = this.selectedAgentCode;
    const agentsList: any = await this.getRetentionByAgent(teamAgentCode).catch((error) => {
      console.log(error);
    });

    if (agentsList.status === 200) {
      const retention = agentsList.data;

      if (retention) {
        this.transferForm.patchValue({
          indFirstYRetention: retention.firstYearRetention,
          indSecondYRetention: retention.secondYearRetention,
          indThirteenMRetention: retention.thirteenMonthsPersistence,
          indTwentyfiveMRetention: retention.twentyFiveMonthsPersistence,
        });
      }

    }
  }

  async getRetentionByAgent(agentCode?: string) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getAgentRetention(agentCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async displayTeamRetention() {
    const teamAgentCode = this.reportingAgentCode;
    const teamList: any = await this.getRetentionByReportingAgent(teamAgentCode).catch((error) => {
      console.log(error);
    });

    if (teamList.status === 204) {
      const retention = teamList.data;
      if (retention) {
        this.transferForm.patchValue({
          exFirstYRetention: retention.firstYearRetention,
          exSecondYRetention: retention.secondYearRetention,
          exThirteenMRetention: retention.thirteenMonthsPersistence,
          exTwentyfiveMRetention: retention.twentyFiveMonthsPersistence
        });
      }
    }
  }

  async displayNewAgentRetention(event: any) {
    const newAgentCode = event.value;
    const retentionList: any = await this.getRetentionByReportingAgent(newAgentCode).catch((error) => {
      console.log(error);
    });

    if (retentionList.status === 204) {
      const retention = retentionList.data;
      if (retention) {
        this.transferForm.patchValue({
          newFirstYRetention: retention.firstYearRetention,
          newSecondYRetention: retention.secondYearRetention,
          newThirteenMRetention: retention.thirteenMonthsPersistence,
          newTwentyfiveMRetention: retention.twentyFiveMonthsPersistence,
        });
      }

    }
  }

  async getRetentionByReportingAgent(agentCode: string) {

    return new Promise((resolve, reject) => {
      this.advisorService
        .getTeamRetention(agentCode, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async newReportingAgent() {
    const newReportingList: any = await this.getNewReportingAgent().catch((error) => {
      console.log(error);
    });

    if (newReportingList.status === 200) {
      this.reportingAgent = newReportingList.data.sort((a, b) => a.agentName.localeCompare(b.agentName));
    }
  }

  async getNewReportingAgent() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .newReportingAgent(this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  clear() {
    this.transferForm.reset();
    this.showLabel = false;
    this.transferForm.get('branch').setValue(this.branchId);
  }

  validate() {

    const validationRules = [
      {field: 'branch', message: 'Branch is Required'},
      {field: 'agentCode', message: 'Agent is Required'},
      {field: 'existingAgentName', message: 'Existing Reporting is Required'},
      {field: 'newAgentCode', message: 'New Reporting is Required'},
      {field: 'reasonForTransfer', message: 'Reason For Transfer is Required'},
      {field: 'effectiveDate', message: 'Effective Date is Required'},
    ];

    for (const rule of validationRules) {
      if (!this.transferForm.value[rule.field]) {
        showErrorMessage(rule.message);
        return false;
      }
    }

    if (this.transferForm.value.impactBranch === 'true' && !this.transferForm.value.impactBranchReason) {
      showErrorMessage('Impact on the Branch Reason is Required');
      return false;
    }

    if (this.transferForm.value.impactLeader === 'true' && !this.transferForm.value.impactLeaderReason) {
      showErrorMessage('Impact on the Leader Reason is Required');
      return false;
    }

    return true;
  }

  draftValidate() {

    const validationRules = [
      {field: 'agentCode', message: 'Agent is Required'},
    ];

    for (const rule of validationRules) {
      if (!this.transferForm.value[rule.field]) {
        showErrorMessage(rule.message);
        return false;
      }
    }

    if (this.transferForm.value.impactBranch === 'true' && !this.transferForm.value.impactBranchReason) {
      showErrorMessage('Impact on the Branch Reason is Required');
      return false;
    }

    if (this.transferForm.value.impactLeader === 'true' && !this.transferForm.value.impactLeaderReason) {
      showErrorMessage('Impact on the Leader Reason is Required');
      return false;
    }

    return true;
  }


  // Save Form
  async saveTransferForm() {
    if (this.validate()) {

      const data = {
        branchCode: +this.transferForm.value.branch,
        agentCode: this.transferForm.value.agentCode,
        existingReportingPerson: this.transferForm.value.existingAgentName,
        newReportingPerson: this.transferForm.value.newAgentCode,
        reasonForAgentTransfer: this.transferForm.value.reasonForTransfer,
        impactOnBranch: this.transferForm.value.impactBranchReason,
        impactOnLeader: this.transferForm.value.impactLeaderReason,
        effectiveDate: formatDate(this.transferForm.value.effectiveDate, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),

      };

      const saveResponse: any = await this.saveForm(data).catch(
        (err) => {
          console.log(err);
        }
      );

      if (saveResponse.status === 201) {

        showSucessMessage(saveResponse.message);
        this.router.navigate(['/dashboard/advisor-management/all-transfer-table']);
        this.clear();
      } else {
        showErrorMessage(saveResponse.payload.message);
      }

    }
  }

  saveForm(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .submitTransferForm(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  // Draft Form
  async draftTransferForm() {

    if (this.draftValidate()) {
      const data = {
        branchCode: +this.transferForm.value.branch,
        agentCode: this.transferForm.value.agentCode,
        existingReportingPerson: this.transferForm.value.existingAgentName,
        newReportingPerson: this.transferForm.value.newAgentCode,
        reasonForAgentTransfer: this.transferForm.value.reasonForTransfer,
        impactOnBranch: this.transferForm.value.impactBranchReason,
        impactOnLeader: this.transferForm.value.impactLeaderReason,
        effectiveDate: formatDate(this.transferForm.value.effectiveDate ? this.transferForm.value.effectiveDate : null, 'yyyy-MM-ddTHH:mm:ss', 'en-US'),
      };


      const saveResponse: any = await this.draftForm(data).catch(
        (err) => {
          console.log(err);
        }
      );

      if (saveResponse.status === 201) {

        showSucessMessage(saveResponse.message);
        this.router.navigate(['/dashboard/advisor-management/all-transfer-table']);
        this.clear();
      } else {
        showErrorMessage(saveResponse.payload.message);
      }
    }

  }

  draftForm(data: any) {
    return new Promise((resolve, reject) => {
      this.advisorService
        .draftTransferForm(data, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {

            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
