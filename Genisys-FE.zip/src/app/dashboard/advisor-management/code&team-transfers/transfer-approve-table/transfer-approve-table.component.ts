import { Component, ViewChild, OnInit} from '@angular/core';
import {applyFilter} from '@app/dashboard/advisor-management/utilities/common-utilities/common-utilities.component';
import {validateEnterSpecialCharacters} from '@app/dashboard/advisor-management/utilities/validation/validation.component';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import {ActivatedRoute, Router} from '@angular/router';
import {AuthService} from '@app/shared/services/auth/auth.service';
import {AdvisorManagementService} from '@app/shared/services/advisor-management/advisor-management.service';
import {
  TransferApprovalLevelsComponent
} from '@app/dashboard/advisor-management/code&team-transfers/transfer-approval-levels/transfer-approval-levels.component';


@Component({
  selector: 'app-transfer-approve-table',
  templateUrl: './transfer-approve-table.component.html',
  styleUrls: ['./transfer-approve-table.component.scss']
})
export class TransferApproveTableComponent implements OnInit {

  dialogRef: MatDialogRef<any>;

  displayedColumns: string[] = ['sequenceNumber', 'id', 'agentName', 'branchName', 'existingReportingName',
    'newReportingName', 'effectiveDate', 'action' , 'approveLevels'];

  dataSource = new MatTableDataSource();

  tableStatus: string;
  formListObj: any;
  formList: Array<any> = [];
  userDetails: any;
  hideBmFeatures = false;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private dialog: MatDialog,
              private route: ActivatedRoute,
              private router: Router,
              private authService: AuthService,
              private advisorService: AdvisorManagementService) { }

  async ngOnInit(): Promise<void> {

    await this.getLoginUser();
    await this.getTransferDetails();
  }

  applyFilter(event: Event) {
    applyFilter(this.dataSource, event);
  }

  validateEnterSpecialCharacters(event: Event) {
    validateEnterSpecialCharacters(event);
  }

  openApprovalLevels(e: any, element: number) {
    this.dialogRef = this.dialog.open(TransferApprovalLevelsComponent, {
      width: '600px',
      data: element
    });
  }

  async getLoginUser() {
    this.userDetails = await this.getUserDetails().catch((error) => {
      console.log(error);
    });

    if (this.userDetails.status === 'OK') {
      const roleName = this.userDetails.data.roleDto.roleName;
      if (['Branch Manager'].includes(roleName)) {
        this.hideBmFeatures = true;
      }
    }
  }

  async getUserDetails() {
    return new Promise((resolve, reject) => {

      this.authService
        .getPermission()
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  async getTransferDetails() {

    this.tableStatus = 'PENDING';

    this.formListObj = await this.getTableDetails().catch((error) => {
      console.log(error);
    });

    if (this.formListObj.status === 200) {

      this.formList = this.formListObj.data.map((item, index) => {
        return { ...item, sequenceNumber: index + 1 };
      });
    }

    this.dataSource = new MatTableDataSource(this.formList);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  async getTableDetails() {
    return new Promise((resolve, reject) => {
      this.advisorService
        .getTransferDetailsByFilter(this.tableStatus, this.authService.getCurrentUserDetails().access_token)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  approveApplication(e: any, element: number) {
    this.router.navigate(['/dashboard/advisor-management/transfer-approve-form'], {
      relativeTo: this.route,
      queryParams: {
        formId : element
      }
    });
  }

}
