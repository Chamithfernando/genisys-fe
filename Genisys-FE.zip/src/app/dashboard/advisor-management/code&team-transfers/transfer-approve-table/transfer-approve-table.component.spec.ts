import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferApproveTableComponent } from './transfer-approve-table.component';

describe('TransferApproveTableComponent', () => {
  let component: TransferApproveTableComponent;
  let fixture: ComponentFixture<TransferApproveTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransferApproveTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferApproveTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
