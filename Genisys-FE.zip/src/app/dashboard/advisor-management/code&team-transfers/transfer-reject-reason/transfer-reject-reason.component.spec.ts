import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferRejectReasonComponent } from './transfer-reject-reason.component';

describe('TransferRejectReasonComponent', () => {
  let component: TransferRejectReasonComponent;
  let fixture: ComponentFixture<TransferRejectReasonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransferRejectReasonComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferRejectReasonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
