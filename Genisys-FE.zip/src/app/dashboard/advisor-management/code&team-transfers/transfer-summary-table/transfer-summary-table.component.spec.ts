import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferSummaryTableComponent } from './transfer-summary-table.component';

describe('TransferSummaryTableComponent', () => {
  let component: TransferSummaryTableComponent;
  let fixture: ComponentFixture<TransferSummaryTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransferSummaryTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferSummaryTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
