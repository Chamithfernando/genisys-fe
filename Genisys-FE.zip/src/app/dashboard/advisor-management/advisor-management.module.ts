import { NgModule } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';

import { AdvisorManagementRoutingModule } from './advisor-management-routing.module';
import { CreateFormComponent } from './promotion-demotion/create-form/create-form.component';
import {MatCardModule} from '@angular/material/card';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatOptionModule} from '@angular/material/core';
import {MatSelectModule} from '@angular/material/select';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { CommonUtilitiesComponent } from './utilities/common-utilities/common-utilities.component';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import {MatDialogModule} from '@angular/material/dialog';
import { ValidationComponent } from './utilities/validation/validation.component';
import { ViewTableComponent } from './promotion-demotion/manage-application/view-table/view-table.component';
import { DraftTableComponent } from './promotion-demotion/manage-application/draft-table/draft-table.component';
import { NotApprovedTableComponent } from './promotion-demotion/manage-application/not-approved-table/not-approved-table.component';
import { CompletedTableComponent } from './promotion-demotion/manage-application/completed-table/completed-table.component';
import { ApproveTableComponent } from './promotion-demotion/manage-application/approve-table/approve-table.component';
import {MatTabsModule} from '@angular/material/tabs';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatTableModule} from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { AddApproveStatusComponent } from './promotion-demotion/manage-application/add-approve-status/add-approve-status.component';
import { ApproveFormComponent } from './promotion-demotion/manage-application/approve-form/approve-form.component';
import { CurrentApprovalLevelsComponent } from './promotion-demotion/manage-application/current-approval-levels/current-approval-levels.component';
import {MatStepperModule} from '@angular/material/stepper';
import { RejectedTableComponent } from './promotion-demotion/manage-application/rejected-table/rejected-table.component';
import { RejectReasonComponent } from './promotion-demotion/manage-application/reject-reason/reject-reason.component';
import { EditFormComponent } from './promotion-demotion/manage-application/edit-form/edit-form.component';
import { OpenPdfComponent } from './promotion-demotion/manage-application/open-pdf/open-pdf.component';
import {PdfViewerModule} from 'ng2-pdf-viewer';
import { AllTransferDataTableComponent } from './code&team-transfers/all-transfer-data-table/all-transfer-data-table.component';
import { TransferDraftTableComponent } from './code&team-transfers/transfer-draft-table/transfer-draft-table.component';
import { TransferApproveTableComponent } from './code&team-transfers/transfer-approve-table/transfer-approve-table.component';
import { TransferNotApprovedTableComponent } from './code&team-transfers/transfer-not-approved-table/transfer-not-approved-table.component';
import { TransferCompletedTableComponent } from './code&team-transfers/transfer-completed-table/transfer-completed-table.component';
import { TransferRejectedTableComponent } from './code&team-transfers/transfer-rejected-table/transfer-rejected-table.component';
import { TransferFormComponent } from './code&team-transfers/transfer-form/transfer-form.component';
import {MatDividerModule} from '@angular/material/divider';
import { TransferEditFormComponent } from './code&team-transfers/transfer-edit-form/transfer-edit-form.component';
import { TransferApproveFormComponent } from './code&team-transfers/transfer-approve-form/transfer-approve-form.component';
import { TransferSummaryTableComponent } from './code&team-transfers/transfer-summary-table/transfer-summary-table.component';
import {MatChipsModule} from '@angular/material/chips';
import { TransferApprovalLevelsComponent } from './code&team-transfers/transfer-approval-levels/transfer-approval-levels.component';
import { TransferRejectReasonComponent } from './code&team-transfers/transfer-reject-reason/transfer-reject-reason.component';
import { SummaryTableComponent } from './promotion-demotion/manage-application/summary-table/summary-table.component';
import { RemoveRecordComponent } from './promotion-demotion/manage-application/remove-record/remove-record.component';
import { MatTableExporterModule } from 'mat-table-exporter';
import { OpenDocumentComponent } from './promotion-demotion/manage-application/open-document/open-document.component';
import { AllTerminationTableComponent } from './termination-resignation/all-termination-table/all-termination-table.component';
import { TerminationDraftTableComponent } from './termination-resignation/termination-draft-table/termination-draft-table.component';
import { TerminationApproveTableComponent } from './termination-resignation/termination-approve-table/termination-approve-table.component';
import { TerminationNotApproveTableComponent } from './termination-resignation/termination-not-approve-table/termination-not-approve-table.component';
import { TerminationCompletedTableComponent } from './termination-resignation/termination-completed-table/termination-completed-table.component';
import { TerminationRejectedTableComponent } from './termination-resignation/termination-rejected-table/termination-rejected-table.component';
import { TerminationSummaryTableComponent } from './termination-resignation/termination-summary-table/termination-summary-table.component';
import { TerminationFinanceClearanceTableComponent } from './termination-resignation/termination-finance-clearance-table/termination-finance-clearance-table.component';
import { TerminationFormComponent } from './termination-resignation/termination-form/termination-form.component';
import { TerminationEditFormComponent } from './termination-resignation/termination-edit-form/termination-edit-form.component';
import { TerminationApprovalLevelsComponent } from './termination-resignation/termination-approval-levels/termination-approval-levels.component';
import { TerminationRejcetReasonComponent } from './termination-resignation/termination-rejcet-reason/termination-rejcet-reason.component';
import { TerminationDueAmountComponent } from './termination-resignation/termination-due-amount/termination-due-amount.component';
import {AzppModule} from '@app/dashboard/azpp/azpp.module';
import { TerminationApproveFormComponent } from './termination-resignation/termination-approve-form/termination-approve-form.component';
import { TerminationServicingSubmitComponent } from './termination-resignation/termination-servicing-submit/termination-servicing-submit.component';
import { TerminationServicingComponent } from './termination-resignation/termination-servicing/termination-servicing.component';
import { AllPolicyTransferTableComponent } from './policy-transfer/all-policy-transfer-table/all-policy-transfer-table.component';
import { PolicyTransferFormComponent } from './policy-transfer/policy-transfer-form/policy-transfer-form.component';
import { PolicyTransferDraftTableComponent } from './policy-transfer/policy-transfer-draft-table/policy-transfer-draft-table.component';
import { PolicyTransferApproveTableComponent } from './policy-transfer/policy-transfer-approve-table/policy-transfer-approve-table.component';
import { PolicyTransferNotApproveTableComponent } from './policy-transfer/policy-transfer-not-approve-table/policy-transfer-not-approve-table.component';
import { PolicyTransferRejectedTableComponent } from './policy-transfer/policy-transfer-rejected-table/policy-transfer-rejected-table.component';
import { PolicyTransferSummaryTableComponent } from './policy-transfer/policy-transfer-summary-table/policy-transfer-summary-table.component';
import { PolicyTransferCompletedTableComponent } from './policy-transfer/policy-transfer-completed-table/policy-transfer-completed-table.component';
import { PolicyTransferEditFormComponent } from './policy-transfer/policy-transfer-edit-form/policy-transfer-edit-form.component';
import { PolicyTransferApproveFormComponent } from './policy-transfer/policy-transfer-approve-form/policy-transfer-approve-form.component';
import { PolicyTransferApprovalLevelsComponent } from './policy-transfer/policy-transfer-approval-levels/policy-transfer-approval-levels.component';
import { PolicyTransferRejectReasonComponent } from './policy-transfer/policy-transfer-reject-reason/policy-transfer-reject-reason.component';
import { PolicyTransferServicingComponent } from './policy-transfer/policy-transfer-servicing/policy-transfer-servicing.component';
import { BranchTransferFormComponent } from './branch-transfer/branch-transfer-form/branch-transfer-form.component';
import { AllBranchTransferTableComponent } from './branch-transfer/all-branch-transfer-table/all-branch-transfer-table.component';
import { BranchTransferDraftTableComponent } from './branch-transfer/branch-transfer-draft-table/branch-transfer-draft-table.component';
import { BranchTransferApproveTableComponent } from './branch-transfer/branch-transfer-approve-table/branch-transfer-approve-table.component';
import { BranchTransferCompletedTableComponent } from './branch-transfer/branch-transfer-completed-table/branch-transfer-completed-table.component';
import { BranchTransferNotApproveTableComponent } from './branch-transfer/branch-transfer-not-approve-table/branch-transfer-not-approve-table.component';
import { BranchTransferRejectedTableComponent } from './branch-transfer/branch-transfer-rejected-table/branch-transfer-rejected-table.component';
import { BranchTransferSummaryTableComponent } from './branch-transfer/branch-transfer-summary-table/branch-transfer-summary-table.component';
import { BranchTransferRejectReasonComponent } from './branch-transfer/branch-transfer-reject-reason/branch-transfer-reject-reason.component';
import { BranchTransferApprovalLevelsComponent } from './branch-transfer/branch-transfer-approval-levels/branch-transfer-approval-levels.component';
import { BranchTransferEditFormComponent } from './branch-transfer/branch-transfer-edit-form/branch-transfer-edit-form.component';
import { BranchTransferApproveFormComponent } from './branch-transfer/branch-transfer-approve-form/branch-transfer-approve-form.component';
import { IncomeServiceFormComponent } from './income-service/income-service-form/income-service-form.component';
import { AllIncomeServiceTableComponent } from './income-service/all-income-service-table/all-income-service-table.component';
import { IncomeServiceApprovalLevelsComponent } from './income-service/income-service-approval-levels/income-service-approval-levels.component';
import { IncomeServiceApproveFormComponent } from './income-service/income-service-approve-form/income-service-approve-form.component';
import { IncomeServiceApproveTableComponent } from './income-service/income-service-approve-table/income-service-approve-table.component';
import { IncomeServiceCompletedTableComponent } from './income-service/income-service-completed-table/income-service-completed-table.component';
import { IncomeServiceDraftTableComponent } from './income-service/income-service-draft-table/income-service-draft-table.component';
import { IncomeServiceEditFormComponent } from './income-service/income-service-edit-form/income-service-edit-form.component';
import { IncomeServiceNotApproveTableComponent } from './income-service/income-service-not-approve-table/income-service-not-approve-table.component';
import { IncomeServiceRejectReasonComponent } from './income-service/income-service-reject-reason/income-service-reject-reason.component';
import { IncomeServiceRejectedTableComponent } from './income-service/income-service-rejected-table/income-service-rejected-table.component';
import { IncomeServiceSummaryTableComponent } from './income-service/income-service-summary-table/income-service-summary-table.component';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { DecimalPrecisionDirective } from './utilities/common-utilities/decimal-precision.directive';


@NgModule({
  declarations: [
    CreateFormComponent,
    CommonUtilitiesComponent,
    ValidationComponent,
    ViewTableComponent,
    DraftTableComponent,
    NotApprovedTableComponent,
    CompletedTableComponent,
    ApproveTableComponent,
    AddApproveStatusComponent,
    ApproveFormComponent,
    CurrentApprovalLevelsComponent,
    RejectedTableComponent,
    RejectReasonComponent,
    EditFormComponent,
    OpenPdfComponent,
    AllTransferDataTableComponent,
    TransferDraftTableComponent,
    TransferApproveTableComponent,
    TransferNotApprovedTableComponent,
    TransferCompletedTableComponent,
    TransferRejectedTableComponent,
    TransferFormComponent,
    TransferEditFormComponent,
    TransferApproveFormComponent,
    TransferSummaryTableComponent,
    TransferApprovalLevelsComponent,
    TransferRejectReasonComponent,
    SummaryTableComponent,
    RemoveRecordComponent,
    OpenDocumentComponent,
    AllTerminationTableComponent,
    TerminationDraftTableComponent,
    TerminationApproveTableComponent,
    TerminationNotApproveTableComponent,
    TerminationCompletedTableComponent,
    TerminationRejectedTableComponent,
    TerminationSummaryTableComponent,
    TerminationFinanceClearanceTableComponent,
    TerminationFormComponent,
    TerminationEditFormComponent,
    TerminationApprovalLevelsComponent,
    TerminationRejcetReasonComponent,
    TerminationDueAmountComponent,
    TerminationApproveFormComponent,
    TerminationServicingSubmitComponent,
    TerminationServicingComponent,
    AllPolicyTransferTableComponent,
    PolicyTransferFormComponent,
    PolicyTransferDraftTableComponent,
    PolicyTransferApproveTableComponent,
    PolicyTransferNotApproveTableComponent,
    PolicyTransferRejectedTableComponent,
    PolicyTransferSummaryTableComponent,
    PolicyTransferCompletedTableComponent,
    PolicyTransferEditFormComponent,
    PolicyTransferApproveFormComponent,
    PolicyTransferApprovalLevelsComponent,
    PolicyTransferRejectReasonComponent,
    PolicyTransferServicingComponent,
    BranchTransferFormComponent,
    AllBranchTransferTableComponent,
    BranchTransferDraftTableComponent,
    BranchTransferApproveTableComponent,
    BranchTransferCompletedTableComponent,
    BranchTransferNotApproveTableComponent,
    BranchTransferRejectedTableComponent,
    BranchTransferSummaryTableComponent,
    BranchTransferRejectReasonComponent,
    BranchTransferApprovalLevelsComponent,
    BranchTransferEditFormComponent,
    BranchTransferApproveFormComponent,
    IncomeServiceFormComponent,
    AllIncomeServiceTableComponent,
    IncomeServiceApprovalLevelsComponent,
    IncomeServiceApproveFormComponent,
    IncomeServiceApproveTableComponent,
    IncomeServiceCompletedTableComponent,
    IncomeServiceDraftTableComponent,
    IncomeServiceEditFormComponent,
    IncomeServiceNotApproveTableComponent,
    IncomeServiceRejectReasonComponent,
    IncomeServiceRejectedTableComponent,
    IncomeServiceSummaryTableComponent,
    DecimalPrecisionDirective,



  ],
  imports: [
    CommonModule,
    FormsModule,
    AdvisorManagementRoutingModule,
    MatCardModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatOptionModule,
    MatSelectModule,
    MatDatepickerModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatTabsModule,
    MatExpansionModule,
    MatTableModule,
    MatPaginatorModule,
    MatStepperModule,
    PdfViewerModule,
    MatDividerModule,
    MatChipsModule,
    MatTableExporterModule,
    AzppModule,
    MatCheckboxModule
  ],
  providers: [
    DecimalPipe
  ],
})
export class AdvisorManagementModule { }
